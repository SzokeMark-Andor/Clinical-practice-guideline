import argparse, os
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def savefig(path: str):
    plt.tight_layout()
    plt.savefig(path, dpi=220)
    plt.close()

def cdf_plot(values: np.ndarray, xlabel: str, title: str, out_png: str, xlim=None):
    v = np.asarray(values)
    v = v[np.isfinite(v)]
    v = v[v >= 0]
    if v.size == 0:
        return
    xs = np.sort(v)
    ys = np.arange(1, xs.size + 1) / xs.size
    plt.figure()
    plt.plot(xs, ys)
    if xlim is not None:
        plt.xlim(xlim)
    plt.ylim((0, 1))
    plt.xlabel(xlabel)
    plt.ylabel("Fraction of stations")
    plt.title(title)
    savefig(out_png)

def hist_plot(values: np.ndarray, xlabel: str, title: str, out_png: str, bins=60, xlim=None):
    v = np.asarray(values)
    v = v[np.isfinite(v)]
    v = v[v >= 0]
    if v.size == 0:
        return
    plt.figure()
    plt.hist(v, bins=bins)
    if xlim is not None:
        plt.xlim(xlim)
    plt.xlabel(xlabel)
    plt.ylabel("Count")
    plt.title(title)
    savefig(out_png)

def barh_series(series: pd.Series, xlabel: str, title: str, out_png: str, topn=None):
    s = series.dropna().copy()
    if topn is not None:
        s = s.head(topn)
    plt.figure(figsize=(9.5, 7.2))
    plt.barh(s.index.astype(str), s.values)
    plt.xlabel(xlabel)
    plt.title(title)
    plt.gca().invert_yaxis()
    savefig(out_png)

def heatmap(df: pd.DataFrame, out_png: str, title: str):
    m = df.to_numpy(dtype=float)
    plt.figure(figsize=(10.5, 7.2))
    plt.imshow(m, aspect="auto", interpolation="nearest")
    plt.colorbar(label="Percent")
    plt.xticks(np.arange(df.shape[1]), df.columns, rotation=45, ha="right")
    plt.yticks(np.arange(df.shape[0]), df.index.astype(str))
    plt.title(title)
    savefig(out_png)

def pct(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def df_to_md_simple(df: pd.DataFrame) -> str:
    # pure-python markdown table (no tabulate dependency needed)
    cols = list(df.columns)
    lines = []
    lines.append("| " + " | ".join(map(str, cols)) + " |")
    lines.append("| " + " | ".join(["---"] * len(cols)) + " |")
    for _, r in df.iterrows():
        lines.append("| " + " | ".join([str(r[c]) for c in cols]) + " |")
    return "\n".join(lines)

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--pair_max_dist_m", type=float, default=2000.0)
    args = ap.parse_args()

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")
    p_cst     = os.path.join(in_dir, "open_counts_station_kind_top30_max.csv")
    p_cad     = os.path.join(in_dir, "open_counts_aed_kind_top30_max.csv")
    p_pairs   = os.path.join(in_dir, "open_pairs_top30_countries_max.csv")  # optional

    must_exist(p_summary); must_exist(p_meta); must_exist(p_cst); must_exist(p_cad)

    df   = read_summary(p_summary)
    meta = pd.read_csv(p_meta, low_memory=True)
    cst  = pd.read_csv(p_cst, low_memory=True)
    cad  = pd.read_csv(p_cad, low_memory=True)

    n_stations  = int(df.shape[0])
    countries   = sorted(df["country_iso2"].dropna().unique().tolist())
    n_countries = len(countries)

    dist = df["nearest_aed_m"].to_numpy()
    has  = np.isfinite(dist)
    within2km = has & (dist <= args.pair_max_dist_m)

    # --- Overall thresholds (all station kinds)
    thresholds_m = [100,200,300,400,500,800,1000,1500,2000]
    overall = []
    for t in thresholds_m:
        overall.append({"threshold_m": t, "pct_stations_with_nearest_aed_leq_t": pct(np.mean(has & (dist <= t)))})
    overall_df = pd.DataFrame(overall)
    overall_df.to_csv(os.path.join(out_dir, "overall_thresholds_all_station_kinds.csv"), index=False)

    # --- Stricter "rail-ish" subset (more manuscript-aligned)
    strict_kinds = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_strict = df[df["station_kind"].isin(strict_kinds)].copy()
    distS = df_strict["nearest_aed_m"].to_numpy()
    hasS  = np.isfinite(distS)
    strict = []
    for t in thresholds_m:
        strict.append({"threshold_m": t, "pct_stations_with_nearest_aed_leq_t": pct(np.mean(hasS & (distS <= t)))})
    pd.DataFrame(strict).to_csv(os.path.join(out_dir, "overall_thresholds_strict_railish.csv"), index=False)

    # --- Per-country metrics (all)
    df2 = df.copy()
    df2["has_nearest"] = np.isfinite(df2["nearest_aed_m"])
    df2["within_2km"]  = df2["has_nearest"] & (df2["nearest_aed_m"] <= args.pair_max_dist_m)

    rows = []
    for iso2, g in df2.groupby("country_iso2", dropna=True):
        d = g["nearest_aed_m"].to_numpy()
        h = np.isfinite(d)
        med = float(np.nanmedian(d)) if np.any(h) else np.nan
        p90 = float(np.nanquantile(d, 0.90)) if np.any(h) else np.nan
        p95 = float(np.nanquantile(d, 0.95)) if np.any(h) else np.nan
        rows.append({
            "country_iso2": iso2,
            "stations_n": int(g.shape[0]),
            "pct_within_200m": pct(np.mean(h & (d <= 200))),
            "pct_within_500m": pct(np.mean(h & (d <= 500))),
            "pct_within_1000m": pct(np.mean(h & (d <= 1000))),
            "pct_within_2km": pct(np.mean(h & (d <= args.pair_max_dist_m))),
            "median_nearest_aed_m": (np.round(med,1) if np.isfinite(med) else ""),
            "p90_nearest_aed_m": (np.round(p90,1) if np.isfinite(p90) else ""),
            "p95_nearest_aed_m": (np.round(p95,1) if np.isfinite(p95) else ""),
            "median_unique_aeds_within_radius": float(np.nanmedian(g["unique_aeds_within_radius"].to_numpy()))
        })

    country_df = pd.DataFrame(rows).sort_values(
        by=["pct_within_500m","median_nearest_aed_m"],
        ascending=[False, True],
        kind="mergesort"
    )
    country_df.to_csv(os.path.join(out_dir, "country_metrics_all_station_kinds.csv"), index=False)

    # --- Global counts
    kind_counts = df["station_kind"].value_counts(dropna=False)
    kind_counts.reset_index().rename(columns={"index":"station_kind","station_kind":"n"}).to_csv(
        os.path.join(out_dir, "station_kind_counts_global.csv"), index=False
    )

    aed_global = cad.groupby("aed_kind", dropna=False)["n"].sum().sort_values(ascending=False)
    aed_global.reset_index().rename(columns={"n":"n"}).to_csv(
        os.path.join(out_dir, "aed_kind_counts_global.csv"), index=False
    )

    # --------------------------
    # FIGURES — nearest distance
    # --------------------------
    cdf_plot(dist[within2km], "Nearest AED distance (m)",
             "CDF — nearest AED distance (stations with AED within 2 km)",
             os.path.join(out_dir, "fig_cdf_nearest_aed_distance_within2km.png"),
             xlim=(0, args.pair_max_dist_m))

    hist_plot(dist[within2km], "Nearest AED distance (m)",
              "Histogram — nearest AED distance (within 2 km)",
              os.path.join(out_dir, "fig_hist_nearest_aed_distance_within2km.png"),
              bins=70, xlim=(0, args.pair_max_dist_m))

    med_series = pd.to_numeric(country_df.set_index("country_iso2")["median_nearest_aed_m"], errors="coerce").dropna().sort_values()
    barh_series(med_series, "Median nearest AED distance (m)",
                "Country ranking — median nearest AED distance (lower is better)",
                os.path.join(out_dir, "fig_country_median_nearest_distance.png"))

    pct500 = pd.to_numeric(country_df.set_index("country_iso2")["pct_within_500m"], errors="coerce").dropna().sort_values(ascending=False)
    barh_series(pct500, "% stations with nearest AED ≤ 500m",
                "Country ranking — coverage within 500m (higher is better)",
                os.path.join(out_dir, "fig_country_pct_within_500m.png"))

    topKinds = kind_counts.head(12).sort_values(ascending=True)
    plt.figure(figsize=(9.5,7.2))
    plt.barh(topKinds.index.astype(str), topKinds.values)
    plt.xlabel("Count")
    plt.title("Station kinds (global) — top 12 by count")
    plt.gca().invert_yaxis()
    savefig(os.path.join(out_dir, "fig_station_kind_top12.png"))

    topAeds = aed_global.head(10).sort_values(ascending=True)
    plt.figure(figsize=(9.2,6.2))
    plt.barh(topAeds.index.astype(str), topAeds.values)
    plt.xlabel("Count")
    plt.title("AED tagging kinds (global) — top 10")
    plt.gca().invert_yaxis()
    savefig(os.path.join(out_dir, "fig_aed_kind_top10.png"))

    # --------------------------
    # FIGURES — metadata heatmap
    # --------------------------
    m = meta.copy().sort_values("country_iso2").set_index("country_iso2")
    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in m.columns]
    mm = m[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
    if mm.shape[0] > 0 and mm.shape[1] > 0:
        heatmap(mm, os.path.join(out_dir, "fig_metadata_coverage_heatmap.png"),
                "Metadata completeness (percent) — OSM tags by country")

    # --------------------------
    # MEDICAL — distance -> estimated time-to-defib (two scenarios)
    # Scenario model: round-trip walk to AED + setup time
    # --------------------------
    d_ok = dist[within2km].astype(float)

    scenarios = [
        # label, walk_speed_mps, setup_seconds
        ("baseline", 1.20, 60.0),
        ("slower_walk", 1.00, 90.0),
    ]
    med_thr = [3,5,8,10]
    med_rows = []

    for label, v_mps, setup_s in scenarios:
        t_min = ((2.0 * d_ok / v_mps) + setup_s) / 60.0

        cdf_plot(t_min, "Estimated time-to-defibrillation (min)",
                 f"CDF — estimated time-to-defib ({label}: v={v_mps:.2f} m/s, setup={setup_s:.0f}s)",
                 os.path.join(out_dir, f"fig_cdf_time_to_defib_minutes_{label}.png"),
                 xlim=(0, 12))

        hist_plot(t_min, "Estimated time-to-defibrillation (min)",
                  f"Histogram — estimated time-to-defib ({label})",
                  os.path.join(out_dir, f"fig_hist_time_to_defib_minutes_{label}.png"),
                  bins=60, xlim=(0, 12))

        for t in med_thr:
            med_rows.append({
                "scenario": label,
                "walk_speed_mps": v_mps,
                "setup_seconds": setup_s,
                "threshold_min": t,
                "pct_stations_estimated_defib_time_leq_threshold": pct(np.mean(t_min <= t))
            })

    pd.DataFrame(med_rows).to_csv(os.path.join(out_dir, "medical_time_thresholds_two_scenarios.csv"), index=False)

    # --------------------------
    # REPORT (markdown) — manuscript-ready summary
    # --------------------------
    overall_pct_200  = float(overall_df.loc[overall_df["threshold_m"]==200,  "pct_stations_with_nearest_aed_leq_t"].iloc[0])
    overall_pct_500  = float(overall_df.loc[overall_df["threshold_m"]==500,  "pct_stations_with_nearest_aed_leq_t"].iloc[0])
    overall_pct_2000 = float(overall_df.loc[overall_df["threshold_m"]==2000, "pct_stations_with_nearest_aed_leq_t"].iloc[0])

    top5 = country_df.head(5)[["country_iso2","stations_n","pct_within_500m","median_nearest_aed_m"]]
    bot5 = country_df.tail(5)[["country_iso2","stations_n","pct_within_500m","median_nearest_aed_m"]]

    report = []
    report.append("# OPEN PACK (MAX) — Key findings for manuscript")
    report.append("")
    report.append(f"- Countries in file: **{n_countries}**")
    report.append(f"- Station/stops rows: **{n_stations:,}**")
    report.append("")
    report.append("## Coverage (nearest AED distance) — all station kinds")
    report.append(f"- % stations with nearest AED ≤ 200 m: **{overall_pct_200:.2f}%**")
    report.append(f"- % stations with nearest AED ≤ 500 m: **{overall_pct_500:.2f}%**")
    report.append(f"- % stations with nearest AED ≤ 2000 m: **{overall_pct_2000:.2f}%**")
    report.append("")
    report.append("## Best vs worst countries (coverage within 500m) — all station kinds")
    report.append("")
    report.append("Top 5:")
    report.append(df_to_md_simple(top5))
    report.append("")
    report.append("Bottom 5:")
    report.append(df_to_md_simple(bot5))
    report.append("")
    report.append("## Figures generated")
    figs = [
        "fig_cdf_nearest_aed_distance_within2km.png",
        "fig_hist_nearest_aed_distance_within2km.png",
        "fig_country_median_nearest_distance.png",
        "fig_country_pct_within_500m.png",
        "fig_station_kind_top12.png",
        "fig_aed_kind_top10.png",
        "fig_metadata_coverage_heatmap.png",
        "fig_cdf_time_to_defib_minutes_baseline.png",
        "fig_hist_time_to_defib_minutes_baseline.png",
        "fig_cdf_time_to_defib_minutes_slower_walk.png",
        "fig_hist_time_to_defib_minutes_slower_walk.png",
    ]
    for f in figs:
        if os.path.exists(os.path.join(out_dir, f)):
            report.append(f"- `{f}`")
    report.append("")
    report.append("## Notes (important for interpreting ‘stations’)")
    report.append("- Dataset is **expanded** and may include platforms/stop_positions depending on tagging.")
    report.append("- For a stricter rail-station focus, consider filtering to station_kind ∈ {rail_station, pt_station, rail_halt, rail_stop}.")
    report.append("")

    report_path = os.path.join(out_dir, "REPORT_open_pack_max_key_findings.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report))

    print("DONE")
    print("OUT:", out_dir)
    print("WROTE:", report_path)

if __name__ == "__main__":
    main()
