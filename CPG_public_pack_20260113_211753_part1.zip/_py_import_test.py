import sys
import pandas, numpy, matplotlib
print("OK", sys.version)
