# OPEN PACK (MAX) — v9 outputs

- Rows (all): 140,175
- Rows (rail-ish): 31,700
- Figures folder: C:\Users\szoke\Documents\CPG\figures\open_pack_max_v9