import argparse, os, math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --------------------------
# Styling (journal-friendly, colorful, readable)
# --------------------------
def setup_style():
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.dpi": 160,
        "savefig.dpi": 450,
        "font.family": "DejaVu Sans",
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.20,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.fancybox": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

def savefig_all(fig, base_no_ext: str):
    # IMPORTANT: do NOT call tight_layout here (prevents layout engine/colorbar conflicts).
    fig.savefig(base_no_ext + ".png", bbox_inches="tight")
    fig.savefig(base_no_ext + ".pdf", bbox_inches="tight")
    fig.savefig(base_no_ext + ".svg", bbox_inches="tight")
    plt.close(fig)

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def pct(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def ecdf_step(values: np.ndarray):
    x = np.asarray(values, dtype=float)
    x = x[~np.isnan(x)]
    x = np.sort(x)
    y = np.arange(1, x.size + 1, dtype=float) / max(1, x.size)
    return x, y

def wilson_ci(k: int, n: int, z: float = 1.96):
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1.0 + (z*z)/n
    center = (p + (z*z)/(2*n)) / denom
    half = (z * math.sqrt((p*(1-p)/n) + (z*z)/(4*n*n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    df["country_iso2"] = df["country_iso2"].astype(str).str.strip()
    df["station_kind"] = df["station_kind"].astype(str).str.strip()
    return df

def time_to_defib_min(dist_m: np.ndarray, walk_speed_mps: float, setup_s: float, retrieval_multiplier: float):
    return ((retrieval_multiplier * dist_m / walk_speed_mps) + setup_s) / 60.0

# --------------------------
# Main
# --------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--fig_dir", required=True)
    ap.add_argument("--max_dist_m", type=float, default=2000.0)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    setup_style()
    np.random.default_rng(args.seed)

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    fig_dir = os.path.abspath(args.fig_dir)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")
    must_exist(p_summary); must_exist(p_meta)

    df   = read_summary(p_summary)
    meta = pd.read_csv(p_meta, low_memory=True)

    # Distances: missing => inf (so it correctly fails any threshold)
    d = df["nearest_aed_m"].to_numpy(dtype=float)
    d_all = d.copy()
    d_all[~np.isfinite(d_all)] = np.inf

    railish = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_rail = df[df["station_kind"].isin(railish)].copy()
    dR = df_rail["nearest_aed_m"].to_numpy(dtype=float)
    d_rail = dR.copy()
    d_rail[~np.isfinite(d_rail)] = np.inf

    # --------------- country coverage (rail-ish) ---------------
    def country_cov(dist_arr: np.ndarray, iso2: pd.Series, thr_m: float = 500.0):
        rows = []
        u = [x for x in sorted(iso2.dropna().astype(str).unique().tolist()) if x and x.lower() != "nan"]
        for c in u:
            mask = (iso2.astype(str) == c).to_numpy()
            dc = dist_arr[mask]
            n = int(dc.size)
            k = int(np.sum(dc <= thr_m))
            lo, hi = wilson_ci(k, n)
            finite = np.isfinite(dc)
            med = float(np.nanmedian(dc[finite])) if np.any(finite) else np.nan
            rows.append({
                "country_iso2": c,
                "stations_n": n,
                "pct_leq_500m": pct(k/n) if n else np.nan,
                "ci95_lo_pct": pct(lo) if np.isfinite(lo) else np.nan,
                "ci95_hi_pct": pct(hi) if np.isfinite(hi) else np.nan,
                "median_nearest_m_finite": np.round(med, 1) if np.isfinite(med) else np.nan,
                "pct_missing_or_gt2km": pct(np.mean(dc > args.max_dist_m)) if n else np.nan,
            })
        out = pd.DataFrame(rows)
        return out

    cc_all  = country_cov(d_all,  df["country_iso2"])
    cc_rail = country_cov(d_rail, df_rail["country_iso2"]) if df_rail.shape[0] else pd.DataFrame(columns=cc_all.columns)

    # --------------- heatmap matrix (rail-ish) ---------------
    thresholds = [100, 200, 300, 500, 1000, 2000]
    if cc_rail.shape[0] > 0:
        countries_sorted = cc_rail.sort_values("pct_leq_500m", ascending=False)["country_iso2"].tolist()
        M = []
        for c in countries_sorted:
            mask = (df_rail["country_iso2"].astype(str).to_numpy() == c)
            dc = d_rail[mask]
            M.append([pct(np.mean(dc <= t)) for t in thresholds])
        M = np.asarray(M, dtype=float)
    else:
        countries_sorted = []
        M = None

    # --------------- meta quality index ---------------
    meta2 = meta.copy()
    if "country_iso2" in meta2.columns:
        meta2["country_iso2"] = meta2["country_iso2"].astype(str).str.strip()
        meta2 = meta2.set_index("country_iso2")
    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in meta2.columns]
    mq = None
    if cols:
        mm = meta2[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        mm["meta_quality_index"] = mm.mean(axis=1)
        mq = mm[["meta_quality_index"]].copy()

    # ==========================================================
    # FIG 0: AUDIT DASHBOARD (v10)
    #  - FIX: removed the extra subtitle line to prevent overlap with Panel B title
    #  - FIX: bubble plot padding so bubbles never clip at the bottom
    # ==========================================================
    fig, axes = plt.subplots(2, 3, figsize=(16.2, 8.7))
    # One clean suptitle ONLY (no extra subtitle line!)
    fig.suptitle("OpenStreetMap AED proximity audit — rail-station environments (dashboard)", y=0.985, fontsize=18, fontweight="bold")
    fig.subplots_adjust(left=0.055, right=0.985, top=0.90, bottom=0.08, wspace=0.28, hspace=0.34)

    # Panel A: distance ECDF (0–2000 m window)
    ax = axes[0,0]
    xA, yA = ecdf_step(np.clip(d_all, 0, args.max_dist_m))
    ax.plot(xA, yA, linewidth=2.4, label=f"All (≤2000m: {pct(np.mean(d_all<=args.max_dist_m)):.1f}%)")
    if d_rail.size > 0:
        xR, yR = ecdf_step(np.clip(d_rail, 0, args.max_dist_m))
        ax.plot(xR, yR, linewidth=2.4, label=f"Rail-ish (≤2000m: {pct(np.mean(d_rail<=args.max_dist_m)):.1f}%)")
    for t in [100, 200, 300, 500, 1000, 2000]:
        ax.axvline(t, linestyle="--", linewidth=1.0, alpha=0.7)
    # line labels at the TOP RIGHT-ish (avoid bottom clutter)
    ax.text(200, 0.98, "200m", va="top", ha="center", fontsize=10, alpha=0.85)
    ax.text(500, 0.98, "500m", va="top", ha="center", fontsize=10, alpha=0.85)
    ax.set_xlim(0, args.max_dist_m); ax.set_ylim(0, 1)
    ax.set_title("Nearest AED distance ECDF")
    ax.set_xlabel("Distance (m)")
    ax.set_ylabel("ECDF (0–2000 m window)")
    ax.legend(loc="upper right", fontsize=10)

    # Panel B: time-to-defib ECDF baseline (rail-ish)
    ax = axes[0,1]
    # Baseline params used in earlier versions
    v0, setup0 = 1.2, 60.0
    if d_rail.size > 0:
        t_round = time_to_defib_min(d_rail, v0, setup0, 2.0)
        t_asst  = time_to_defib_min(d_rail, v0, setup0, 1.0)
        # clip only for plotting, keep true inf behavior for coverage elsewhere
        x1, y1 = ecdf_step(np.clip(t_round, 0, 15))
        x2, y2 = ecdf_step(np.clip(t_asst,  0, 15))
        ax.plot(x1, y1, linewidth=2.4, label="Round-trip ×2 (Rail-ish)")
        ax.plot(x2, y2, linewidth=2.4, label="Assisted ×1 (Rail-ish)")
        for T, lab in [(3,"3 min"), (5,"5 min")]:
            ax.axvline(T, linestyle="--", linewidth=1.0, alpha=0.75)
            ax.text(T, 0.98, lab, va="top", ha="center", fontsize=10, alpha=0.85)
    ax.set_xlim(0, 15); ax.set_ylim(0, 1)
    ax.set_title("Estimated time-to-defib ECDF (baseline)")
    ax.set_xlabel("Minutes (retrieval + setup)")
    ax.set_ylabel("ECDF")
    ax.legend(loc="upper right", fontsize=10)

    # Panel C: rail-ish country coverage heatmap
    ax = axes[0,2]
    if M is not None and len(countries_sorted) > 0:
        im = ax.imshow(M, aspect="auto", interpolation="nearest", cmap="magma", vmin=0, vmax=100)
        ax.set_yticks(np.arange(len(countries_sorted)))
        ax.set_yticklabels(countries_sorted, fontsize=9)
        ax.set_xticks(np.arange(len(thresholds)))
        ax.set_xticklabels([f"≤{t}\nm" for t in thresholds], fontsize=10)
        ax.tick_params(axis="x", pad=8)
        ax.set_xlabel("Distance threshold")
        ax.set_ylabel("Country")
        ax.set_title("Rail-ish — country coverage heatmap")
        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
        cbar.set_label("%")
    else:
        ax.set_axis_off()
        ax.text(0.5, 0.5, "Rail-ish subset empty", ha="center", va="center", fontsize=14)

    # Panel D: forest plot ≤500m (rail-ish if available else all)
    ax = axes[1,0]
    use = cc_rail.copy() if cc_rail.shape[0] else cc_all.copy()
    use = use.sort_values("pct_leq_500m", ascending=False, kind="mergesort").reset_index(drop=True)
    y = np.arange(use.shape[0])
    x = use["pct_leq_500m"].to_numpy(dtype=float)
    lo = use["ci95_lo_pct"].to_numpy(dtype=float)
    hi = use["ci95_hi_pct"].to_numpy(dtype=float)
    xerr = np.vstack([x - lo, hi - x])
    ax.errorbar(x, y, xerr=xerr, fmt="o", capsize=2, elinewidth=1.6)
    ax.set_yticks(y)
    ax.set_yticklabels(use["country_iso2"].astype(str).tolist(), fontsize=9)
    ax.invert_yaxis()
    ax.set_xlabel("% ≤ 500 m (Wilson 95% CI)")
    ax.set_title("Coverage within 500 m")
    ax.set_xlim(0, max(10, float(np.nanmax(hi) + 6)))
    for i, n in enumerate(use["stations_n"].tolist()):
        ax.text(ax.get_xlim()[1]*0.985, i, f"n={n}", va="center", ha="right", fontsize=8, alpha=0.80)

    # Panel E: data quality vs coverage (bubble = sqrt(stations); color = % missing/>2km)
    ax = axes[1,1]
    if mq is not None:
        tmp = use.set_index("country_iso2").join(mq, how="left").dropna().reset_index()
        if tmp.shape[0] >= 5:
            X = tmp["meta_quality_index"].to_numpy(dtype=float)
            Y = tmp["pct_leq_500m"].to_numpy(dtype=float)
            C = tmp["pct_missing_or_gt2km"].to_numpy(dtype=float)
            N = tmp["stations_n"].to_numpy(dtype=float)

            # bubble size scaling (stable, readable)
            s = 60 + 840 * (np.sqrt(N) / max(1.0, np.sqrt(np.nanmax(N))))

            sc = ax.scatter(X, Y, s=s, c=C, cmap="plasma", alpha=0.88, edgecolor="white", linewidth=0.8)

            # regression line + Pearson r
            r = float(np.corrcoef(X, Y)[0,1]) if X.size >= 2 else np.nan
            a, b = np.polyfit(X, Y, 1)
            xx = np.linspace(float(np.min(X)), float(np.max(X)), 120)
            ax.plot(xx, a*xx + b, linewidth=2.0, alpha=0.9)

            ax.set_title("Data quality vs coverage (bubble = √stations)")
            ax.set_xlabel("Metadata quality index (%)")
            ax.set_ylabel("% ≤ 500 m")

            # FIX: ensure NO bubble clipping (especially at the bottom)
            ymin = float(np.nanmin(Y)); ymax = float(np.nanmax(Y))
            yrng = max(1.0, ymax - ymin)
            pad = max(5.0, 0.12 * yrng)
            ax.set_ylim(ymin - pad, ymax + pad)

            xmin = float(np.nanmin(X)); xmax = float(np.nanmax(X))
            xrng = max(1.0, xmax - xmin)
            ax.set_xlim(xmin - 0.06*xrng, xmax + 0.06*xrng)

            # annotation centered top
            ax.text(
                0.5, 0.98, f"Pearson r = {r:.2f}",
                transform=ax.transAxes, ha="center", va="top", fontsize=10,
                bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="0.75", alpha=0.95)
            )

            cbar = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.02)
            cbar.set_label("% missing/>2km")
        else:
            ax.set_axis_off()
            ax.text(0.5, 0.5, "Not enough countries for meta vs coverage", ha="center", va="center", fontsize=12)
    else:
        ax.set_axis_off()
        ax.text(0.5, 0.5, "Metadata fields missing in meta file", ha="center", va="center", fontsize=12)

    # Panel F: clinical sensitivity lines (rail-ish)
    ax = axes[1,2]
    ax.set_title("Clinical sensitivity (Rail-ish)")
    ax.set_xlabel("Setup time (s)")
    ax.set_ylabel("% meeting ≤ 5 min")
    if d_rail.size > 0:
        setups = np.arange(0, 181, 15)
        speeds = [1.0, 1.2, 1.5]
        for v in speeds:
            # round-trip
            vals_rt = [pct(np.mean(time_to_defib_min(d_rail, v, s, 2.0) <= 5.0)) for s in setups]
            ax.plot(setups, vals_rt, linewidth=2.0, label=f"v={v:.1f} — Round-trip ×2")
            # assisted
            vals_as = [pct(np.mean(time_to_defib_min(d_rail, v, s, 1.0) <= 5.0)) for s in setups]
            ax.plot(setups, vals_as, linewidth=2.0, linestyle="--", label=f"v={v:.1f} — Assisted ×1")
        ax.axvline(60, linewidth=1.0, alpha=0.6)
    ax.set_xlim(0, 180)
    ax.legend(loc="upper right", fontsize=9, ncol=2)

    savefig_all(fig, os.path.join(fig_dir, "Fig0_AUDIT_DASHBOARD_open_pack_max_v10"))

    # ==========================================================
    # FIG M: Clinical impact summary (heuristic) — FIXED titles (no overlap)
    # ==========================================================
    fig, axs = plt.subplots(1, 3, figsize=(15.8, 5.1))
    fig.subplots_adjust(left=0.055, right=0.99, top=0.86, bottom=0.18, wspace=0.28)
    fig.suptitle("Clinical impact summary (heuristic): early shock remains dominant", fontsize=18, fontweight="bold")

    # M1: survival decay curves
    ax = axs[0]
    t = np.linspace(0, 15, 301)
    for pmin in [0.03, 0.04, 0.05, 0.07, 0.10]:
        ax.plot(t, np.power(1.0 - pmin, t), linewidth=2.4, label=f"{int(pmin*100)}%/min")
    for T, lab in [(3,"3 min"), (5,"5 min")]:
        ax.axvline(T, linestyle="--", linewidth=1.2, alpha=0.75)
    ax.axvspan(0, 3, alpha=0.06)
    ax.set_title("Medical model: survival decay vs time-to-shock", fontsize=13, fontweight="bold")
    ax.set_xlabel("Minutes from collapse to shock")
    ax.set_ylabel("Relative survival multiplier (heuristic)")
    ax.set_xlim(0, 15); ax.set_ylim(0, 1.02)
    ax.legend(loc="upper right", fontsize=10)

    # M2: operational ECDFs
    ax = axs[1]
    if d_rail.size > 0:
        scenarios = [
            ("Slow round-trip",    1.0, 90.0, 2.0),
            ("Baseline round-trip",1.2, 60.0, 2.0),
            ("Baseline assisted",  1.2, 60.0, 1.0),
            ("Fast assisted",      1.5, 45.0, 1.0),
        ]
        for name, v, s, mult in scenarios:
            tt = time_to_defib_min(d_rail, v, s, mult)
            x, y = ecdf_step(np.clip(tt, 0, 15))
            ax.plot(x, y, linewidth=2.4, label=name)
        for T, lab in [(3,"3 min"), (5,"5 min")]:
            ax.axvline(T, linestyle="--", linewidth=1.2, alpha=0.75)
    ax.set_title("Operational model: time-to-defib ECDF", fontsize=13, fontweight="bold")
    ax.set_xlabel("Estimated time-to-defibrillation (min)")
    ax.set_ylabel("ECDF")
    ax.set_xlim(0, 15); ax.set_ylim(0, 1)
    ax.legend(loc="lower right", fontsize=10)

    # M3: opportunity index bars
    ax = axs[2]
    if d_rail.size > 0:
        scenarios = [
            ("Slow\nround-trip",    1.0, 90.0, 2.0),
            ("Baseline\nround-trip",1.2, 60.0, 2.0),
            ("Baseline\nassisted",  1.2, 60.0, 1.0),
            ("Fast\nassisted",      1.5, 45.0, 1.0),
        ]
        vals_4 = []
        vals_10 = []
        for _, v, s, mult in scenarios:
            tt = time_to_defib_min(d_rail, v, s, mult)
            surv4  = np.power(0.96, np.where(np.isfinite(tt), tt, 1e9))
            surv10 = np.power(0.90, np.where(np.isfinite(tt), tt, 1e9))
            vals_4.append(float(np.mean(surv4)))
            vals_10.append(float(np.mean(surv10)))
        x = np.arange(len(scenarios))
        ax.bar(x - 0.18, vals_4,  width=0.36, label="Assumed 4%/min (CPR-like)")
        ax.bar(x + 0.18, vals_10, width=0.36, label="Assumed 10%/min (no-CPR-like)")
        ax.set_xticks(x)
        ax.set_xticklabels([s[0] for s in scenarios], rotation=25, ha="right")
    ax.set_title("Expected opportunity index (heuristic)", fontsize=13, fontweight="bold")
    ax.set_ylabel("Mean survival opportunity (0–1)")
    ax.set_ylim(0, 1)
    ax.legend(loc="upper right", fontsize=10)

    savefig_all(fig, os.path.join(fig_dir, "FigM_medical_compound_survival_time_opportunity_v10"))

    # ==========================================================
    # FIG X: Rail-ish distance-bin composition (top countries by station count)
    #  - keep your perfect look; set legend top-right
    # ==========================================================
    if df_rail.shape[0] > 0:
        # bins
        bins = [(0,100),(100,200),(200,300),(300,500),(500,1000),(1000,2000),(2000,np.inf)]
        labels = ["0–100","100–200","200–300","300–500","500–1000","1000–2000",">2000/missing"]

        # top countries by station count
        topN = 12
        top_c = df_rail["country_iso2"].astype(str).value_counts().head(topN).index.tolist()

        rows = []
        for c in top_c:
            dc = d_rail[df_rail["country_iso2"].astype(str).to_numpy() == c]
            n = max(1, dc.size)
            parts = []
            for lo, hi in bins:
                parts.append(100.0 * float(np.mean((dc >= lo) & (dc < hi))))
            rows.append([c] + parts)

        comp = pd.DataFrame(rows, columns=["country"] + labels)

        fig, ax = plt.subplots(figsize=(16.0, 7.6))
        left = np.zeros(comp.shape[0])
        for lab in labels:
            ax.barh(comp["country"], comp[lab].to_numpy(dtype=float), left=left, label=lab, edgecolor="white", linewidth=0.6)
            left += comp[lab].to_numpy(dtype=float)

        ax.set_title("Rail-ish subset — distance-bin composition (top countries by station count)", fontsize=20, fontweight="bold")
        ax.set_xlabel("Percent of stations")
        ax.set_xlim(0, 100)
        ax.legend(loc="upper right", fontsize=14, ncol=2, framealpha=0.95)
        savefig_all(fig, os.path.join(fig_dir, "FigX_stacked_distance_bins_top_countries_v10"))

    print("DONE")
    print("OUT_DIR:", out_dir)
    print("FIG_DIR:", fig_dir)

if __name__ == "__main__":
    main()
