# OPEN PACK (MAX) — Key findings for manuscript

- Countries in file: **30**
- Station/stops rows: **140,175**

## Coverage (nearest AED distance) — all station kinds
- % stations with nearest AED ≤ 200 m: **11.79%**
- % stations with nearest AED ≤ 500 m: **20.83%**
- % stations with nearest AED ≤ 2000 m: **38.21%**

## Best vs worst countries (coverage within 500m) — all station kinds

Top 5:
| country_iso2 | stations_n | pct_within_500m | median_nearest_aed_m |
| --- | --- | --- | --- |
| CH | 10641 | 79.78 | 175.2 |
| NL | 5956 | 55.96 | 400.7 |
| IE | 1059 | 55.81 | 397.6 |
| BE | 6853 | 55.25 | 388.5 |
| DK | 3032 | 40.27 | 646.4 |

Bottom 5:
| country_iso2 | stations_n | pct_within_500m | median_nearest_aed_m |
| --- | --- | --- | --- |
| KR | 5210 | 0.42 | 3959.9 |
| MX | 1222 | 0.25 | 4735.4 |
| TR | 5505 | 0.0 | 3633.6 |
| VN | 593 | 0.0 | 5233.0 |
| CO | 281 | 0.0 | 6356.0 |

## Figures generated
- `fig_cdf_nearest_aed_distance_within2km.png`
- `fig_hist_nearest_aed_distance_within2km.png`
- `fig_country_median_nearest_distance.png`
- `fig_country_pct_within_500m.png`
- `fig_station_kind_top12.png`
- `fig_aed_kind_top10.png`
- `fig_metadata_coverage_heatmap.png`
- `fig_cdf_time_to_defib_minutes_baseline.png`
- `fig_hist_time_to_defib_minutes_baseline.png`
- `fig_cdf_time_to_defib_minutes_slower_walk.png`
- `fig_hist_time_to_defib_minutes_slower_walk.png`

## Notes (important for interpreting ‘stations’)
- Dataset is **expanded** and may include platforms/stop_positions depending on tagging.
- For a stricter rail-station focus, consider filtering to station_kind ∈ {rail_station, pt_station, rail_halt, rail_stop}.
