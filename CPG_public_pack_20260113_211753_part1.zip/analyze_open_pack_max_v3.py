import argparse, os, math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --------------------------
# Styling (journal-friendly)
# --------------------------
def setup_style():
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.dpi": 150,
        "savefig.dpi": 450,
        "font.family": "DejaVu Sans",
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.22,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.fancybox": True,
        "pdf.fonttype": 42,  # embed TrueType fonts
        "ps.fonttype": 42,
    })

def savefig_all(base_no_ext: str):
    fig = plt.gcf()

    # IMPORTANT: do not mix tight_layout with constrained_layout (esp. with colorbars).
    try:
        if hasattr(fig, "get_constrained_layout") and fig.get_constrained_layout():
            pass
        else:
            fig.tight_layout()
    except Exception:
        pass

    fig.savefig(base_no_ext + ".png", bbox_inches="tight")
    fig.savefig(base_no_ext + ".pdf", bbox_inches="tight")
    fig.savefig(base_no_ext + ".svg", bbox_inches="tight")
    plt.close(fig)

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def pct(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def ecdf_step(values: np.ndarray):
    x = np.asarray(values, dtype=float)
    x = x[~np.isnan(x)]
    x = np.sort(x)
    y = np.arange(1, x.size + 1, dtype=float) / max(1, x.size)
    return x, y

def wilson_ci(k: int, n: int, z: float = 1.96):
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1.0 + (z*z)/n
    center = (p + (z*z)/(2*n)) / denom
    half = (z * math.sqrt((p*(1-p)/n) + (z*z)/(4*n*n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))

def md_table(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    lines = []
    lines.append("| " + " | ".join(map(str, cols)) + " |")
    lines.append("| " + " | ".join(["---"] * len(cols)) + " |")
    for _, r in df.iterrows():
        lines.append("| " + " | ".join([str(r[c]) for c in cols]) + " |")
    return "\n".join(lines)

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    df["country_iso2"] = df["country_iso2"].astype(str).str.strip()
    df["station_kind"] = df["station_kind"].astype(str).str.strip()
    return df

def time_to_defib_min(dist_m: np.ndarray, walk_speed_mps: float, setup_s: float, retrieval_multiplier: float):
    # retrieval_multiplier: 2.0=round-trip bystander fetch; 1.0=assisted/nearby responder one-way-to-AED model
    # NOTE: both are simplified heuristics; we surface sensitivity rather than pretending precision.
    return ((retrieval_multiplier * dist_m / walk_speed_mps) + setup_s) / 60.0

def dmax_for_target_minutes(t_min: float, v_mps: float, setup_s: float, retrieval_multiplier: float):
    # t = (mult*d/v + setup)/60 => d = ( (t*60 - setup) * v ) / mult
    return max(0.0, ((t_min*60.0 - setup_s) * v_mps) / max(1e-9, retrieval_multiplier))

# --------------------------
# Main
# --------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--fig_dir", required=True)
    ap.add_argument("--max_dist_m", type=float, default=2000.0)
    ap.add_argument("--pairs_max_m", type=float, default=500.0)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    setup_style()
    rng = np.random.default_rng(args.seed)

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    fig_dir = os.path.abspath(args.fig_dir)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_pairs   = os.path.join(in_dir, "open_pairs_top30_countries_max.csv")
    p_cst     = os.path.join(in_dir, "open_counts_station_kind_top30_max.csv")
    p_cad     = os.path.join(in_dir, "open_counts_aed_kind_top30_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")

    must_exist(p_summary); must_exist(p_cst); must_exist(p_cad); must_exist(p_meta)

    df   = read_summary(p_summary)
    cst  = pd.read_csv(p_cst, low_memory=True)
    cad  = pd.read_csv(p_cad, low_memory=True)
    meta = pd.read_csv(p_meta, low_memory=True)

    # Distances: replace missing with inf so "ECDF < 1.0" is visible and meaningful
    d = df["nearest_aed_m"].to_numpy(dtype=float)
    d_all = d.copy()
    d_all[~np.isfinite(d_all)] = np.inf

    railish = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_rail = df[df["station_kind"].isin(railish)].copy()
    dR = df_rail["nearest_aed_m"].to_numpy(dtype=float)
    d_rail = dR.copy()
    d_rail[~np.isfinite(d_rail)] = np.inf

    # Coverage thresholds (actionable)
    dist_thr = [50,75,100,150,200,300,500,750,1000,1500,2000]
    def coverage_table(dist_arr: np.ndarray, subset: str):
        rows = []
        for t in dist_thr:
            rows.append({"subset": subset, "threshold_m": t, "pct_stations_leq_t": pct(np.mean(dist_arr <= t))})
        out = pd.DataFrame(rows)
        out.to_csv(os.path.join(out_dir, f"coverage_thresholds_{subset}.csv"), index=False)
        return out

    cov_all  = coverage_table(d_all,  "all_station_kinds")
    cov_rail = coverage_table(d_rail, "railish_only")

    # Per-country coverage (≤500 m) + CI (all + rail)
    def country_cov(dist_arr: np.ndarray, iso2: pd.Series, subset: str, thr_m: float = 500.0):
        rows = []
        for c in sorted([x for x in iso2.unique().tolist() if x and x != "nan"]):
            mask = (iso2 == c).to_numpy()
            dc = dist_arr[mask]
            n = int(dc.size)
            k = int(np.sum(dc <= thr_m))
            lo, hi = wilson_ci(k, n)
            finite = np.isfinite(dc)
            med = float(np.nanmedian(dc[finite])) if np.any(finite) else np.nan
            q25 = float(np.nanquantile(dc[finite], 0.25)) if np.any(finite) else np.nan
            q75 = float(np.nanquantile(dc[finite], 0.75)) if np.any(finite) else np.nan
            rows.append({
                "subset": subset,
                "country_iso2": c,
                "stations_n": n,
                "p_leq_500m": (k/n) if n else np.nan,
                "pct_leq_500m": pct(k/n) if n else np.nan,
                "ci95_lo_pct": pct(lo) if np.isfinite(lo) else np.nan,
                "ci95_hi_pct": pct(hi) if np.isfinite(hi) else np.nan,
                "median_nearest_m_finite": np.round(med, 1) if np.isfinite(med) else np.nan,
                "q25_nearest_m_finite": np.round(q25, 1) if np.isfinite(q25) else np.nan,
                "q75_nearest_m_finite": np.round(q75, 1) if np.isfinite(q75) else np.nan,
                "pct_no_aed_within_2km": pct(np.mean(dc > args.max_dist_m)),
            })
        out = pd.DataFrame(rows)
        out.to_csv(os.path.join(out_dir, f"country_coverage_500m_{subset}.csv"), index=False)
        return out

    cc_all  = country_cov(d_all,  df["country_iso2"],      "all_station_kinds")
    cc_rail = country_cov(d_rail, df_rail["country_iso2"], "railish_only")

    # --------------------------
    # FIG 1: Distance ECDF (All vs Rail-ish) + thresholds
    # --------------------------
    xA, yA = ecdf_step(np.clip(d_all, 0, args.max_dist_m))  # clip inf for plotting window
    xR, yR = ecdf_step(np.clip(d_rail, 0, args.max_dist_m))

    # BUT: fractions should still reflect missing beyond window; so compute y via full dist_all then plot clipped x
    # Simpler: plot ECDF of clipped; annotate missing separately.
    miss_all  = pct(np.mean(d_all > args.max_dist_m))
    miss_rail = pct(np.mean(d_rail > args.max_dist_m))

    plt.figure(figsize=(10.2, 6.2))
    plt.step(xA, yA, where="post", linewidth=2.2, label=f"All station kinds (missing/>2km: {miss_all:.1f}%)")
    if d_rail.size > 0:
        plt.step(xR, yR, where="post", linewidth=2.2, label=f"Rail-ish only (missing/>2km: {miss_rail:.1f}%)")

    for t in [100,200,300,500,1000,2000]:
        plt.axvline(t, linestyle="--", linewidth=1)

    plt.xlim((0, args.max_dist_m))
    plt.ylim((0, 1))
    plt.xlabel("Nearest AED distance (m)")
    plt.ylabel("ECDF (within plotting window; see legend for missing/>2 km)")
    plt.title("Nearest AED distance distribution (OpenStreetMap audit) — All vs Rail-ish subset")
    plt.legend(loc="lower right")
    savefig_all(os.path.join(fig_dir, "Fig1_ecdf_distance_all_vs_railish"))

    # --------------------------
    # FIG 2: Country heatmap of coverage across thresholds (rail-ish), sorted by ≤500m
    # --------------------------
    if cc_rail.shape[0] > 0:
        # build matrix: rows countries, cols thresholds
        countries_sorted = cc_rail.sort_values("pct_leq_500m", ascending=False)["country_iso2"].tolist()
        M = []
        for c in countries_sorted:
            mask = (df_rail["country_iso2"].to_numpy() == c)
            dc = d_rail[mask]
            row = [pct(np.mean(dc <= t)) for t in [100,200,300,500,1000,2000]]
            M.append(row)
        M = np.asarray(M, dtype=float)

        plt.figure(figsize=(10.8, max(6.5, 0.32*len(countries_sorted) + 2.0)))
        im = plt.imshow(M, aspect="auto", interpolation="nearest", cmap="viridis", vmin=0, vmax=100)
        plt.colorbar(im, label="% stations with nearest AED ≤ threshold")
        plt.xticks(np.arange(6), ["≤100m","≤200m","≤300m","≤500m","≤1000m","≤2000m"], rotation=0)
        plt.yticks(np.arange(len(countries_sorted)), countries_sorted)
        plt.title("Rail-ish subset — country coverage heatmap across distance thresholds")
        savefig_all(os.path.join(fig_dir, "Fig2_heatmap_country_coverage_thresholds_railish"))

    # --------------------------
    # FIG 3: Forest plot (≤500m) with Wilson CI — rail-ish
    # --------------------------
    def forest(dfm: pd.DataFrame, subset_label: str, outbase: str):
        dff = dfm.copy().sort_values("pct_leq_500m", ascending=False, kind="mergesort")
        y = np.arange(dff.shape[0])

        x = dff["pct_leq_500m"].to_numpy(dtype=float)
        lo = dff["ci95_lo_pct"].to_numpy(dtype=float)
        hi = dff["ci95_hi_pct"].to_numpy(dtype=float)
        xerr = np.vstack([x - lo, hi - x])

        plt.figure(figsize=(10.2, max(6.0, 0.33*dff.shape[0] + 2.0)))
        plt.errorbar(x, y, xerr=xerr, fmt="o", capsize=2, elinewidth=1.6)
        plt.yticks(y, dff["country_iso2"].astype(str).tolist())
        plt.xlabel("% stations with nearest AED ≤ 500 m (Wilson 95% CI)")
        plt.title(f"Coverage within 500 m — {subset_label}")
        plt.gca().invert_yaxis()
        plt.xlim((0, max(10, float(np.nanmax(hi) + 5))))
        # annotate station counts
        for i, n in enumerate(dff["stations_n"].tolist()):
            plt.text(plt.xlim()[1]*0.98, i, f"n={n}", va="center", ha="right", fontsize=10, alpha=0.85)
        savefig_all(os.path.join(fig_dir, outbase))

    if cc_rail.shape[0] > 0:
        forest(cc_rail, "Rail-ish only", "Fig3_forest_coverage500m_railish")
    forest(cc_all, "All station kinds", "Fig3b_forest_coverage500m_all")

    # --------------------------
    # FIG 4: Clinical sensitivity heatmaps (rail-ish)
    #   % meeting 3-min and 5-min time-to-defib across speed/setup grid,
    #   for round-trip (mult=2.0) and assisted (mult=1.0)
    # --------------------------
    def sensitivity(dist_arr: np.ndarray, subset: str):
        speeds = np.array([0.8, 1.0, 1.2, 1.5])   # m/s
        setups = np.array([30, 60, 90, 120])      # seconds
        mults  = [2.0, 1.0]
        targets = [3, 5]

        rows = []
        for mult in mults:
            for v in speeds:
                for s in setups:
                    tmin = time_to_defib_min(dist_arr, v, s, mult)
                    # treat inf as inf -> fails thresholds (correct)
                    for T in targets:
                        rows.append({
                            "subset": subset,
                            "retrieval_multiplier": mult,
                            "walk_speed_mps": v,
                            "setup_seconds": s,
                            "target_min": T,
                            "pct_stations_time_leq_target": pct(np.mean(tmin <= T))
                        })
        out = pd.DataFrame(rows)
        out.to_csv(os.path.join(out_dir, f"clinical_sensitivity_grid_{subset}.csv"), index=False)

        # Make a 2x2 panel heatmap: rows=mults, cols=targets
        fig, axes = plt.subplots(2, 2, figsize=(12.2, 7.6), constrained_layout=True)
        for r, mult in enumerate(mults):
            for c, T in enumerate(targets):
                ax = axes[r, c]
                mat = np.zeros((len(speeds), len(setups)), dtype=float)
                for i, v in enumerate(speeds):
                    for j, s in enumerate(setups):
                        val = out[
                            (out["retrieval_multiplier"]==mult) &
                            (out["walk_speed_mps"]==v) &
                            (out["setup_seconds"]==s) &
                            (out["target_min"]==T)
                        ]["pct_stations_time_leq_target"].iloc[0]
                        mat[i, j] = float(val)
                im = ax.imshow(mat, aspect="auto", interpolation="nearest", cmap="viridis", vmin=0, vmax=100)
                ax.set_xticks(np.arange(len(setups)))
                ax.set_xticklabels([f"{x}s" for x in setups])
                ax.set_yticks(np.arange(len(speeds)))
                ax.set_yticklabels([f"{x:.1f}" for x in speeds])
                ax.set_xlabel("Setup time (s)")
                ax.set_ylabel("Walking speed (m/s)")
                mode = "Round-trip fetch (×2 distance)" if mult==2.0 else "Assisted/nearby (×1 distance)"
                ax.set_title(f"{mode} — % ≤ {T} min")
        cbar = fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.92)
        cbar.set_label("Percent")
        savefig_all(os.path.join(fig_dir, f"Fig4_clinical_sensitivity_heatmaps_{subset}"))

        return out

    sens_all = sensitivity(d_all, "all_station_kinds")
    if d_rail.size > 0:
        sens_rail = sensitivity(d_rail, "railish_only")

    # --------------------------
    # FIG 5: Metadata quality vs coverage (rail-ish if available else all)
    # --------------------------
    # Build a simple metadata quality index: mean of selected percent fields
    meta2 = meta.copy()
    if "country_iso2" in meta2.columns:
        meta2["country_iso2"] = meta2["country_iso2"].astype(str).str.strip()
        meta2 = meta2.set_index("country_iso2")
    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in meta2.columns]
    if cols:
        mm = meta2[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        mm["meta_quality_index"] = mm.mean(axis=1)

        use_cc = cc_rail if cc_rail.shape[0] > 0 else cc_all
        tmp = use_cc.set_index("country_iso2").join(mm[["meta_quality_index"]], how="left").dropna()
        if tmp.shape[0] >= 5:
            plt.figure(figsize=(10.2, 6.2))
            plt.scatter(tmp["meta_quality_index"].to_numpy(dtype=float), tmp["pct_leq_500m"].to_numpy(dtype=float), s=70, alpha=0.85)
            # simple least-squares line
            x = tmp["meta_quality_index"].to_numpy(dtype=float)
            y = tmp["pct_leq_500m"].to_numpy(dtype=float)
            a, b = np.polyfit(x, y, 1)
            xx = np.linspace(float(np.min(x)), float(np.max(x)), 100)
            plt.plot(xx, a*xx + b, linewidth=2.0, alpha=0.9)
            plt.xlabel("Metadata quality index (mean tag completeness, %)")
            plt.ylabel("% stations with nearest AED ≤ 500 m")
            plt.title("Data quality vs AED coverage (country-level)")
            savefig_all(os.path.join(fig_dir, "Fig5_scatter_metadata_quality_vs_coverage"))

            tmp.reset_index().to_csv(os.path.join(out_dir, "metadata_quality_vs_coverage.csv"), index=False)

    # --------------------------
    # FIG 6: PAIRS usability (≤500m): access/indoor/opening_hours completeness + "likely public" bucket
    # --------------------------
    pairs_summary_path = os.path.join(out_dir, "pairs_usability_within500m_by_country.csv")
    if os.path.exists(p_pairs):
        head = pd.read_csv(p_pairs, nrows=1, low_memory=True)
        cols_avail = set([c.strip() for c in head.columns.tolist()])
        need_cols = [c for c in ["country_iso2","distance_m","access","indoor","opening_hours"] if c in cols_avail]
        if "country_iso2" in need_cols and "distance_m" in need_cols:
            total = {}
            nonempty_access = {}
            nonempty_indoor = {}
            nonempty_open = {}
            likely_public = {}
            public_vals = {"yes","public","permissive","customers"}  # heuristic

            def is_nonempty(x):
                s = str(x).strip().lower()
                return (s not in {"", "nan", "none"})

            for chunk in pd.read_csv(p_pairs, usecols=need_cols, chunksize=250_000, low_memory=True):
                chunk["country_iso2"] = chunk["country_iso2"].astype(str).str.strip()
                chunk["distance_m"] = pd.to_numeric(chunk["distance_m"], errors="coerce")
                chunk = chunk[np.isfinite(chunk["distance_m"]) & (chunk["distance_m"] <= args.pairs_max_m)]
                if chunk.shape[0] == 0:
                    continue

                for iso2, g in chunk.groupby("country_iso2"):
                    n = int(g.shape[0])
                    total[iso2] = total.get(iso2, 0) + n

                    if "access" in g.columns:
                        a = g["access"].astype(str).tolist()
                        nonempty_access[iso2] = nonempty_access.get(iso2, 0) + int(sum(is_nonempty(x) for x in a))
                        likely_public[iso2] = likely_public.get(iso2, 0) + int(sum((str(x).strip().lower() in public_vals) for x in a))

                    if "indoor" in g.columns:
                        i = g["indoor"].astype(str).tolist()
                        nonempty_indoor[iso2] = nonempty_indoor.get(iso2, 0) + int(sum(is_nonempty(x) for x in i))

                    if "opening_hours" in g.columns:
                        o = g["opening_hours"].astype(str).tolist()
                        nonempty_open[iso2] = nonempty_open.get(iso2, 0) + int(sum(is_nonempty(x) for x in o))

            rows = []
            for iso2 in sorted(total.keys()):
                n = total.get(iso2, 0)
                rows.append({
                    "country_iso2": iso2,
                    "pairs_leq_500m_n": n,
                    "pct_pairs_nonempty_access": pct(nonempty_access.get(iso2, 0) / max(1, n)),
                    "pct_pairs_access_likely_public_bucket": pct(likely_public.get(iso2, 0) / max(1, n)),
                    "pct_pairs_nonempty_indoor": pct(nonempty_indoor.get(iso2, 0) / max(1, n)),
                    "pct_pairs_nonempty_opening_hours": pct(nonempty_open.get(iso2, 0) / max(1, n)),
                })
            outp = pd.DataFrame(rows)
            outp.to_csv(pairs_summary_path, index=False)

            # Figure: top15 likely-public share
            dtop = outp.sort_values("pct_pairs_access_likely_public_bucket", ascending=False).head(15)
            if dtop.shape[0] > 0:
                plt.figure(figsize=(10.2, 6.2))
                plt.barh(dtop["country_iso2"].astype(str), dtop["pct_pairs_access_likely_public_bucket"].to_numpy(dtype=float))
                plt.xlabel("% pairs (≤500 m) with access in {yes, public, permissive, customers} (heuristic)")
                plt.title("AED ‘likely public access’ tagging (pairs within 500 m) — top 15 countries")
                plt.gca().invert_yaxis()
                savefig_all(os.path.join(fig_dir, "Fig6_pairs_likely_public_access_top15"))

    # --------------------------
    # FIG 7/8: Global distributions (station_kind, aed_kind)
    # --------------------------
    # station_kind distribution from summary (robust) + counts file (if consistent)
    sk = df["station_kind"].value_counts(dropna=False).head(14).sort_values(ascending=True)
    plt.figure(figsize=(10.2, 6.6))
    plt.barh(sk.index.astype(str), sk.values)
    plt.xlabel("Count (rows)")
    plt.title("Station kinds — top 14 (from station summary)")
    plt.gca().invert_yaxis()
    savefig_all(os.path.join(fig_dir, "Fig7_station_kind_distribution_top14"))

    if "aed_kind" in cad.columns and "n" in cad.columns:
        ag = cad.groupby("aed_kind", dropna=False)["n"].sum().sort_values(ascending=False).head(12).sort_values(ascending=True)
        plt.figure(figsize=(10.2, 6.0))
        plt.barh(ag.index.astype(str), ag.values)
        plt.xlabel("Count")
        plt.title("AED tag kinds — top 12 (from AED counts)")
        plt.gca().invert_yaxis()
        savefig_all(os.path.join(fig_dir, "Fig8_aed_kind_distribution_top12"))

    # --------------------------
    # FIG 9: “Survival opportunity index” by country (heuristic)
    # Using an ERC-consistent per-minute penalty concept (3–5%/min); we plot 4%/min as mid-point.
    # --------------------------
    # Choose one representative scenario for ranking (round-trip baseline)
    v0, s0, mult0 = 1.2, 60.0, 2.0
    t_all = time_to_defib_min(d_all, v0, s0, mult0)
    # survival multiplier: (1 - 0.04) ** minutes ; inf -> 0
    surv = np.power(0.96, np.where(np.isfinite(t_all), t_all, 1e9))
    # country mean
    iso = df["country_iso2"].to_numpy()
    rows = []
    for c in sorted([x for x in np.unique(iso) if x and x != "nan"]):
        mask = (iso == c)
        if np.sum(mask) < 1:
            continue
        rows.append({
            "country_iso2": c,
            "stations_n": int(np.sum(mask)),
            "mean_survival_opportunity_index": float(np.mean(surv[mask])),
            "pct_leq_500m": float(cc_all[cc_all["country_iso2"]==c]["pct_leq_500m"].iloc[0]) if np.any(cc_all["country_iso2"]==c) else np.nan
        })
    so = pd.DataFrame(rows).sort_values("mean_survival_opportunity_index", ascending=False)
    so.to_csv(os.path.join(out_dir, "survival_opportunity_index_by_country_baseline_roundtrip.csv"), index=False)

    top = so.head(20).copy()
    plt.figure(figsize=(10.2, 7.2))
    plt.barh(top["country_iso2"].astype(str).iloc[::-1], top["mean_survival_opportunity_index"].to_numpy(dtype=float)[::-1])
    plt.xlabel("Mean survival opportunity index (heuristic; higher is better)")
    plt.title("Country ranking — survival opportunity index (baseline round-trip model)")
    savefig_all(os.path.join(fig_dir, "Fig9_survival_opportunity_index_top20"))

    # --------------------------
    # Report + captions
    # --------------------------
    n_total = int(df.shape[0])
    n_rail  = int(df_rail.shape[0])
    overall = {
        "pct_leq_200m_all": pct(np.mean(d_all <= 200)),
        "pct_leq_500m_all": pct(np.mean(d_all <= 500)),
        "pct_leq_2km_all":  pct(np.mean(d_all <= args.max_dist_m)),
        "pct_missing_or_gt2km_all": pct(np.mean(d_all > args.max_dist_m)),
    }
    overallR = {
        "pct_leq_200m_rail": pct(np.mean(d_rail <= 200)) if n_rail else np.nan,
        "pct_leq_500m_rail": pct(np.mean(d_rail <= 500)) if n_rail else np.nan,
        "pct_leq_2km_rail":  pct(np.mean(d_rail <= args.max_dist_m)) if n_rail else np.nan,
        "pct_missing_or_gt2km_rail": pct(np.mean(d_rail > args.max_dist_m)) if n_rail else np.nan,
    }

    # Distance limits for 3/5 min (baseline + slower; round-trip vs assisted)
    limits = []
    for label, v, s in [("baseline",1.2,60.0), ("slower",1.0,90.0)]:
        for mult in [2.0, 1.0]:
            mode = "round-trip (x2)" if mult==2.0 else "assisted (x1)"
            limits.append({
                "scenario": label,
                "mode": mode,
                "dmax_3min_m": int(round(dmax_for_target_minutes(3, v, s, mult))),
                "dmax_5min_m": int(round(dmax_for_target_minutes(5, v, s, mult))),
            })
    limits_df = pd.DataFrame(limits)

    top5 = cc_all.sort_values("pct_leq_500m", ascending=False).head(5)[["country_iso2","stations_n","pct_leq_500m","ci95_lo_pct","ci95_hi_pct","pct_no_aed_within_2km"]]
    bot5 = cc_all.sort_values("pct_leq_500m", ascending=True).head(5)[["country_iso2","stations_n","pct_leq_500m","ci95_lo_pct","ci95_hi_pct","pct_no_aed_within_2km"]]

    captions = {
        "Fig1_ecdf_distance_all_vs_railish": "Nearest AED distance ECDF (OpenStreetMap audit). Comparison between all station kinds and a stricter rail-ish subset. Dashed lines mark actionable distance thresholds.",
        "Fig2_heatmap_country_coverage_thresholds_railish": "Rail-ish subset: per-country coverage heatmap (% of stations with nearest AED within each distance threshold). Countries sorted by ≤500 m coverage.",
        "Fig3_forest_coverage500m_railish": "Rail-ish subset: country-level coverage within 500 m with Wilson 95% confidence intervals; station counts annotated.",
        "Fig3b_forest_coverage500m_all": "All station kinds: country-level coverage within 500 m with Wilson 95% confidence intervals; station counts annotated.",
        "Fig4_clinical_sensitivity_heatmaps_all_station_kinds": "Clinical sensitivity: percent of stations meeting 3-min and 5-min time-to-defibrillation targets across walking speed and setup-time grids, under round-trip vs assisted retrieval models.",
        "Fig5_scatter_metadata_quality_vs_coverage": "Association between metadata quality (mean tag completeness) and AED coverage within 500 m (country-level).",
        "Fig6_pairs_likely_public_access_top15": "Among station→AED pairs within 500 m, share with access tags indicating likely public availability (heuristic).",
        "Fig7_station_kind_distribution_top14": "Distribution of station kinds (top categories) in the station summary table.",
        "Fig8_aed_kind_distribution_top12": "Distribution of AED tag kinds (top categories) from AED counts.",
        "Fig9_survival_opportunity_index_top20": "Heuristic survival opportunity index by country under a baseline round-trip model, using a mid-point 4%/min decay concept.",
    }

    cap_path = os.path.join(out_dir, "FIGURE_CAPTIONS_open_pack_max_v3.md")
    with open(cap_path, "w", encoding="utf-8") as f:
        f.write("# Figure captions (draft)\n\n")
        for k, v in captions.items():
            f.write(f"**{k}** — {v}\n\n")

    rep = []
    rep.append("# OPEN PACK (MAX) — Manuscript Analytics v3\n")
    rep.append(f"- Stations rows (all kinds): **{n_total:,}**")
    rep.append(f"- Stations rows (rail-ish subset): **{n_rail:,}**")
    rep.append("\n## Coverage summary (all station kinds)\n")
    rep.append(f"- % with nearest AED ≤ 200 m: **{overall['pct_leq_200m_all']:.2f}%**")
    rep.append(f"- % with nearest AED ≤ 500 m: **{overall['pct_leq_500m_all']:.2f}%**")
    rep.append(f"- % with nearest AED ≤ 2 km:  **{overall['pct_leq_2km_all']:.2f}%**")
    rep.append(f"- % missing or >2 km:         **{overall['pct_missing_or_gt2km_all']:.2f}%**")
    rep.append("\n## Coverage summary (rail-ish subset)\n")
    if n_rail:
        rep.append(f"- % with nearest AED ≤ 200 m: **{overallR['pct_leq_200m_rail']:.2f}%**")
        rep.append(f"- % with nearest AED ≤ 500 m: **{overallR['pct_leq_500m_rail']:.2f}%**")
        rep.append(f"- % with nearest AED ≤ 2 km:  **{overallR['pct_leq_2km_rail']:.2f}%**")
        rep.append(f"- % missing or >2 km:         **{overallR['pct_missing_or_gt2km_rail']:.2f}%**")
    else:
        rep.append("- Rail-ish subset is empty in this file (check station_kind tagging).")

    rep.append("\n## Clinical distance limits implied by time targets (heuristic)\n")
    rep.append(md_table(limits_df))

    rep.append("\n## Best vs worst countries (≤500 m coverage; all station kinds)\n")
    rep.append("Top 5:\n" + md_table(top5))
    rep.append("\nBottom 5:\n" + md_table(bot5))

    rep.append("\n## Files written\n")
    rep.append("- coverage thresholds: `coverage_thresholds_all_station_kinds.csv`, `coverage_thresholds_railish_only.csv`")
    rep.append("- country coverage + CI: `country_coverage_500m_all_station_kinds.csv`, `country_coverage_500m_railish_only.csv`")
    rep.append("- clinical sensitivity grids: `clinical_sensitivity_grid_*.csv`")
    if os.path.exists(pairs_summary_path):
        rep.append("- pairs usability: `pairs_usability_within500m_by_country.csv`")
    rep.append("- figure captions: `FIGURE_CAPTIONS_open_pack_max_v3.md`")
    rep.append("- survival opportunity index: `survival_opportunity_index_by_country_baseline_roundtrip.csv`")

    rep_path = os.path.join(out_dir, "REPORT_open_pack_max_v3.md")
    with open(rep_path, "w", encoding="utf-8") as f:
        f.write("\n".join(rep))

    print("DONE")
    print("OUT_DIR:", out_dir)
    print("FIG_DIR:", fig_dir)
    print("REPORT:", rep_path)
    print("CAPTIONS:", cap_path)

if __name__ == "__main__":
    main()

