[CmdletBinding()]
param(
  [string]$ConfigPath   = (Join-Path (Resolve-Path ".").Path "config\osm_aed_station_experiment.json"),
  [string]$OneRunScript = (Join-Path (Resolve-Path ".").Path "scripts\run_osm_aed_station_experiment.ps1"),

  # Cities with typically better OSM AED mapping; edit freely
  [string[]]$Locations = @(
    "Bucharest, Romania",
    "Budapest, Hungary",
    "Vienna, Austria",
    "Prague, Czechia",
    "Copenhagen, Denmark",
    "Amsterdam, Netherlands"
  )
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function SafeName([string]$s) {
  if ([string]::IsNullOrWhiteSpace($s)) { return "na" }
  $t = $s.ToLowerInvariant()
  $t = $t -replace '[^0-9a-z]+','_'
  $t = $t.Trim('_')
  if ($t.Length -gt 48) { $t = $t.Substring(0,48) }
  return $t
}

if (-not (Test-Path -LiteralPath $ConfigPath))   { throw "Config not found: $ConfigPath" }
if (-not (Test-Path -LiteralPath $OneRunScript)) { throw "OneRun script not found: $OneRunScript" }

$root = (Resolve-Path ".").Path
$baseCfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json

# Make sure anonymization is ON in the base object too (add/overwrite)
$baseCfg | Add-Member -NotePropertyName "anonymize_station_names" -NotePropertyValue $true -Force

$all = New-Object System.Collections.Generic.List[object]

foreach ($loc in $Locations) {
  Write-Host "`n=== MULTI-LOCATION RUN: $loc ===" -ForegroundColor Cyan

  # clone config via JSON round-trip
  $cfg = $baseCfg | ConvertTo-Json -Depth 30 | ConvertFrom-Json

  # per-run settings
  $cfg.location_query = $loc
  $cfg.force_refresh  = $true
  $cfg | Add-Member -NotePropertyName "anonymize_station_names" -NotePropertyValue $true -Force

  $tag = SafeName $loc
  $cfg.out_raw_dir     = "data\external\osm\$tag"
  $cfg.out_reports_dir = "reports\$tag"

  $tmpCfgPath = Join-Path $root ("config\_tmp_osm_cfg_$tag.json")
  ($cfg | ConvertTo-Json -Depth 30) | Set-Content -LiteralPath $tmpCfgPath -Encoding UTF8

  try {
    & $OneRunScript -ConfigPath $tmpCfgPath
  } finally {
    Remove-Item -LiteralPath $tmpCfgPath -Force -ErrorAction SilentlyContinue
  }

  $sumPath = Join-Path $root ("reports\$tag\osm_summary.json")
  if (-not (Test-Path -LiteralPath $sumPath)) {
    Write-Warning "Missing summary JSON for $loc at: $sumPath"
    continue
  }

  $sum = Get-Content -LiteralPath $sumPath -Raw | ConvertFrom-Json

  $all.Add([pscustomobject]@{
    location_query = $loc
    radius_m       = [int]$sum.radius_m
    stations_total = [int]$sum.counts.stations_total
    aeds_total_osm = [int]$sum.counts.aeds_total
    stations_with_aed_within_radius      = [int]$sum.counts.stations_with_aed_within_radius
    stations_with_24_7_aed_within_radius = [int]$sum.counts.stations_with_24_7_aed_within_radius
    pct_stations_with_aed_within_radius      = [double]$sum.percentages.pct_stations_with_aed_within_radius
    pct_stations_with_24_7_aed_within_radius = [double]$sum.percentages.pct_stations_with_24_7_aed_within_radius
    bbox_display_name = [string]$sum.bbox.display_name
    bbox_south = [double]$sum.bbox.south
    bbox_west  = [double]$sum.bbox.west
    bbox_north = [double]$sum.bbox.north
    bbox_east  = [double]$sum.bbox.east
    generated_utc = [string]$sum.generated_utc
  })

  # be nice to Nominatim/Overpass across runs
  Start-Sleep -Seconds 1
}

# Global outputs
$globalDir = Join-Path $root "reports"
New-Item -ItemType Directory -Force -Path $globalDir | Out-Null

$csvOut = Join-Path $globalDir "multi_location_summary.csv"
$all | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $csvOut

$texOut = Join-Path $globalDir "multi_location_table.tex"
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("% Auto-generated multi-location OSM AED×Station summary")
$lines.Add("% Data © OpenStreetMap contributors (ODbL). AED tags: emergency=defibrillator (+ presence tags).")
$lines.Add("\begin{table}[t]")
$lines.Add("\centering")
$lines.Add("\small")
$lines.Add("\begin{tabular}{lrrrr}")
$lines.Add("\toprule")
$lines.Add("Location & Stations & AEDs(OSM) & \%Stations w/ AED & \%Stations w/ 24/7 AED \\")
$lines.Add("\midrule")

foreach ($r in ($all | Sort-Object location_query)) {
  $locEsc = ($r.location_query -replace '&','\&')
  $lines.Add(("{0} & {1} & {2} & {3} & {4} \\" -f
    $locEsc,
    $r.stations_total,
    $r.aeds_total_osm,
    ([Math]::Round($r.pct_stations_with_aed_within_radius,1)),
    ([Math]::Round($r.pct_stations_with_24_7_aed_within_radius,1))
  ))
}

$lines.Add("\bottomrule")
$lines.Add("\end{tabular}")
$lines.Add("\caption{Real-world AED coverage near rail/metro stations derived from OpenStreetMap within geocoded study areas. AEDs were identified using \texttt{emergency=defibrillator} (plus common presence tags such as \texttt{defibrillator=yes}/\texttt{aed=yes}). 24/7 availability is counted only when \texttt{opening\_hours} explicitly includes \texttt{24/7}; missing metadata are treated as unknown.}")
$lines.Add("\label{tab:osm_aed_station_multi}")
$lines.Add("\end{table}")

($lines -join "`r`n") | Set-Content -LiteralPath $texOut -Encoding UTF8

Write-Host "`nDONE (multi-location)." -ForegroundColor Green
Write-Host "  CSV: $csvOut"
Write-Host "  TEX: $texOut"
Write-Host "Tip: per-location outputs are under .\reports\<city_tag>\"
