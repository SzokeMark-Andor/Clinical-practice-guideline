import argparse, os, math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

# --------------------------
# Styling (journal-friendly, pro)
# --------------------------
def setup_style():
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.dpi": 150,
        "savefig.dpi": 450,
        "font.family": "DejaVu Sans",
        "font.size": 12,
        "axes.titlesize": 15,
        "axes.labelsize": 12,
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.18,
        "legend.frameon": True,
        "legend.framealpha": 0.94,
        "legend.fancybox": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

def savefig_all(fig, base_no_ext: str):
    # IMPORTANT: do NOT call tight_layout() (prevents layout-engine conflicts with colorbars)
    for ext in ("png","pdf","svg"):
        fig.savefig(base_no_ext + f".{ext}", bbox_inches="tight", facecolor="white")
    plt.close(fig)

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def pct(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def wilson_ci(k: int, n: int, z: float = 1.96):
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1.0 + (z*z)/n
    center = (p + (z*z)/(2*n)) / denom
    half = (z * math.sqrt((p*(1-p)/n) + (z*z)/(4*n*n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    df["country_iso2"] = df["country_iso2"].astype(str).str.strip()
    df["station_kind"] = df["station_kind"].astype(str).str.strip()
    return df

def time_to_defib_min(dist_m: np.ndarray, walk_speed_mps: float, setup_s: float, retrieval_multiplier: float):
    return ((retrieval_multiplier * dist_m / walk_speed_mps) + setup_s) / 60.0

# v11 FIX: ECDF within window WITHOUT clipping inf->max (prevents right-edge spikes)
def ecdf_within_window(values: np.ndarray, max_x: float):
    v = np.asarray(values, dtype=float)
    n = int(v.size)
    if n <= 0:
        return np.array([0.0]), np.array([0.0]), 0.0
    mask = np.isfinite(v) & (v <= max_x)
    x = np.sort(v[mask])
    k = int(x.size)
    if k == 0:
        return np.array([0.0]), np.array([0.0]), 0.0
    y = (np.arange(1, k + 1, dtype=float) / n)  # scaled by total n (fraction within window)
    return x, y, (k / n)

def pearson_r(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    if np.sum(m) < 3:
        return np.nan
    return float(np.corrcoef(x[m], y[m])[0,1])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--fig_dir", required=True)
    ap.add_argument("--max_dist_m", type=float, default=2000.0)
    ap.add_argument("--max_time_min", type=float, default=15.0)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    setup_style()
    rng = np.random.default_rng(args.seed)

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    fig_dir = os.path.abspath(args.fig_dir)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_cst     = os.path.join(in_dir, "open_counts_station_kind_top30_max.csv")
    p_cad     = os.path.join(in_dir, "open_counts_aed_kind_top30_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")
    must_exist(p_summary); must_exist(p_cst); must_exist(p_cad); must_exist(p_meta)

    df   = read_summary(p_summary)
    cst  = pd.read_csv(p_cst, low_memory=True)
    cad  = pd.read_csv(p_cad, low_memory=True)
    meta = pd.read_csv(p_meta, low_memory=True)

    # Distances: keep NaN/inf as inf for "no AED within window"
    d_all = df["nearest_aed_m"].to_numpy(dtype=float)
    d_all = np.where(np.isfinite(d_all), d_all, np.inf)

    railish = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_rail = df[df["station_kind"].isin(railish)].copy()
    d_rail = df_rail["nearest_aed_m"].to_numpy(dtype=float)
    d_rail = np.where(np.isfinite(d_rail), d_rail, np.inf)

    # ------------------------------------------------------------
    # Country coverage within 500 m (rail-ish) + CI
    # ------------------------------------------------------------
    def country_cov(dist_arr: np.ndarray, iso2: np.ndarray, thr_m: float = 500.0):
        rows = []
        for c in sorted([x for x in np.unique(iso2) if x and x != "nan"]):
            mask = (iso2 == c)
            dc = dist_arr[mask]
            n = int(dc.size)
            k = int(np.sum(dc <= thr_m))
            lo, hi = wilson_ci(k, n)
            rows.append({
                "country_iso2": c,
                "stations_n": n,
                "pct_leq_500m": pct(k/n) if n else np.nan,
                "ci95_lo_pct": pct(lo) if np.isfinite(lo) else np.nan,
                "ci95_hi_pct": pct(hi) if np.isfinite(hi) else np.nan,
                "pct_missing_gt_2km": pct(np.mean(dc > args.max_dist_m)) if n else np.nan,
            })
        out = pd.DataFrame(rows)
        return out

    cc_rail = country_cov(d_rail, df_rail["country_iso2"].to_numpy()) if df_rail.shape[0] else pd.DataFrame()
    cc_all  = country_cov(d_all,  df["country_iso2"].to_numpy())

    # ------------------------------------------------------------
    # Metadata quality index (same as v10)
    # ------------------------------------------------------------
    meta2 = meta.copy()
    if "country_iso2" in meta2.columns:
        meta2["country_iso2"] = meta2["country_iso2"].astype(str).str.strip()
        meta2 = meta2.set_index("country_iso2")

    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in meta2.columns]
    mm = None
    if cols:
        mm = meta2[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        mm["meta_quality_index"] = mm.mean(axis=1)

    # ------------------------------------------------------------
    # FIG0: DASHBOARD (v11) — fix ECDF right-edge spikes (A,B)
    # ------------------------------------------------------------
    fig = plt.figure(figsize=(18.8, 9.4), constrained_layout=True)
    gs = GridSpec(2, 3, figure=fig, height_ratios=[1.06, 1.0], width_ratios=[1.12, 1.0, 1.15])

    axA = fig.add_subplot(gs[0,0])
    axB = fig.add_subplot(gs[0,1])
    axC = fig.add_subplot(gs[0,2])
    axD = fig.add_subplot(gs[1,0])
    axE = fig.add_subplot(gs[1,1])
    axF = fig.add_subplot(gs[1,2])

    fig.suptitle("OpenStreetMap AED proximity audit — rail-station environments (dashboard)",
                 fontsize=20, fontweight="bold")

    # A) Nearest AED distance ECDF (0–2000 m window) — v11 spike fix
    x1, y1, frac1 = ecdf_within_window(d_all,  args.max_dist_m)
    x2, y2, frac2 = ecdf_within_window(d_rail, args.max_dist_m)

    axA.step(x1, y1, where="post", linewidth=2.2, label=f"All (≤{int(args.max_dist_m)}m: {pct(frac1):.1f}%)")
    axA.step(x2, y2, where="post", linewidth=2.2, label=f"Rail-ish (≤{int(args.max_dist_m)}m: {pct(frac2):.1f}%)")

    for t in [200, 500]:
        axA.axvline(t, linestyle="--", linewidth=1.2, alpha=0.85)
        axA.text(t, axA.get_ylim()[1]*0.98, f"{t}m", ha="center", va="top", fontsize=10, alpha=0.85)

    axA.set_xlim((0, args.max_dist_m))
    axA.set_ylim((0, max(0.45, float(max(y1.max(), y2.max())) + 0.08)))
    axA.set_title("Nearest AED distance ECDF")
    axA.set_xlabel("Distance (m)")
    axA.set_ylabel(f"ECDF (0–{int(args.max_dist_m)} m window)")
    axA.legend(loc="upper right")

    # B) Estimated time-to-defib ECDF (baseline) — v11 spike fix
    # Baseline assumptions (as in your previous versions)
    v0, setup0 = 1.2, 60.0
    t_round = time_to_defib_min(d_rail if df_rail.shape[0] else d_all, v0, setup0, 2.0)
    t_assis = time_to_defib_min(d_rail if df_rail.shape[0] else d_all, v0, setup0, 1.0)

    xb1, yb1, f1 = ecdf_within_window(t_round, args.max_time_min)
    xb2, yb2, f2 = ecdf_within_window(t_assis, args.max_time_min)

    axB.step(xb1, yb1, where="post", linewidth=2.2, label="Round-trip ×2 (Rail-ish)")
    axB.step(xb2, yb2, where="post", linewidth=2.2, label="Assisted ×1 (Rail-ish)")
    for t in [3, 5]:
        axB.axvline(t, linestyle="--", linewidth=1.2, alpha=0.85)
        axB.text(t, axB.get_ylim()[1]*0.98, f"{t} min", ha="center", va="top", fontsize=10, alpha=0.85)

    axB.set_xlim((0, args.max_time_min))
    axB.set_ylim((0, max(0.35, float(max(yb1.max(), yb2.max())) + 0.08)))
    axB.set_title("Estimated time-to-defib ECDF (baseline)")
    axB.set_xlabel("Minutes (retrieval + setup)")
    axB.set_ylabel("ECDF")
    axB.legend(loc="upper right")

    # C) Rail-ish — country coverage heatmap
    if cc_rail.shape[0] > 0:
        thr = [100,200,300,500,1000,2000]
        # sort countries by ≤500m coverage
        countries_sorted = cc_rail.sort_values("pct_leq_500m", ascending=False)["country_iso2"].tolist()
        M = []
        for c in countries_sorted:
            mask = (df_rail["country_iso2"].to_numpy() == c)
            dc = d_rail[mask]
            row = [pct(np.mean(dc <= t)) for t in thr]
            M.append(row)
        M = np.asarray(M, dtype=float)
        im = axC.imshow(M, aspect="auto", interpolation="nearest", cmap="magma", vmin=0, vmax=100)
        axC.set_title("Rail-ish — country coverage heatmap")
        axC.set_yticks(np.arange(len(countries_sorted)))
        axC.set_yticklabels(countries_sorted, fontsize=9)
        axC.set_xticks(np.arange(len(thr)))
        axC.set_xticklabels([f"≤{t}\nm" for t in thr], fontsize=9)
        axC.set_xlabel("Distance threshold")
        axC.set_ylabel("Country")
        cbar = fig.colorbar(im, ax=axC, fraction=0.046, pad=0.02)
        cbar.set_label("%", rotation=90)
    else:
        axC.axis("off")
        axC.text(0.5, 0.5, "Rail-ish subset empty\n(check station_kind tags)", ha="center", va="center")

    # D) Coverage within 500 m (Wilson 95% CI)
    useD = cc_rail if cc_rail.shape[0] > 0 else cc_all
    dff = useD.copy().sort_values("pct_leq_500m", ascending=False, kind="mergesort")
    y = np.arange(dff.shape[0])
    x = dff["pct_leq_500m"].to_numpy(dtype=float)
    lo = dff["ci95_lo_pct"].to_numpy(dtype=float)
    hi = dff["ci95_hi_pct"].to_numpy(dtype=float)
    xerr = np.vstack([x - lo, hi - x])
    axD.errorbar(x, y, xerr=xerr, fmt="o", capsize=2, elinewidth=1.6, markersize=4)
    axD.set_yticks(y)
    axD.set_yticklabels(dff["country_iso2"].astype(str).tolist(), fontsize=9)
    axD.invert_yaxis()
    axD.set_title("Coverage within 500 m")
    axD.set_xlabel("% ≤ 500 m (Wilson 95% CI)")
    axD.set_xlim((0, max(12, float(np.nanmax(hi) + 6))))
    # annotate n on right
    xmax = axD.get_xlim()[1]
    for i, n in enumerate(dff["stations_n"].tolist()):
        axD.text(xmax*0.985, i, f"n={n}", va="center", ha="right", fontsize=8, alpha=0.75)

    # E) Data quality vs coverage (bubble = √stations)
    if mm is not None:
        tmp = useD.set_index("country_iso2").join(mm[["meta_quality_index"]], how="left").dropna().reset_index()
        if tmp.shape[0] >= 5:
            xs = tmp["meta_quality_index"].to_numpy(dtype=float)
            ys = tmp["pct_leq_500m"].to_numpy(dtype=float)
            cs = tmp["pct_missing_gt_2km"].to_numpy(dtype=float)
            ss = np.sqrt(tmp["stations_n"].to_numpy(dtype=float)) * 22.0

            sc = axE.scatter(xs, ys, s=ss, c=cs, cmap="plasma", alpha=0.92, edgecolors="white", linewidths=0.6)
            # regression line
            a, b = np.polyfit(xs, ys, 1)
            xx = np.linspace(float(xs.min()), float(xs.max()), 100)
            axE.plot(xx, a*xx + b, linewidth=2.0)

            r = pearson_r(xs, ys)
            axE.set_title("Data quality vs coverage (bubble = √stations)")
            axE.set_xlabel("Metadata quality index (%)")
            axE.set_ylabel("% ≤ 500 m")
            # keep bubbles fully inside plot (same look, but prevents half-clipping)
            ypad = max(4.0, 0.08*(float(np.nanmax(ys)) - float(np.nanmin(ys)) + 1e-9))
            axE.set_ylim((float(np.nanmin(ys)) - ypad, float(np.nanmax(ys)) + ypad))
            axE.text(0.5, 0.98, f"Pearson r = {r:.2f}", transform=axE.transAxes,
                     ha="center", va="top", fontsize=10,
                     bbox=dict(boxstyle="round,pad=0.25", facecolor="white", alpha=0.85, linewidth=0.6))
            cbarE = fig.colorbar(sc, ax=axE, fraction=0.046, pad=0.02)
            cbarE.set_label("% missing/>2 km")
        else:
            axE.axis("off")
            axE.text(0.5, 0.5, "Not enough countries\nfor quality-vs-coverage", ha="center", va="center")
    else:
        axE.axis("off")
        axE.text(0.5, 0.5, "Metadata fields missing\n(no quality index)", ha="center", va="center")

    # F) Clinical sensitivity (Rail-ish) — lines (unchanged look from v10)
    axF.set_title("Clinical sensitivity (Rail-ish)")
    axF.set_xlabel("Setup time (s)")
    axF.set_ylabel("% meeting ≤ 5 min")
    setups = np.linspace(0, 180, 19)

    dist_use = d_rail if df_rail.shape[0] else d_all
    speeds = [1.0, 1.2, 1.5]
    colors = {1.0: None, 1.2: None, 1.5: None}  # let mpl cycle (keeps your v10 feel)

    for v in speeds:
        # round-trip
        vals_rt = []
        for s in setups:
            t = time_to_defib_min(dist_use, v, float(s), 2.0)
            vals_rt.append(pct(np.mean(t <= 5.0)))
        axF.plot(setups, vals_rt, linewidth=2.0, label=f"v={v:.1f} — Round-trip ×2")

        # assisted
        vals_as = []
        for s in setups:
            t = time_to_defib_min(dist_use, v, float(s), 1.0)
            vals_as.append(pct(np.mean(t <= 5.0)))
        axF.plot(setups, vals_as, linewidth=2.0, linestyle="--", label=f"v={v:.1f} — Assisted ×1")

    axF.axvline(60, linewidth=1.2, alpha=0.55)
    axF.set_xlim((0, 180))
    axF.legend(loc="upper right", ncol=2, fontsize=9)

    savefig_all(fig, os.path.join(fig_dir, "Fig0_AUDIT_DASHBOARD_open_pack_max_v11"))

    # ------------------------------------------------------------
    # FigM: Clinical impact summary (heuristic) — v11 fixes
    #   - Operational ECDF uses ecdf_within_window (no margin spike)
    #   - Legend moved to TOP-RIGHT
    # ------------------------------------------------------------
    figm, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(20, 6), constrained_layout=True)
    figm.suptitle("Clinical impact summary (heuristic): early shock remains dominant",
                  fontsize=22, fontweight="bold")

    # Left: survival decay curves
    ax1.set_title("Medical model: survival decay vs time-to-shock")
    minutes = np.linspace(0, args.max_time_min, 200)
    rates = [0.03, 0.04, 0.05, 0.07, 0.10]
    for r in rates:
        ax1.plot(minutes, np.power(1.0 - r, minutes), linewidth=2.8, label=f"{int(r*100)}%/min")
    for t in [3, 5]:
        ax1.axvline(t, linestyle="--", linewidth=1.3, alpha=0.85)
    ax1.axvspan(0, 3, alpha=0.06)
    ax1.set_xlim((0, args.max_time_min))
    ax1.set_ylim((0, 1.02))
    ax1.set_xlabel("Minutes from collapse to shock")
    ax1.set_ylabel("Relative survival multiplier (heuristic)")
    ax1.legend(loc="upper right")

    # Middle: operational time-to-defib ECDF (NO right-edge spikes; legend top-right)
    ax2.set_title("Operational model: time-to-defib ECDF")
    scenarios = [
        ("Slow round-trip",      1.0, 90.0, 2.0),
        ("Baseline round-trip",  1.2, 60.0, 2.0),
        ("Baseline assisted",    1.2, 60.0, 1.0),
        ("Fast assisted",        1.5, 30.0, 1.0),
    ]
    for name, v, s, mult in scenarios:
        tt = time_to_defib_min(dist_use, v, s, mult)
        xx, yy, ff = ecdf_within_window(tt, args.max_time_min)  # v11 FIX
        ax2.step(xx, yy, where="post", linewidth=2.6, label=name)

    for t in [3, 5]:
        ax2.axvline(t, linestyle="--", linewidth=1.3, alpha=0.85)
    ax2.set_xlim((0, args.max_time_min))
    ax2.set_ylim((0, max(0.35, float(ax2.get_ylim()[1]))))
    ax2.set_xlabel("Estimated time-to-defibrillation (min)")
    ax2.set_ylabel("ECDF")
    ax2.legend(loc="upper right")  # v11 FIX (was bottom-right)

    # Right: opportunity index bars (heuristic)
    ax3.set_title("Expected opportunity index (heuristic)")
    labels = [s[0] for s in scenarios]
    p_good = 0.04
    p_bad  = 0.10
    vals_good = []
    vals_bad  = []
    for _, v, s, mult in scenarios:
        tt = time_to_defib_min(dist_use, v, s, mult)
        surv_good = np.power(1.0 - p_good, np.where(np.isfinite(tt), tt, 1e9))
        surv_bad  = np.power(1.0 - p_bad,  np.where(np.isfinite(tt), tt, 1e9))
        vals_good.append(float(np.mean(surv_good)))
        vals_bad.append(float(np.mean(surv_bad)))

    x = np.arange(len(labels))
    w = 0.36
    ax3.bar(x - w/2, vals_good, width=w, label="Assumed 4%/min (CPR-like)")
    ax3.bar(x + w/2, vals_bad,  width=w, label="Assumed 10%/min (no-CPR-like)")
    ax3.set_xticks(x)
    ax3.set_xticklabels(labels, rotation=25, ha="right")
    ax3.set_ylabel("Mean survival opportunity (0–1)")
    ax3.set_ylim((0, 1.0))
    ax3.legend(loc="upper right")

    savefig_all(figm, os.path.join(fig_dir, "FigM_medical_compound_survival_time_opportunity_v11"))

    print("DONE")
    print("OUT_DIR:", out_dir)
    print("FIG_DIR:", fig_dir)

if __name__ == "__main__":
    main()
