# OPEN PACK (MAX) — Manuscript Analytics v7

- Stations (all kinds): **140,175**
- Stations (subset = Rail-ish): **31,700**

## Coverage summary

All station kinds:
- ≤200 m: **11.79%**
- ≤500 m: **20.83%**
- ≤2 km:  **38.21%**
- missing/>2 km: **61.79%**

Subset (Rail-ish):
- ≤200 m: **7.22%**
- ≤500 m: **12.09%**
- ≤2 km:  **22.78%**
- missing/>2 km: **77.22%**

## Figures written (PNG+PDF+SVG)

- `Fig0_AUDIT_DASHBOARD_open_pack_max_v7.[png|pdf|svg]`
- `FigA_ecdf_distance_all_vs_subset_pro.[png|pdf|svg]`
- `FigB_ecdf_time_baseline_subset_pro.[png|pdf|svg]`
- `FigC_country_coverage_heatmap_subset_pro.[png|pdf|svg]`
- `FigD_forest_coverage500m_subset_pro.[png|pdf|svg]`
- `FigE_bubble_quality_vs_coverage_pro.[png|pdf|svg]`
- `FigF_clinical_sensitivity_heatmap_pro.[png|pdf|svg]`
- `FigX_stacked_distance_bins_top_countries_pro.[png|pdf|svg]`