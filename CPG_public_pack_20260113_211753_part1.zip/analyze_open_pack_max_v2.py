import argparse, os, math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def setup_style():
    # "More scientific" defaults without extra dependencies
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.figsize": (9, 6),
        "figure.dpi": 130,
        "savefig.dpi": 320,
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "legend.fontsize": 11,
        "axes.titleweight": "bold",
        "axes.grid": True,
        "grid.alpha": 0.25,
    })

def savefig_all(basepath_no_ext: str):
    # Write PNG + PDF + SVG (PDF/SVG are manuscript-friendly)
    plt.tight_layout()
    plt.savefig(basepath_no_ext + ".png", dpi=320, bbox_inches="tight")
    plt.savefig(basepath_no_ext + ".pdf", bbox_inches="tight")
    plt.savefig(basepath_no_ext + ".svg", bbox_inches="tight")
    plt.close()

def ecdf_all(values: np.ndarray):
    # ECDF over *all* stations, allowing inf (no AED) -> curve may not reach 1 within xlim
    x = np.asarray(values, dtype=float)
    x = x[~np.isnan(x)]
    x = np.sort(x)
    y = np.arange(1, x.size + 1, dtype=float) / x.size
    return x, y

def wilson_ci(k: int, n: int, z: float = 1.96):
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1.0 + (z*z)/n
    center = (p + (z*z)/(2*n)) / denom
    half = (z * math.sqrt((p*(1-p)/n) + (z*z)/(4*n*n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    df["country_iso2"] = df["country_iso2"].astype(str).str.strip()
    df["station_kind"] = df["station_kind"].astype(str).str.strip()
    return df

def percent(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def dist_to_time_min(dist_m: np.ndarray, walk_speed_mps: float, setup_s: float):
    # Round trip + setup
    return ((2.0 * dist_m / walk_speed_mps) + setup_s) / 60.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--pair_max_dist_m", type=float, default=2000.0)
    ap.add_argument("--sample_per_country", type=int, default=25000)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    setup_style()
    rng = np.random.default_rng(args.seed)

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")
    p_cst     = os.path.join(in_dir, "open_counts_station_kind_top30_max.csv")
    p_cad     = os.path.join(in_dir, "open_counts_aed_kind_top30_max.csv")
    p_pairs   = os.path.join(in_dir, "open_pairs_top30_countries_max.csv")

    must_exist(p_summary); must_exist(p_meta); must_exist(p_cst); must_exist(p_cad)

    df   = read_summary(p_summary)
    meta = pd.read_csv(p_meta, low_memory=True)
    cst  = pd.read_csv(p_cst, low_memory=True)
    cad  = pd.read_csv(p_cad, low_memory=True)

    n_total = int(df.shape[0])
    countries = sorted([c for c in df["country_iso2"].unique().tolist() if c and c != "nan"])
    n_countries = len(countries)

    # Replace missing with inf for "all-stations ECDF" (so curve < 1 at finite x is meaningful)
    dist = df["nearest_aed_m"].to_numpy(dtype=float)
    dist_all = dist.copy()
    dist_all[~np.isfinite(dist_all)] = np.inf

    # Subsets
    railish = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_rail = df[df["station_kind"].isin(railish)].copy()
    dist_rail = df_rail["nearest_aed_m"].to_numpy(dtype=float)
    dist_rail_all = dist_rail.copy()
    dist_rail_all[~np.isfinite(dist_rail_all)] = np.inf

    # Threshold grids (include actionable distances)
    thresholds_m = [50, 75, 100, 150, 200, 300, 500, 750, 1000, 1500, 2000]

    def thresholds_table(d_all: np.ndarray, label: str):
        rows = []
        for t in thresholds_m:
            rows.append({
                "subset": label,
                "threshold_m": t,
                "pct_all_stations_with_nearest_aed_leq_t": percent(np.mean(d_all <= t))
            })
        out = pd.DataFrame(rows)
        out.to_csv(os.path.join(out_dir, f"overall_thresholds_{label}.csv"), index=False)
        return out

    thr_all  = thresholds_table(dist_all, "all_station_kinds")
    thr_rail = thresholds_table(dist_rail_all, "railish_only")

    # ---------- Figure A: ECDF distance (ALL stations, inf allowed) + threshold lines ----------
    x, y = ecdf_all(dist_all)
    plt.figure(figsize=(9.5, 6.2))
    plt.step(x, y, where="post")
    for t in [100, 150, 200, 300, 500, 1000, 2000]:
        plt.axvline(t, linestyle="--", linewidth=1)
    plt.xlim((0, args.pair_max_dist_m))
    plt.ylim((0, 1))
    plt.xlabel("Nearest AED distance (m)")
    plt.ylabel("Fraction of stations (ALL stations)")
    plt.title("Nearest AED distance — ECDF (all stations; ‘<1’ reflects missing/too-far AEDs)")
    savefig_all(os.path.join(out_dir, "figA_ecdf_distance_allstations_with_thresholds"))

    # ---------- Figure B: ECDF time-to-defib (ALL stations) overlay scenarios + 3/5 min ----------
    scenarios = [
        ("optimistic", 1.50, 45.0),
        ("baseline",   1.20, 60.0),
        ("slower",     1.00, 90.0),
    ]
    plt.figure(figsize=(9.5, 6.2))
    report_time_rows = []
    for label, v, setup_s in scenarios:
        t_all = dist_to_time_min(dist_all, v, setup_s)
        x2, y2 = ecdf_all(t_all)
        plt.step(x2, y2, where="post", label=f"{label} (v={v:.2f} m/s, setup={setup_s:.0f}s)")
        for thr in [3, 5]:
            report_time_rows.append({
                "scenario": label,
                "walk_speed_mps": v,
                "setup_seconds": setup_s,
                "threshold_min": thr,
                "pct_all_stations_time_to_defib_leq_thr": percent(np.mean(t_all <= thr))
            })

    for thr in [3, 5]:
        plt.axvline(thr, linestyle="--", linewidth=1)

    plt.xlim((0, 15))
    plt.ylim((0, 1))
    plt.xlabel("Estimated time-to-defibrillation (min) — round trip + setup")
    plt.ylabel("Fraction of stations (ALL stations)")
    plt.title("Estimated time-to-defib — ECDF across scenarios (ALL stations)")
    plt.legend(loc="lower right")
    savefig_all(os.path.join(out_dir, "figB_ecdf_time_to_defib_allstations_scenarios"))

    pd.DataFrame(report_time_rows).to_csv(os.path.join(out_dir, "medical_time_thresholds_allstations_scenarios.csv"), index=False)

    # ---------- Country metrics + Wilson CI (all station kinds + railish) ----------
    def country_props(d: np.ndarray, iso: pd.Series, label: str, thr_m: int = 500):
        rows = []
        for c in sorted(iso.unique().tolist()):
            if not c or c == "nan":
                continue
            mask = (iso == c).to_numpy()
            dc = d[mask]
            n = int(dc.size)
            k = int(np.sum(dc <= thr_m))
            lo, hi = wilson_ci(k, n)
            # median/IQR among finite only
            finite = np.isfinite(dc)
            med = float(np.nanmedian(dc[finite])) if np.any(finite) else np.nan
            q25 = float(np.nanquantile(dc[finite], 0.25)) if np.any(finite) else np.nan
            q75 = float(np.nanquantile(dc[finite], 0.75)) if np.any(finite) else np.nan
            rows.append({
                "subset": label,
                "country_iso2": c,
                "stations_n": n,
                "p_leq_500m": k / n if n else np.nan,
                "p_leq_500m_pct": percent(k / n) if n else np.nan,
                "p_leq_500m_ci95_lo_pct": percent(lo) if np.isfinite(lo) else np.nan,
                "p_leq_500m_ci95_hi_pct": percent(hi) if np.isfinite(hi) else np.nan,
                "median_nearest_aed_m_finite": np.round(med, 1) if np.isfinite(med) else np.nan,
                "q25_nearest_aed_m_finite": np.round(q25, 1) if np.isfinite(q25) else np.nan,
                "q75_nearest_aed_m_finite": np.round(q75, 1) if np.isfinite(q75) else np.nan,
            })
        out = pd.DataFrame(rows)
        out.to_csv(os.path.join(out_dir, f"country_metrics_{label}.csv"), index=False)
        return out

    cm_all  = country_props(dist_all, df["country_iso2"], "all_station_kinds")
    cm_rail = country_props(dist_rail_all, df_rail["country_iso2"], "railish_only")

    # ---------- Figure C: Forest plot (500m coverage + Wilson CI) ----------
    def forest_500(dfm: pd.DataFrame, label: str, outname: str):
        d = dfm.copy().sort_values("p_leq_500m", ascending=False, kind="mergesort")
        y = np.arange(d.shape[0])

        x = d["p_leq_500m_pct"].to_numpy()
        lo = d["p_leq_500m_ci95_lo_pct"].to_numpy()
        hi = d["p_leq_500m_ci95_hi_pct"].to_numpy()
        xerr = np.vstack([x - lo, hi - x])

        plt.figure(figsize=(9.5, max(6.0, 0.32 * d.shape[0] + 2.0)))
        plt.errorbar(x, y, xerr=xerr, fmt="o", capsize=2)
        plt.yticks(y, d["country_iso2"].astype(str).tolist())
        plt.xlabel("% stations with nearest AED ≤ 500 m (Wilson 95% CI)")
        plt.title(f"Coverage within 500 m — {label}")
        plt.gca().invert_yaxis()
        plt.xlim((0, max(5, float(np.nanmax(hi) + 5))))
        savefig_all(os.path.join(out_dir, outname))

    forest_500(cm_all,  "all station kinds", "figC_forest_500m_all_station_kinds")
    if cm_rail.shape[0] > 0:
        forest_500(cm_rail, "rail-ish only", "figC2_forest_500m_railish_only")

    # ---------- Figure D: Median + IQR “dumbbell” (finite only) ----------
    def dumbbell(dfm: pd.DataFrame, label: str, outname: str):
        d = dfm.copy()
        d = d[np.isfinite(d["median_nearest_aed_m_finite"])].copy()
        d = d.sort_values("median_nearest_aed_m_finite", ascending=True, kind="mergesort")
        y = np.arange(d.shape[0])

        med = d["median_nearest_aed_m_finite"].to_numpy(dtype=float)
        q25 = d["q25_nearest_aed_m_finite"].to_numpy(dtype=float)
        q75 = d["q75_nearest_aed_m_finite"].to_numpy(dtype=float)

        plt.figure(figsize=(9.5, max(6.0, 0.32 * d.shape[0] + 2.0)))
        for i in range(d.shape[0]):
            plt.plot([q25[i], q75[i]], [y[i], y[i]])
        plt.plot(med, y, "o")
        plt.yticks(y, d["country_iso2"].astype(str).tolist())
        plt.xlabel("Nearest AED distance (m) — finite only (IQR line, median dot)")
        plt.title(f"Nearest AED distance distribution — {label}")
        plt.gca().invert_yaxis()
        savefig_all(os.path.join(out_dir, outname))

    dumbbell(cm_all,  "all station kinds", "figD_dumbbell_median_iqr_all_station_kinds")

    # ---------- Figure E: Scatter (median distance vs 500m coverage; bubble size ~ stations_n) ----------
    dsc = cm_all.copy()
    dsc = dsc[np.isfinite(dsc["median_nearest_aed_m_finite"])].copy()
    dsc["bubble"] = np.sqrt(dsc["stations_n"].clip(lower=1).to_numpy(dtype=float))
    plt.figure(figsize=(9.5, 6.2))
    plt.scatter(
        dsc["median_nearest_aed_m_finite"].to_numpy(dtype=float),
        dsc["p_leq_500m_pct"].to_numpy(dtype=float),
        s=dsc["bubble"].to_numpy(dtype=float) * 8.0,
        alpha=0.8
    )
    plt.xlabel("Median nearest AED distance (m) — finite only")
    plt.ylabel("% stations with nearest AED ≤ 500 m")
    plt.title("Country comparison — distance vs 500 m coverage (bubble ~ √stations_n)")
    savefig_all(os.path.join(out_dir, "figE_scatter_median_vs_coverage_500m"))

    # ---------- Figure F: Metadata completeness heatmap (sorted by mean completeness) ----------
    m = meta.copy()
    if "country_iso2" in m.columns:
        m["country_iso2"] = m["country_iso2"].astype(str).str.strip()
        m = m.sort_values("country_iso2").set_index("country_iso2")

    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in m.columns]
    if cols:
        mm = m[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        mm["__mean__"] = mm.mean(axis=1)
        mm = mm.sort_values("__mean__", ascending=False).drop(columns=["__mean__"])

        plt.figure(figsize=(10.5, max(6.5, 0.28 * mm.shape[0] + 2.0)))
        plt.imshow(mm.to_numpy(dtype=float), aspect="auto", interpolation="nearest")
        plt.colorbar(label="Percent")
        plt.xticks(np.arange(mm.shape[1]), mm.columns, rotation=45, ha="right")
        plt.yticks(np.arange(mm.shape[0]), mm.index.astype(str))
        plt.title("Metadata completeness (percent) — OSM tags by country (sorted by mean)")
        savefig_all(os.path.join(out_dir, "figF_metadata_completeness_heatmap_sorted"))

    # ---------- PAIRS: access / indoor / opening_hours completeness (chunked) ----------
    pairs_out = os.path.join(out_dir, "pairs_access_indoor_opening_summary.csv")
    if os.path.exists(p_pairs):
        # detect available columns safely
        head = pd.read_csv(p_pairs, nrows=1, low_memory=True)
        cols_avail = set([c.strip() for c in head.columns.tolist()])

        want = []
        for c in ["country_iso2","distance_m","access","indoor","opening_hours"]:
            if c in cols_avail:
                want.append(c)

        if "country_iso2" in want and "distance_m" in want:
            acc = {}
            total = {}
            nonempty_access = {}
            nonempty_indoor = {}
            nonempty_open = {}
            likely_public = {}

            def is_nonempty(s):
                s = str(s).strip().lower()
                return (s != "" and s != "nan" and s != "none")

            public_vals = {"yes","public","permissive","customers"}  # heuristic bucket

            for chunk in pd.read_csv(p_pairs, usecols=want, chunksize=250_000, low_memory=True):
                chunk["country_iso2"] = chunk["country_iso2"].astype(str).str.strip()
                chunk["distance_m"] = pd.to_numeric(chunk["distance_m"], errors="coerce")
                chunk = chunk[np.isfinite(chunk["distance_m"]) & (chunk["distance_m"] <= 500.0)]
                if chunk.shape[0] == 0:
                    continue

                for iso2, g in chunk.groupby("country_iso2"):
                    n = int(g.shape[0])
                    total[iso2] = total.get(iso2, 0) + n

                    if "access" in g.columns:
                        a = g["access"].astype(str)
                        ne = int(sum(is_nonempty(x) for x in a.tolist()))
                        nonempty_access[iso2] = nonempty_access.get(iso2, 0) + ne
                        lp = int(sum((str(x).strip().lower() in public_vals) for x in a.tolist()))
                        likely_public[iso2] = likely_public.get(iso2, 0) + lp

                    if "indoor" in g.columns:
                        i = g["indoor"].astype(str)
                        ne = int(sum(is_nonempty(x) for x in i.tolist()))
                        nonempty_indoor[iso2] = nonempty_indoor.get(iso2, 0) + ne

                    if "opening_hours" in g.columns:
                        o = g["opening_hours"].astype(str)
                        ne = int(sum(is_nonempty(x) for x in o.tolist()))
                        nonempty_open[iso2] = nonempty_open.get(iso2, 0) + ne

            rows = []
            for iso2 in sorted(total.keys()):
                n = total.get(iso2, 0)
                rows.append({
                    "country_iso2": iso2,
                    "pairs_within_500m_n": n,
                    "pct_pairs_nonempty_access": percent(nonempty_access.get(iso2, 0) / max(n, 1)),
                    "pct_pairs_access_likely_public_bucket": percent(likely_public.get(iso2, 0) / max(n, 1)),
                    "pct_pairs_nonempty_indoor": percent(nonempty_indoor.get(iso2, 0) / max(n, 1)),
                    "pct_pairs_nonempty_opening_hours": percent(nonempty_open.get(iso2, 0) / max(n, 1)),
                })

            outp = pd.DataFrame(rows)
            outp.to_csv(pairs_out, index=False)

            # simple figure: public-bucket share by country (top 15)
            if outp.shape[0] > 0:
                d = outp.sort_values("pct_pairs_access_likely_public_bucket", ascending=False).head(15)
                plt.figure(figsize=(9.5, 6.2))
                plt.barh(d["country_iso2"].astype(str), d["pct_pairs_access_likely_public_bucket"].to_numpy(dtype=float))
                plt.xlabel("% pairs (≤500m) with access in {yes, public, permissive, customers} (heuristic)")
                plt.title("AED access tag ‘likely public’ (pairs within 500 m) — top 15 countries")
                plt.gca().invert_yaxis()
                savefig_all(os.path.join(out_dir, "figG_pairs_access_likely_public_top15"))

    # ---------- Report (v2) ----------
    # Derive actionable distance limits for 3/5 min under baseline/slower (round trip)
    def dmax(t_min, v, setup_s):
        # t_min = ((2*d/v)+setup)/60 => d = ( (t*60 - setup) * v ) / 2
        return max(0.0, ((t_min*60.0 - setup_s) * v) / 2.0)

    rep = []
    rep.append("# OPEN PACK (MAX) — Manuscript Analytics v2")
    rep.append("")
    rep.append(f"- Countries present: **{n_countries}**")
    rep.append(f"- Stations rows: **{n_total:,}**")
    rep.append("")
    rep.append("## Clinical timing interpretation (round-trip retrieval model)")
    rep.append("- Early defibrillation is time-critical; guideline targets often aim for shock within a few minutes of collapse.")
    rep.append("")
    for label, v, setup_s in [("baseline",1.20,60.0), ("slower",1.00,90.0)]:
        rep.append(f"**{label}** (v={v:.2f} m/s, setup={setup_s:.0f}s):")
        rep.append(f"- max distance for **3 min** target ≈ **{dmax(3,v,setup_s):.0f} m**")
        rep.append(f"- max distance for **5 min** target ≈ **{dmax(5,v,setup_s):.0f} m**")
        rep.append("")

    rep.append("## Files written (key)")
    rep.append("- `overall_thresholds_all_station_kinds.csv`, `overall_thresholds_railish_only.csv`")
    rep.append("- `country_metrics_all_station_kinds.csv`, `country_metrics_railish_only.csv`")
    rep.append("- `medical_time_thresholds_allstations_scenarios.csv`")
    if os.path.exists(pairs_out):
        rep.append("- `pairs_access_indoor_opening_summary.csv`")
    rep.append("")
    rep.append("## Figures (PNG+PDF+SVG)")
    figs = [
        "figA_ecdf_distance_allstations_with_thresholds",
        "figB_ecdf_time_to_defib_allstations_scenarios",
        "figC_forest_500m_all_station_kinds",
        "figC2_forest_500m_railish_only",
        "figD_dumbbell_median_iqr_all_station_kinds",
        "figE_scatter_median_vs_coverage_500m",
        "figF_metadata_completeness_heatmap_sorted",
        "figG_pairs_access_likely_public_top15",
    ]
    for f in figs:
        if os.path.exists(os.path.join(out_dir, f + ".png")):
            rep.append(f"- `{f}.[png|pdf|svg]`")

    report_path = os.path.join(out_dir, "REPORT_open_pack_max_v2.md")
    with open(report_path, "w", encoding="utf-8") as fp:
        fp.write("\n".join(rep))

    print("DONE")
    print("OUT:", out_dir)
    print("REPORT:", report_path)

if __name__ == "__main__":
    main()
