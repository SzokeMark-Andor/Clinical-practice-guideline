#Requires -Version 5.1
<#
.SYNOPSIS
  Merge multiple PRIVATE de-identified OHCA extracts into station_ohca_registry_pseudonymized schema.

.DESCRIPTION
  Reads:   data\private\imports\incoming\*.csv
  Writes:  data\private\processed\station_ohca_registry_pseudonymized.csv

  Normalizes YES/NO fields + ints + fills ym from event_date_utc if missing.
  Supports delimiter: comma, semicolon, or TAB.

IMPORTANT:
  DO NOT publish/commit raw rows. Use suppressed KPI exports for sharing.

NOTE:
  Do NOT use variable $pid (conflicts with automatic read-only $PID in PowerShell).
#>

[CmdletBinding()]
param(
  [string] $InDir  = (Join-Path (Resolve-Path ".").Path "data\private\imports\incoming"),
  [string] $OutCsv = (Join-Path (Resolve-Path ".").Path "data\private\processed\station_ohca_registry_pseudonymized.csv"),
  [switch] $Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Read-CsvSmart([string]$Path) {
  $h = Get-Content -LiteralPath $Path -TotalCount 1 -ErrorAction SilentlyContinue
  if ([string]::IsNullOrWhiteSpace($h)) { return @() }

  $comma = ($h -split ',').Count
  $semi  = ($h -split ';').Count
  $tab   = ($h -split "`t").Count

  $delim = ','
  if ($semi -gt $comma -and $semi -ge $tab) { $delim = ';' }
  elseif ($tab -gt $comma -and $tab -gt $semi) { $delim = "`t" }

  return @(Import-Csv -LiteralPath $Path -Delimiter $delim)
}

function NeedCols([object[]]$rows, [string[]]$need, [string]$name) {
  $rows = @($rows)
  if ($rows.Count -lt 1) { throw ("{0}: 0 rows" -f $name) }
  $have = @(($rows | Select-Object -First 1).PSObject.Properties.Name)
  $miss = @($need | Where-Object { $have -notcontains $_ })
  if ($miss.Count -gt 0) { throw ("{0} missing columns: {1}" -f $name, ($miss -join ", ")) }
}

function To-YesNo([object]$v) {
  if ($null -eq $v) { return '' }
  $t = ([string]$v).Trim()
  if ([string]::IsNullOrWhiteSpace($t)) { return '' }
  if ($t -match '^(?i:true|1|yes|y)$')  { return 'YES' }
  if ($t -match '^(?i:false|0|no|n)$') { return 'NO' }
  return $t.ToUpperInvariant()
}

function Parse-Int([object]$v) {
  if ($null -eq $v) { return $null }
  $t = ([string]$v).Trim()
  if ([string]::IsNullOrWhiteSpace($t)) { return $null }
  $x = 0
  if ([int]::TryParse($t, [ref]$x)) { return $x }
  return $null
}

function Ym-FromIsoUtc([string]$iso) {
  if ([string]::IsNullOrWhiteSpace($iso)) { return '' }
  if ($iso.Length -ge 7 -and $iso.Substring(4,1) -eq '-') { return $iso.Substring(0,7) }
  return ''
}

New-Item -ItemType Directory -Force -Path (Split-Path $OutCsv -Parent) | Out-Null

$files = @(Get-ChildItem -LiteralPath $InDir -File -Filter *.csv -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -notlike "TEMPLATE_*" })

if ($files.Count -eq 0) {
  Write-Host "No PRIVATE imports found in: $InDir" -ForegroundColor Yellow
  Write-Host "Drop de-identified extracts there (same schema), then re-run:" -ForegroundColor Yellow
  Write-Host ("  & `"{0}`" -Force" -f $PSCommandPath) -ForegroundColor Yellow
  return
}

if ((Test-Path -LiteralPath $OutCsv) -and -not $Force) {
  throw "Output exists: $OutCsv  (use -Force to overwrite)"
}

$need = @(
  'pseudo_event_id','event_date_utc','ym','country','station_id','station_name',
  'aed_used','shocks_delivered','rosc_any','survival_to_discharge','ems_response_time_s','time_to_first_shock_s'
)

$all = New-Object "System.Collections.Generic.List[object]"

foreach ($f in $files) {
  Write-Host ("Importing: {0}" -f $f.FullName) -ForegroundColor Cyan
  $rows = Read-CsvSmart $f.FullName
  NeedCols $rows $need ("Import file " + $f.Name)

  foreach ($r in $rows) {
    # IMPORTANT: do NOT use $pid (conflicts with $PID). Use $eventId instead.
    $eventId = ([string]$r.pseudo_event_id).Trim()
    if ([string]::IsNullOrWhiteSpace($eventId)) {
      $eventId = "EVT_" + ([guid]::NewGuid().ToString("N").Substring(0,16))
    }

    $eventDate = ([string]$r.event_date_utc).Trim()
    $ym = ([string]$r.ym).Trim()
    if ([string]::IsNullOrWhiteSpace($ym)) { $ym = Ym-FromIsoUtc $eventDate }

    [void]$all.Add([pscustomobject]@{
      pseudo_event_id        = $eventId
      event_date_utc         = $eventDate
      ym                     = $ym
      country                = ([string]$r.country).Trim().ToUpperInvariant()
      station_id             = ([string]$r.station_id).Trim()
      station_name           = ([string]$r.station_name).Trim()
      aed_used               = (To-YesNo $r.aed_used)
      shocks_delivered       = (Parse-Int $r.shocks_delivered)
      rosc_any               = (To-YesNo $r.rosc_any)
      survival_to_discharge  = (To-YesNo $r.survival_to_discharge)
      ems_response_time_s    = (Parse-Int $r.ems_response_time_s)
      time_to_first_shock_s  = (Parse-Int $r.time_to_first_shock_s)
    })
  }
}

# de-dup by pseudo_event_id
$dedup = $all | Group-Object pseudo_event_id | ForEach-Object { $_.Group | Select-Object -First 1 }

$dedup | Sort-Object event_date_utc,pseudo_event_id | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $OutCsv
Write-Host ("Wrote PRIVATE merged registry: {0} (rows={1})" -f $OutCsv,(@($dedup).Count)) -ForegroundColor Green
