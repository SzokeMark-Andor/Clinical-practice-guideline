[CmdletBinding()]
param(
  [string]$RegistryCsv = (Join-Path (Resolve-Path ".").Path "data\private\station_ohca_registry.csv"),
  [string]$OutByStation= (Join-Path (Resolve-Path ".").Path "reports\ohca_by_station.csv"),
  [string]$OutByMonth  = (Join-Path (Resolve-Path ".").Path "reports\ohca_by_month.csv")
)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $RegistryCsv)) { throw "Missing registry: $RegistryCsv" }

$rows = Import-Csv -LiteralPath $RegistryCsv -Delimiter ','
if (@($rows).Count -eq 0) {
  Write-Host "Registry has no rows yet (fill it first)." -ForegroundColor Yellow
  return
}

function Norm([string]$s) {
  if ($null -eq $s) { return "" }
  return ($s.Trim())
}

# By station
$rows |
  Group-Object { Norm $_.station_name } |
  Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) } |
  ForEach-Object {
    $g = $_.Group
    [pscustomobject]@{
      station_name = $_.Name
      events_total = $_.Count
      aed_used     = (@($g | Where-Object { (Norm $_.public_access_aed_used) -match '^(?i)yes|true$' })).Count
      shock_deliv  = (@($g | Where-Object { [int]([double]::Parse((Norm $_.shocks_delivered) -replace '[^0-9]','0')) -gt 0 })).Count
      survival_30d = (@($g | Where-Object { (Norm $_.survival_to_discharge_30d) -match '^(?i)yes|true$' })).Count
    }
  } |
  Sort-Object events_total -Descending |
  Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $OutByStation

# By month
$rows |
  ForEach-Object {
    $d = $null
    try { $d = [datetime]::Parse((Norm $_.event_date_utc)).ToUniversalTime() } catch { $d = $null }
    $m = if ($d) { "{0:yyyy-MM}" -f $d } else { "" }
    [pscustomobject]@{ ym = $m; public_access_aed_used = (Norm $_.public_access_aed_used) }
  } |
  Where-Object { -not [string]::IsNullOrWhiteSpace($_.ym) } |
  Group-Object ym |
  ForEach-Object {
    $g = $_.Group
    [pscustomobject]@{
      ym          = $_.Name
      events_total= $_.Count
      aed_used    = (@($g | Where-Object { $_.public_access_aed_used -match '^(?i)yes|true$' })).Count
    }
  } |
  Sort-Object ym |
  Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $OutByMonth

Write-Host "Wrote:" -ForegroundColor Green
Write-Host "  $OutByStation"
Write-Host "  $OutByMonth"
