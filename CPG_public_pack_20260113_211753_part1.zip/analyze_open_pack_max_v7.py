import argparse, os, math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --------------------------
# Styling (journal-friendly)
# --------------------------
def setup_style():
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.dpi": 160,
        "savefig.dpi": 520,
        "font.family": "DejaVu Sans",
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.22,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.fancybox": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def pct(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def wilson_ci(k: int, n: int, z: float = 1.96):
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1.0 + (z*z)/n
    center = (p + (z*z)/(2*n)) / denom
    half = (z * math.sqrt((p*(1-p)/n) + (z*z)/(4*n*n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))

def savefig_all(fig, base_no_ext: str):
    # IMPORTANT: no plt.tight_layout() -> avoids colorbar/layout-engine conflicts
    fig.savefig(base_no_ext + ".png", bbox_inches="tight")
    fig.savefig(base_no_ext + ".pdf", bbox_inches="tight")
    fig.savefig(base_no_ext + ".svg", bbox_inches="tight")
    plt.close(fig)

def panel_letter(ax, letter: str):
    ax.text(
        0.01, 0.99, letter,
        transform=ax.transAxes,
        va="top", ha="left",
        fontsize=11, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="0.4", alpha=0.95)
    )

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    df["country_iso2"] = df["country_iso2"].astype(str).str.strip()
    df["station_kind"] = df["station_kind"].astype(str).str.strip()
    return df

def time_to_defib_min(dist_m: np.ndarray, walk_speed_mps: float, setup_s: float, retrieval_multiplier: float):
    # multiplier: 2.0=round-trip bystander fetch, 1.0=assisted/nearby responder (one-way-ish)
    return ((retrieval_multiplier * dist_m / walk_speed_mps) + setup_s) / 60.0

def ecdf_fraction(values: np.ndarray, x_max: float):
    """
    ECDF where y is fraction of ALL stations (denominator = total N),
    and we only plot finite values within x_max so the curve naturally ends <1 if coverage is poor.
    """
    x = np.asarray(values, dtype=float)
    N = int(x.size)
    finite = np.isfinite(x)
    inwin = finite & (x <= x_max)
    xs = np.sort(x[inwin])
    if xs.size == 0:
        return xs, np.array([], dtype=float), 0.0
    y = np.arange(1, xs.size + 1, dtype=float) / max(1, N)
    return xs, y, (xs.size / max(1, N))

def country_metrics(dist_arr: np.ndarray, iso2: pd.Series, max_dist_m: float, thr_m: float = 500.0) -> pd.DataFrame:
    rows = []
    iso = iso2.astype(str).str.strip()
    for c in sorted([x for x in iso.unique().tolist() if x and x != "nan"]):
        mask = (iso == c).to_numpy()
        dc = dist_arr[mask]
        n = int(dc.size)
        k = int(np.sum(np.isfinite(dc) & (dc <= thr_m)))
        lo, hi = wilson_ci(k, n)
        finite = np.isfinite(dc)
        med = float(np.nanmedian(dc[finite])) if np.any(finite) else np.nan
        q25 = float(np.nanquantile(dc[finite], 0.25)) if np.any(finite) else np.nan
        q75 = float(np.nanquantile(dc[finite], 0.75)) if np.any(finite) else np.nan
        miss = float(np.mean((~np.isfinite(dc)) | (dc > max_dist_m)))
        rows.append({
            "country_iso2": c,
            "stations_n": n,
            "p_leq_500m": (k/n) if n else np.nan,
            "pct_leq_500m": pct(k/n) if n else np.nan,
            "ci95_lo_pct": pct(lo) if np.isfinite(lo) else np.nan,
            "ci95_hi_pct": pct(hi) if np.isfinite(hi) else np.nan,
            "median_nearest_m_finite": np.round(med, 1) if np.isfinite(med) else np.nan,
            "q25_nearest_m_finite": np.round(q25, 1) if np.isfinite(q25) else np.nan,
            "q75_nearest_m_finite": np.round(q75, 1) if np.isfinite(q75) else np.nan,
            "pct_missing_or_gt2km": pct(miss),
        })
    return pd.DataFrame(rows)

def meta_quality_index(meta: pd.DataFrame) -> pd.DataFrame:
    m = meta.copy()
    if "country_iso2" not in m.columns:
        return pd.DataFrame()
    m["country_iso2"] = m["country_iso2"].astype(str).str.strip()
    m = m.set_index("country_iso2")

    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in m.columns]
    if not cols:
        return pd.DataFrame()

    mm = m[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
    mm["meta_quality_index"] = mm.mean(axis=1)
    return mm[["meta_quality_index"]].reset_index()

# --------------------------
# Draw functions (used by mono + dashboard)
# --------------------------
def draw_A_ecdf_distance(ax, d_all, d_rail, max_dist_m):
    # Pro background bands (subtle)
    bands = [
        (0, 100, 0.08),
        (100, 200, 0.06),
        (200, 500, 0.05),
        (500, max_dist_m, 0.03),
    ]
    for (a,b,alpha) in bands:
        ax.axvspan(a, b, alpha=alpha, color="#ffcc80")  # warm band

    xa, ya, frac_a = ecdf_fraction(d_all, max_dist_m)
    xr, yr, frac_r = ecdf_fraction(d_rail, max_dist_m)

    ax.step(xa, ya, where="post", linewidth=2.6, color="#ef6c00", label=f"All (≤{int(max_dist_m)}m: {pct(frac_a):.1f}%)")
    ax.step(xr, yr, where="post", linewidth=2.6, color="#1e88e5", label=f"Rail-ish (≤{int(max_dist_m)}m: {pct(frac_r):.1f}%)")

    # Threshold lines + TOP labels (what you asked)
    thr = [100, 200, 500, 1000, 2000]
    for t in thr:
        ax.axvline(t, linestyle="--", linewidth=1.3, color="0.35", alpha=0.8, zorder=1)
        ax.text(t, 0.985, f"{t}m", rotation=90, va="top", ha="right", fontsize=10, color="0.25")

    ax.set_xlim(0, max_dist_m)
    ax.set_ylim(0, 1.0)
    ax.set_title("Nearest AED distance ECDF")
    ax.set_xlabel("Distance (m)")
    ax.set_ylabel(f"ECDF (fraction of ALL stations within 0–{int(max_dist_m)} m)")
    ax.legend(loc="upper left")

def draw_B_ecdf_time(ax, dist, max_t=15.0, v=1.2, setup_s=60.0):
    # Background “target” zones
    ax.axvspan(0, 3, color="#a5d6a7", alpha=0.12)   # green-ish target
    ax.axvspan(3, 5, color="#fff59d", alpha=0.10)   # yellow caution
    ax.axvspan(5, max_t, color="#ffccbc", alpha=0.07)  # red-ish delay

    t_round = time_to_defib_min(dist, v, setup_s, 2.0)
    t_assist= time_to_defib_min(dist, v, setup_s, 1.0)

    xr, yr, fr = ecdf_fraction(t_round, max_t)
    xa, ya, fa = ecdf_fraction(t_assist, max_t)

    ax.step(xr, yr, where="post", linewidth=2.6, color="#ef6c00", label=f"Round-trip ×2 (≤{max_t:.0f}m: {pct(fr):.1f}%)")
    ax.step(xa, ya, where="post", linewidth=2.6, color="#1e88e5", label=f"Assisted ×1 (≤{max_t:.0f}m: {pct(fa):.1f}%)")

    # 3/5 min lines + TOP labels
    for thr in [3, 5]:
        ax.axvline(thr, linestyle="--", linewidth=1.4, color="0.35", alpha=0.85)
        ax.text(thr, 0.985, f"{thr} min", rotation=90, va="top", ha="right", fontsize=10, color="0.25")

    ax.set_xlim(0, max_t)
    ax.set_ylim(0, 1.0)
    ax.set_title("Estimated time-to-defib ECDF (baseline)")
    ax.set_xlabel("Minutes (retrieval + setup)")
    ax.set_ylabel("ECDF")
    ax.legend(loc="upper left")

def draw_C_heatmap(ax, df, dist, max_dist_m, thresholds=[100,200,300,500,1000,2000]):
    # rail-ish country coverage across thresholds
    cc = country_metrics(dist, df["country_iso2"], max_dist_m, thr_m=500.0)
    if cc.shape[0] == 0:
        ax.text(0.5,0.5,"No countries in subset", ha="center", va="center")
        return

    order = cc.sort_values("pct_leq_500m", ascending=False)["country_iso2"].tolist()
    M = []
    for c in order:
        mask = (df["country_iso2"].astype(str).str.strip().to_numpy() == c)
        dc = dist[mask]
        row = [pct(np.mean(np.isfinite(dc) & (dc <= t))) for t in thresholds]
        M.append(row)
    M = np.asarray(M, dtype=float)

    im = ax.imshow(M, aspect="auto", interpolation="nearest", cmap="magma", vmin=0, vmax=100)
    ax.set_yticks(np.arange(len(order)))
    ax.set_yticklabels(order)
    ax.set_xticks(np.arange(len(thresholds)))
    ax.set_xticklabels([f"≤{t}m" for t in thresholds], rotation=0)
    ax.set_title("Rail-ish — country coverage heatmap")
    ax.set_xlabel("Distance threshold")
    ax.set_ylabel("Country")
    return im

def draw_D_forest(ax, cc, title):
    if cc.shape[0] == 0:
        ax.text(0.5,0.5,"No countries", ha="center", va="center")
        return None
    d = cc.copy().sort_values("pct_leq_500m", ascending=False, kind="mergesort")
    y = np.arange(d.shape[0])

    x  = d["pct_leq_500m"].to_numpy(dtype=float)
    lo = d["ci95_lo_pct"].to_numpy(dtype=float)
    hi = d["ci95_hi_pct"].to_numpy(dtype=float)

    # CI lines
    for i in range(d.shape[0]):
        ax.hlines(y[i], lo[i], hi[i], color="0.55", lw=2.0, alpha=0.95, zorder=1)

    # Points colored by "missing/gt2km" to add information + color
    miss = d["pct_missing_or_gt2km"].to_numpy(dtype=float)
    sc = ax.scatter(x, y, c=miss, cmap="viridis", s=55, edgecolor="white", linewidth=0.7, zorder=2)

    ax.set_yticks(y)
    ax.set_yticklabels(d["country_iso2"].astype(str).tolist())
    ax.invert_yaxis()
    ax.set_xlim(0, max(10, float(np.nanmax(hi) + 5)))
    ax.set_xlabel("% ≤ 500 m (Wilson 95% CI)")
    ax.set_title(title)

    # station counts on the right
    xmax = ax.get_xlim()[1]
    for i, n in enumerate(d["stations_n"].tolist()):
        ax.text(xmax*0.985, y[i], f"n={n}", va="center", ha="right", fontsize=9.8, color="0.25")

    return sc

def draw_E_bubble(ax, cc, meta_q):
    # Bubble scatter: x=metadata quality, y=coverage<=500m, size~sqrt(n), color=missing/gt2km
    if cc.shape[0] == 0 or meta_q.shape[0] == 0:
        ax.text(0.5,0.5,"Missing metadata/coverage join", ha="center", va="center")
        return None

    tmp = cc.merge(meta_q, on="country_iso2", how="left").dropna()
    if tmp.shape[0] < 5:
        ax.text(0.5,0.5,"Too few countries with metadata", ha="center", va="center")
        return None

    x = tmp["meta_quality_index"].to_numpy(dtype=float)
    y = tmp["pct_leq_500m"].to_numpy(dtype=float)
    n = tmp["stations_n"].to_numpy(dtype=float)
    miss = tmp["pct_missing_or_gt2km"].to_numpy(dtype=float)
    s = np.sqrt(np.clip(n, 1, None)) * 18.0  # visible but not insane

    sc = ax.scatter(x, y, s=s, c=miss, cmap="plasma", alpha=0.9, edgecolor="white", linewidth=0.7)

    # regression line + Pearson r
    a, b = np.polyfit(x, y, 1)
    xx = np.linspace(float(np.min(x)), float(np.max(x)), 100)
    ax.plot(xx, a*xx + b, lw=2.2, color="#1565c0", alpha=0.9)

    r = float(np.corrcoef(x, y)[0,1])
    ax.text(0.02, 0.98, f"Pearson r = {r:.2f}", transform=ax.transAxes, va="top", ha="left",
            fontsize=10.5, bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="0.4", alpha=0.92))

    ax.set_title("Data quality vs coverage (bubble = √stations)")
    ax.set_xlabel("Metadata quality index (%)")
    ax.set_ylabel("% stations ≤ 500 m")
    return sc

def draw_F_clinical_heat(ax, dist, target_min=5.0, max_setup=180, subset_name="Rail-ish"):
    # Single strong plot: heatmap of % meeting target (round-trip),
    # with contour overlay for assisted model.
    setups = np.arange(0, max_setup+1, 10, dtype=float)
    speeds = np.arange(0.8, 1.61, 0.1, dtype=float)

    # matrices: rows=speeds, cols=setups
    M_round = np.zeros((speeds.size, setups.size), dtype=float)
    M_ass  = np.zeros((speeds.size, setups.size), dtype=float)

    for i, v in enumerate(speeds):
        for j, s in enumerate(setups):
            t_r = time_to_defib_min(dist, v, s, 2.0)
            t_a = time_to_defib_min(dist, v, s, 1.0)
            M_round[i, j] = pct(np.mean(np.isfinite(t_r) & (t_r <= target_min)))
            M_ass[i, j]   = pct(np.mean(np.isfinite(t_a) & (t_a <= target_min)))

    im = ax.imshow(
        M_round,
        aspect="auto",
        origin="lower",
        interpolation="nearest",
        cmap="viridis",
        vmin=0, vmax=max(10, float(np.nanmax(M_ass)) + 5)
    )

    # Contours for assisted
    X, Y = np.meshgrid(setups, speeds)
    cs = ax.contour(X, Y, M_ass, levels=[2, 5, 10, 15, 20], colors="white", linewidths=1.2, alpha=0.95)
    ax.clabel(cs, fmt="%d%%", inline=True, fontsize=9.5)

    ax.set_title(f"Clinical sensitivity — % meeting ≤{int(target_min)} min ({subset_name})")
    ax.set_xlabel("Setup time (s)")
    ax.set_ylabel("Walking speed (m/s)")
    ax.set_xticks(np.arange(0, setups.size, 3))
    ax.set_xticklabels([f"{int(setups[k])}" for k in range(0, setups.size, 3)])
    ax.set_yticks(np.arange(0, speeds.size, 2))
    ax.set_yticklabels([f"{speeds[k]:.1f}" for k in range(0, speeds.size, 2)])

    # legend-like note
    ax.text(
        0.02, 0.02,
        "Heat = Round-trip ×2\nWhite contours = Assisted ×1",
        transform=ax.transAxes,
        va="bottom", ha="left",
        fontsize=10,
        bbox=dict(boxstyle="round,pad=0.28", fc="white", ec="0.4", alpha=0.92)
    )
    return im

def stacked_bins_by_country(df, dist, max_dist_m, outpath_base, topn=12):
    # Complex “pro” plot: stacked composition of distance bins per country
    # bins chosen to match actionable thresholds
    bins = np.array([0,100,200,300,500,1000,2000,np.inf], dtype=float)
    labels = ["0–100","100–200","200–300","300–500","500–1000","1000–2000",">2000/missing"]

    iso = df["country_iso2"].astype(str).str.strip().to_numpy()
    countries, counts = np.unique(iso, return_counts=True)
    # choose top by station count (subset)
    order = countries[np.argsort(counts)[::-1]][:topn].tolist()

    mat = []
    for c in order:
        mask = (iso == c)
        dc = dist[mask]
        dc2 = dc.copy()
        dc2[~np.isfinite(dc2)] = np.inf
        hist = []
        for i in range(len(bins)-1):
            lo, hi = bins[i], bins[i+1]
            if np.isinf(hi):
                hist.append(float(np.mean(dc2 >= lo)))
            else:
                hist.append(float(np.mean((dc2 >= lo) & (dc2 < hi))))
        mat.append(hist)

    M = np.asarray(mat, dtype=float) * 100.0

    fig = plt.figure(figsize=(11.5, 6.5), constrained_layout=True)
    ax = fig.add_subplot(111)

    left = np.zeros(len(order), dtype=float)
    cmap = plt.get_cmap("magma")
    colors = [cmap(x) for x in np.linspace(0.15, 0.92, len(labels))]

    for i, lab in enumerate(labels):
        ax.barh(order, M[:, i], left=left, color=colors[i], edgecolor="white", linewidth=0.5, label=lab)
        left += M[:, i]

    ax.set_xlim(0, 100)
    ax.set_xlabel("Percent of stations")
    ax.set_title("Rail-ish subset — distance-bin composition (top countries by station count)")
    ax.legend(ncol=2, loc="lower right", framealpha=0.92)
    savefig_all(fig, outpath_base)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--fig_dir", required=True)
    ap.add_argument("--max_dist_m", type=float, default=2000.0)
    ap.add_argument("--pairs_max_m", type=float, default=500.0)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    setup_style()

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    fig_dir = os.path.abspath(args.fig_dir)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")

    must_exist(p_summary); must_exist(p_meta)

    df   = read_summary(p_summary)
    meta = pd.read_csv(p_meta, low_memory=True)
    meta_q = meta_quality_index(meta)

    # Distances: inf for missing
    d_all = df["nearest_aed_m"].to_numpy(dtype=float)
    d_all[~np.isfinite(d_all)] = np.inf

    railish = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_rail = df[df["station_kind"].isin(railish)].copy()
    d_rail = df_rail["nearest_aed_m"].to_numpy(dtype=float)
    d_rail[~np.isfinite(d_rail)] = np.inf

    # fallback if rail-ish empty
    use_df = df_rail if df_rail.shape[0] > 0 else df
    use_dist = d_rail if df_rail.shape[0] > 0 else d_all
    subset_name = "Rail-ish" if df_rail.shape[0] > 0 else "All (fallback)"

    # Country metrics for forest/scatter
    cc_all  = country_metrics(d_all,  df["country_iso2"], args.max_dist_m, thr_m=500.0)
    cc_rail = country_metrics(use_dist, use_df["country_iso2"], args.max_dist_m, thr_m=500.0)

    cc_all.to_csv(os.path.join(out_dir, "country_metrics_500m_all.csv"), index=False)
    cc_rail.to_csv(os.path.join(out_dir, "country_metrics_500m_subset.csv"), index=False)

    # --------------------------
    # MONO FIGURES (big + manuscript-ready)
    # --------------------------
    # A
    fig = plt.figure(figsize=(11.2, 6.6), constrained_layout=True)
    ax = fig.add_subplot(111)
    draw_A_ecdf_distance(ax, d_all, use_dist, args.max_dist_m)
    panel_letter(ax, "A")
    savefig_all(fig, os.path.join(fig_dir, "FigA_ecdf_distance_all_vs_subset_pro"))

    # B
    fig = plt.figure(figsize=(11.2, 6.6), constrained_layout=True)
    ax = fig.add_subplot(111)
    draw_B_ecdf_time(ax, use_dist, max_t=15.0, v=1.2, setup_s=60.0)
    panel_letter(ax, "B")
    savefig_all(fig, os.path.join(fig_dir, "FigB_ecdf_time_baseline_subset_pro"))

    # C
    fig = plt.figure(figsize=(11.2, 7.2), constrained_layout=True)
    ax = fig.add_subplot(111)
    im = draw_C_heatmap(ax, use_df, use_dist, args.max_dist_m)
    panel_letter(ax, "C")
    if im is not None:
        cbar = fig.colorbar(im, ax=ax, shrink=0.92)
        cbar.set_label("% stations within threshold")
    savefig_all(fig, os.path.join(fig_dir, "FigC_country_coverage_heatmap_subset_pro"))

    # D
    fig = plt.figure(figsize=(11.2, max(7.0, 0.35*max(10, cc_rail.shape[0]) + 2.0)), constrained_layout=True)
    ax = fig.add_subplot(111)
    sc = draw_D_forest(ax, cc_rail, f"Coverage within 500 m (Wilson 95% CI) — {subset_name}")
    panel_letter(ax, "D")
    if sc is not None:
        cbar = fig.colorbar(sc, ax=ax, shrink=0.92)
        cbar.set_label("% missing or >2 km")
    savefig_all(fig, os.path.join(fig_dir, "FigD_forest_coverage500m_subset_pro"))

    # E
    fig = plt.figure(figsize=(11.2, 6.8), constrained_layout=True)
    ax = fig.add_subplot(111)
    sc2 = draw_E_bubble(ax, cc_rail, meta_q)
    panel_letter(ax, "E")
    if sc2 is not None:
        cbar = fig.colorbar(sc2, ax=ax, shrink=0.92)
        cbar.set_label("% missing or >2 km")
    savefig_all(fig, os.path.join(fig_dir, "FigE_bubble_quality_vs_coverage_pro"))

    # F (new: single heatmap + contours; no zoom)
    fig = plt.figure(figsize=(11.2, 6.8), constrained_layout=True)
    ax = fig.add_subplot(111)
    im2 = draw_F_clinical_heat(ax, use_dist, target_min=5.0, max_setup=180, subset_name=subset_name)
    panel_letter(ax, "F")
    cbar = fig.colorbar(im2, ax=ax, shrink=0.92)
    cbar.set_label("% meeting ≤5 min (round-trip ×2)")
    savefig_all(fig, os.path.join(fig_dir, "FigF_clinical_sensitivity_heatmap_pro"))

    # Extra complex “pro” plot (stacked distance-bin composition)
    stacked_bins_by_country(
        use_df, use_dist, args.max_dist_m,
        os.path.join(fig_dir, "FigX_stacked_distance_bins_top_countries_pro"),
        topn=12
    )

    # --------------------------
    # DASHBOARD (2x3) — like your v6, but cleaner A/B top labels and new F
    # --------------------------
    fig = plt.figure(figsize=(18.5, 10.5), constrained_layout=True)
    gs = fig.add_gridspec(2, 3)

    axA = fig.add_subplot(gs[0,0]); draw_A_ecdf_distance(axA, d_all, use_dist, args.max_dist_m); panel_letter(axA, "A")
    axB = fig.add_subplot(gs[0,1]); draw_B_ecdf_time(axB, use_dist, max_t=15.0, v=1.2, setup_s=60.0); panel_letter(axB, "B")
    axC = fig.add_subplot(gs[0,2]); imC = draw_C_heatmap(axC, use_df, use_dist, args.max_dist_m); panel_letter(axC, "C")
    if imC is not None:
        cbar = fig.colorbar(imC, ax=axC, shrink=0.86)
        cbar.set_label("%")

    axD = fig.add_subplot(gs[1,0]); scD = draw_D_forest(axD, cc_rail, "Coverage within 500 m (Wilson 95% CI)"); panel_letter(axD, "D")
    if scD is not None:
        cbar = fig.colorbar(scD, ax=axD, shrink=0.86)
        cbar.set_label("% missing/>2 km")

    axE = fig.add_subplot(gs[1,1]); scE = draw_E_bubble(axE, cc_rail, meta_q); panel_letter(axE, "E")
    if scE is not None:
        cbar = fig.colorbar(scE, ax=axE, shrink=0.86)
        cbar.set_label("% missing/>2 km")

    axF = fig.add_subplot(gs[1,2]); imF = draw_F_clinical_heat(axF, use_dist, target_min=5.0, max_setup=180, subset_name=subset_name); panel_letter(axF, "F")
    cbar = fig.colorbar(imF, ax=axF, shrink=0.86)
    cbar.set_label("% ≤5 min (×2)")

    fig.suptitle("OpenStreetMap AED proximity audit — rail-station environments (dashboard)\n"
                 f"Subset focus: {subset_name}", fontsize=16, fontweight="bold")
    savefig_all(fig, os.path.join(fig_dir, "Fig0_AUDIT_DASHBOARD_open_pack_max_v7"))

    # --------------------------
    # Report notes (v7)
    # --------------------------
    n_total = int(df.shape[0])
    n_subset = int(use_df.shape[0])

    overall_all = {
        "pct_leq_200m": pct(np.mean(np.isfinite(d_all) & (d_all <= 200))),
        "pct_leq_500m": pct(np.mean(np.isfinite(d_all) & (d_all <= 500))),
        "pct_leq_2km":  pct(np.mean(np.isfinite(d_all) & (d_all <= args.max_dist_m))),
        "pct_missing_or_gt2km": pct(np.mean((~np.isfinite(d_all)) | (d_all > args.max_dist_m))),
    }
    overall_sub = {
        "pct_leq_200m": pct(np.mean(np.isfinite(use_dist) & (use_dist <= 200))),
        "pct_leq_500m": pct(np.mean(np.isfinite(use_dist) & (use_dist <= 500))),
        "pct_leq_2km":  pct(np.mean(np.isfinite(use_dist) & (use_dist <= args.max_dist_m))),
        "pct_missing_or_gt2km": pct(np.mean((~np.isfinite(use_dist)) | (use_dist > args.max_dist_m))),
    }

    rep = []
    rep.append("# OPEN PACK (MAX) — Manuscript Analytics v7\n")
    rep.append(f"- Stations (all kinds): **{n_total:,}**")
    rep.append(f"- Stations (subset = {subset_name}): **{n_subset:,}**\n")
    rep.append("## Coverage summary\n")
    rep.append("All station kinds:")
    rep.append(f"- ≤200 m: **{overall_all['pct_leq_200m']:.2f}%**")
    rep.append(f"- ≤500 m: **{overall_all['pct_leq_500m']:.2f}%**")
    rep.append(f"- ≤2 km:  **{overall_all['pct_leq_2km']:.2f}%**")
    rep.append(f"- missing/>2 km: **{overall_all['pct_missing_or_gt2km']:.2f}%**\n")
    rep.append(f"Subset ({subset_name}):")
    rep.append(f"- ≤200 m: **{overall_sub['pct_leq_200m']:.2f}%**")
    rep.append(f"- ≤500 m: **{overall_sub['pct_leq_500m']:.2f}%**")
    rep.append(f"- ≤2 km:  **{overall_sub['pct_leq_2km']:.2f}%**")
    rep.append(f"- missing/>2 km: **{overall_sub['pct_missing_or_gt2km']:.2f}%**\n")
    rep.append("## Figures written (PNG+PDF+SVG)\n")
    for f in [
        "Fig0_AUDIT_DASHBOARD_open_pack_max_v7",
        "FigA_ecdf_distance_all_vs_subset_pro",
        "FigB_ecdf_time_baseline_subset_pro",
        "FigC_country_coverage_heatmap_subset_pro",
        "FigD_forest_coverage500m_subset_pro",
        "FigE_bubble_quality_vs_coverage_pro",
        "FigF_clinical_sensitivity_heatmap_pro",
        "FigX_stacked_distance_bins_top_countries_pro",
    ]:
        rep.append(f"- `{f}.[png|pdf|svg]`")
    rep_path = os.path.join(out_dir, "REPORT_open_pack_max_v7.md")
    with open(rep_path, "w", encoding="utf-8") as fp:
        fp.write("\n".join(rep))

    print("DONE")
    print("OUT_DIR:", out_dir)
    print("FIG_DIR:", fig_dir)
    print("REPORT:", rep_path)

if __name__ == "__main__":
    main()
