# OPEN PACK (MAX) — Manuscript Analytics v6

- Stations rows (all kinds): **140,175**
- Stations rows (rail-ish subset): **31,700**
- Missing / >2000 m (all): **61.79%**
- Missing / >2000 m (Rail-ish): **77.22%**

## Baseline time-to-defib (subset used in dashboard)
- Round-trip ×2: % ≤3 min = **3.83%**, % ≤5 min = **6.02%**
- Assisted ×1:   % ≤3 min = **6.02%**, % ≤5 min = **8.99%**

## Distance limits implied by time targets (heuristic)
| scenario   | mode            |   dmax_3min_m |   dmax_5min_m |
|:-----------|:----------------|--------------:|--------------:|
| baseline   | round-trip (×2) |            72 |           144 |
| baseline   | assisted (×1)   |           144 |           288 |
| slower     | round-trip (×2) |            45 |           105 |
| slower     | assisted (×1)   |            90 |           210 |

## Best vs worst countries (≤500 m coverage; subset used in dashboard)
Top 5:
| country_iso2   |   stations_n |   pct_leq_500m |   ci95_lo_pct |   ci95_hi_pct |   pct_missing_or_gt2km |
|:---------------|-------------:|---------------:|--------------:|--------------:|-----------------------:|
| CH             |         1935 |          71.06 |         69    |         73.04 |                   6.05 |
| IE             |          164 |          53.05 |         45.43 |         60.53 |                  14.63 |
| NL             |          594 |          51.35 |         47.33 |         55.34 |                  19.87 |
| BE             |          715 |          40    |         36.47 |         43.64 |                  31.19 |
| DK             |          602 |          37.71 |         33.93 |         41.65 |                  42.36 |

Bottom 5:
| country_iso2   |   stations_n |   pct_leq_500m |   ci95_lo_pct |   ci95_hi_pct |   pct_missing_or_gt2km |
|:---------------|-------------:|---------------:|--------------:|--------------:|-----------------------:|
| CO             |          168 |           0    |          0    |          2.24 |                  98.21 |
| VN             |          333 |           0    |          0    |          1.14 |                  99.7  |
| TR             |         1396 |           0    |          0    |          0.27 |                  99.93 |
| MX             |          560 |           0.18 |          0.03 |          1    |                  97.68 |
| RO             |         2085 |           0.19 |          0.07 |          0.49 |                  99.47 |

## Figures
- Fig0_AUDIT_DASHBOARD_open_pack_max_v6.[png|pdf|svg]