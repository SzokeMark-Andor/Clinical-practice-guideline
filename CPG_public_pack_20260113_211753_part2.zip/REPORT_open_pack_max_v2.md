# OPEN PACK (MAX) — Manuscript Analytics v2

- Countries present: **30**
- Stations rows: **140,175**

## Clinical timing interpretation (round-trip retrieval model)
- Early defibrillation is time-critical; guideline targets often aim for shock within a few minutes of collapse.

**baseline** (v=1.20 m/s, setup=60s):
- max distance for **3 min** target ≈ **72 m**
- max distance for **5 min** target ≈ **144 m**

**slower** (v=1.00 m/s, setup=90s):
- max distance for **3 min** target ≈ **45 m**
- max distance for **5 min** target ≈ **105 m**

## Files written (key)
- `overall_thresholds_all_station_kinds.csv`, `overall_thresholds_railish_only.csv`
- `country_metrics_all_station_kinds.csv`, `country_metrics_railish_only.csv`
- `medical_time_thresholds_allstations_scenarios.csv`

## Figures (PNG+PDF+SVG)
- `figA_ecdf_distance_allstations_with_thresholds.[png|pdf|svg]`
- `figB_ecdf_time_to_defib_allstations_scenarios.[png|pdf|svg]`
- `figC_forest_500m_all_station_kinds.[png|pdf|svg]`
- `figC2_forest_500m_railish_only.[png|pdf|svg]`
- `figD_dumbbell_median_iqr_all_station_kinds.[png|pdf|svg]`
- `figE_scatter_median_vs_coverage_500m.[png|pdf|svg]`
- `figF_metadata_completeness_heatmap_sorted.[png|pdf|svg]`