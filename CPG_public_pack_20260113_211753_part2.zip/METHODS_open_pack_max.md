# Methods – OpenStreetMap (OSM) station/AED open-data pack (MAX / expanded)

Generated: 2026-01-11 18:52:58

## Data source and access
- OpenStreetMap (OSM) data retrieved via Overpass API.
- Country area selection uses ISO3166-1 lookup via rea[...] if present, otherwise the country boundary relation is mapped to an Overpass area (map_to_area).
- We request nodes/ways/relations ("nwr") and use "out body center" so that ways/relations include a representative "center" coordinate for distance calculations.
- Raw Overpass JSON responses are cached under: _overpass_raw/
- The full Overpass QL queries used are recorded in: OVERPASS_QUERIES_used.txt

## Country scope
- Seed ISO2 list is taken from:
  C:\Users\szoke\Documents\CPG\reports\open_evidence_pack\open_top30_pack\open_station_summary_top30_countries.csv
- Because the seed list contains fewer than 30 unique ISO2 and some countries can yield 0 stations (or fail due to Overpass limits),
  the script iterates over a candidate pool and selects the first 30 ISO2 that yield at least 1 station elements.
- The final selected list is written to:
  SELECTED_COUNTRIES_iso2_top30_max.txt

## Station/stops definition (expanded)
- railway=station
- railway=halt
- railway=stop
- railway=platform
- railway=tram_stop
- railway=subway_entrance (optional)
- public_transport=station
- public_transport=stop_area
- public_transport=platform
- public_transport=stop_position
Note: To reduce non-rail inflation, the default configuration restricts PT stop_area/platform/stop_position to elements that also include a "railway" tag key (PtRailOnly=true).

## AED definition (expanded)
- emergency=defibrillator
- emergency=aed (older tagging exists in some areas)
- defibrillator=yes (AED mapped at another object)
- amenity=defibrillator (optional legacy)

## Derived outputs
- open_osm_stations_elements_top30_max.csv: raw harvested station/stops elements + tags_json.
- open_osm_aeds_elements_top30_max.csv: raw harvested AED elements + tags_json.
- open_station_summary_top30_countries_max.csv: per-station summary including nearest AED distance and the count of AEDs within PairMaxDistM.
- open_pairs_top30_countries_max.csv: station-to-AED pairs within PairMaxDistM (or nearest-only if configured).
- open_counts_station_kind_top30_max.csv / open_counts_aed_kind_top30_max.csv: counts by type categories.
- open_metadata_coverage_top30_max.csv: completeness of key tags by country.

## OSM attribution / license note
- Publications should include attribution such as "(c) OpenStreetMap contributors" and comply with the ODbL.
