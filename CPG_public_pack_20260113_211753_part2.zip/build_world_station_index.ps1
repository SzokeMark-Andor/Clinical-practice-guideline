[CmdletBinding()]
param(
  # Choose which continent extracts to process (default: all)
  [string[]]$Regions = @(
    "europe","asia","africa","north-america","south-america","australia-oceania","antarctica"
  ),

  # Refresh downloads if older than this (hours). Set 0 to always redownload.
  [int]$RefreshHours = 168,

  # Include tram stops (can be huge). Default OFF.
  [switch]$IncludeTramStops,

  # Output locations
  [string]$WorldCsv = (Join-Path (Resolve-Path ".").Path "data\osm_world\world_stations.csv"),
  [string]$CountsCsv= (Join-Path (Resolve-Path ".").Path "reports\world_station_counts.csv")
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Require-Cmd([string]$name) {
  $cmd = Get-Command $name -ErrorAction SilentlyContinue
  if (-not $cmd) { throw "Missing dependency: '$name'. Install osmium-tool and ensure 'osmium' is on PATH." }
  return $cmd.Source
}

function CacheValid([string]$p, [int]$ttlHours) {
  if (-not (Test-Path -LiteralPath $p)) { return $false }
  if ($ttlHours -le 0) { return $false }
  $age = (Get-Date) - (Get-Item -LiteralPath $p).LastWriteTime
  return ($age.TotalHours -lt $ttlHours)
}

function Download-File([string]$url, [string]$dest, [int]$ttlHours) {
  $dir = Split-Path -Parent $dest
  New-Item -ItemType Directory -Force -Path $dir | Out-Null

  if (CacheValid $dest $ttlHours) {
    Write-Host "Cached: $dest" -ForegroundColor DarkGray
    return
  }

  Write-Host "Downloading: $url" -ForegroundColor Cyan
  try {
    if (Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue) {
      Start-BitsTransfer -Source $url -Destination $dest -TransferType Download -ErrorAction Stop
    } else {
      Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -ErrorAction Stop
    }
  } catch {
    throw "Download failed: $url -> $dest : $($_.Exception.Message)"
  }
}

# Minimal CSV writer (streaming; avoids huge memory)
function Csv-Escape([string]$s) {
  if ($null -eq $s) { return "" }
  $s2 = [string]$s
  if ($s2 -match '[,"\r\n]') { return '"' + ($s2 -replace '"','""') + '"' }
  return $s2
}

function Avg([double[]]$xs) {
  if (-not $xs -or $xs.Count -eq 0) { return $null }
  return ($xs | Measure-Object -Average).Average
}

function Get-CentroidFromGeometry($geom) {
  # Handles Point / LineString / Polygon / Multi* by averaging all coordinates (approx centroid)
  if ($null -eq $geom) { return $null }

  $type = [string]$geom.type
  $coords = $geom.coordinates

  $lons = New-Object System.Collections.Generic.List[double]
  $lats = New-Object System.Collections.Generic.List[double]

  function Add-Coord($pt) {
    if ($null -eq $pt -or $pt.Count -lt 2) { return }
    [void]$lons.Add([double]$pt[0])
    [void]$lats.Add([double]$pt[1])
  }

  switch ($type) {
    "Point" { Add-Coord $coords }
    "LineString" { foreach ($pt in $coords) { Add-Coord $pt } }
    "Polygon" { foreach ($ring in $coords) { foreach ($pt in $ring) { Add-Coord $pt } } }
    "MultiLineString" { foreach ($line in $coords) { foreach ($pt in $line) { Add-Coord $pt } } }
    "MultiPolygon" { foreach ($poly in $coords) { foreach ($ring in $poly) { foreach ($pt in $ring) { Add-Coord $pt } } } }
    default {
      # best effort
      try {
        foreach ($pt in $coords) { Add-Coord $pt }
      } catch { }
    }
  }

  $lon = Avg($lons.ToArray())
  $lat = Avg($lats.ToArray())
  if ($null -eq $lon -or $null -eq $lat) { return $null }
  return [pscustomobject]@{ lon = $lon; lat = $lat }
}

$osmium = Require-Cmd "osmium"

$root = (Resolve-Path ".").Path
$pbfDir     = Join-Path $root "data\osm_world\pbf"
$workDir    = Join-Path $root "data\osm_world\_work"
$outDir     = Split-Path -Parent $WorldCsv
New-Item -ItemType Directory -Force -Path $pbfDir, $workDir, $outDir, (Split-Path -Parent $CountsCsv) | Out-Null

# Geofabrik continent extracts (latest)
$catalog = @{
  "europe"            = "https://download.geofabrik.de/europe-latest.osm.pbf"
  "asia"              = "https://download.geofabrik.de/asia-latest.osm.pbf"
  "africa"            = "https://download.geofabrik.de/africa-latest.osm.pbf"
  "north-america"     = "https://download.geofabrik.de/north-america-latest.osm.pbf"
  "south-america"     = "https://download.geofabrik.de/south-america-latest.osm.pbf"
  "australia-oceania" = "https://download.geofabrik.de/australia-oceania-latest.osm.pbf"
  "antarctica"        = "https://download.geofabrik.de/antarctica-latest.osm.pbf"
}

# Station selectors (rail + metro tend to use railway=station; halts are common too)
$selectors = @(
  "nwr/railway=station",
  "nwr/railway=halt",
  "nwr/public_transport=station"
)
if ($IncludeTramStops) {
  $selectors += "nwr/railway=tram_stop"
}

# Prep output CSV (world)
$worldHeader = @(
  "extract","osm_type","osm_id","name","railway","public_transport","station","network","operator","ref","wheelchair","website",
  "lon","lat"
) -join ","
Set-Content -LiteralPath $WorldCsv -Encoding UTF8 -Value ($worldHeader + "`r`n")

$counts = New-Object System.Collections.Generic.List[object]

foreach ($region in $Regions) {
  if (-not $catalog.ContainsKey($region)) {
    Write-Warning "Unknown region '$region' (skip). Allowed: $($catalog.Keys -join ', ')"
    continue
  }

  $url  = $catalog[$region]
  $pbf  = Join-Path $pbfDir "$region-latest.osm.pbf"
  Download-File -url $url -dest $pbf -ttlHours $RefreshHours

  # 1) Filter stations to a small PBF
  $filtered = Join-Path $workDir "stations_$region.osm.pbf"
  if (-not (CacheValid $filtered 24)) {
    Write-Host "Filtering stations ($region)..." -ForegroundColor Cyan
    & $osmium tags-filter $pbf @selectors -o $filtered -O --overwrite | Out-Null
  } else {
    Write-Host "Cached filtered: $filtered" -ForegroundColor DarkGray
  }

  # 2) Export to GeoJSON sequence if supported; else fallback to GeoJSON (warning: big)
  $help = & $osmium export -h 2>&1 | Out-String
  $fmt = if ($help -match "(?i)geojsonseq") { "geojsonseq" } else { "geojson" }

  $gj = Join-Path $workDir "stations_$region.$fmt"
  if (-not (CacheValid $gj 24)) {
    Write-Host "Exporting ($region) -> $fmt..." -ForegroundColor Cyan
    & $osmium export $filtered -f $fmt -o $gj -O --overwrite | Out-Null
  } else {
    Write-Host "Cached export: $gj" -ForegroundColor DarkGray
  }

  # 3) Stream-parse GeoJSONSeq (line-delimited features). If geojson fallback, it may be too large.
  $n = 0
  $named = 0

  $sw = New-Object System.IO.StreamWriter($WorldCsv, $true, [System.Text.Encoding]::UTF8)

  try {
    if ($fmt -eq "geojsonseq") {
      Get-Content -LiteralPath $gj | ForEach-Object {
        $line = $_
        if ([string]::IsNullOrWhiteSpace($line)) { return }
        $feat = $null
        try { $feat = $line | ConvertFrom-Json } catch { return }

        $id = [string]$feat.id
        $props = $feat.properties

        $name = ""
        if ($null -ne $props) { $name = [string]$props.name }
        if (-not [string]::IsNullOrWhiteSpace($name)) { $named++ }

        $railway = if ($props) { [string]$props.railway } else { "" }
        $pt      = if ($props) { [string]$props.public_transport } else { "" }
        $station = if ($props) { [string]$props.station } else { "" }
        $network = if ($props) { [string]$props.network } else { "" }
        $oper    = if ($props) { [string]$props.operator } else { "" }
        $ref     = if ($props) { [string]$props.ref } else { "" }
        $wh      = if ($props) { [string]$props.wheelchair } else { "" }
        $web     = if ($props) { [string]$props.website } else { "" }

        $geom = $feat.geometry
        $cent = Get-CentroidFromGeometry $geom
        $lon  = if ($cent) { "{0:F6}" -f $cent.lon } else { "" }
        $lat  = if ($cent) { "{0:F6}" -f $cent.lat } else { "" }

        # id is like "node/123" or "way/..." in osmium export
        $osmType = ""
        $osmId   = ""
        if ($id -match "^(node|way|relation)\/(\d+)$") { $osmType = $Matches[1]; $osmId = $Matches[2] }

        $row = @(
          (Csv-Escape $region),
          (Csv-Escape $osmType),
          (Csv-Escape $osmId),
          (Csv-Escape $name),
          (Csv-Escape $railway),
          (Csv-Escape $pt),
          (Csv-Escape $station),
          (Csv-Escape $network),
          (Csv-Escape $oper),
          (Csv-Escape $ref),
          (Csv-Escape $wh),
          (Csv-Escape $web),
          $lon,
          $lat
        ) -join ","

        $sw.WriteLine($row)
        $n++
      }
    } else {
      Write-Warning "Export format 'geojson' detected. This can be huge; prefer an osmium version that supports geojsonseq."
      # Best-effort: skip parsing rather than blowing memory.
    }
  }
  finally {
    $sw.Flush()
    $sw.Close()
  }

  $counts.Add([pscustomobject]@{
    extract_region = $region
    stations_total = $n
    stations_named = $named
    selectors      = ($selectors -join " ")
  }) | Out-Null

  Write-Host ("Done region={0} stations={1} named={2}" -f $region,$n,$named) -ForegroundColor Green
}

# Write counts
$counts | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $CountsCsv
Write-Host "`nWORLD outputs:" -ForegroundColor Cyan
Write-Host ("  {0}" -f $WorldCsv)
Write-Host ("  {0}" -f $CountsCsv)

