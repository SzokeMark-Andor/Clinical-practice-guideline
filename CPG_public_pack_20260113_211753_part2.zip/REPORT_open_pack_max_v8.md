# OPEN PACK (MAX) — Manuscript Analytics v8

- Stations rows (all kinds): **140,175**
- Stations rows (rail-ish): **31,700**

## Key outputs

- Dashboard: `Fig0_AUDIT_DASHBOARD_open_pack_max_v8.[png|pdf|svg]`
- Medical compound: `FigM_medical_compound_survival_time_opportunity_pro.[png|pdf|svg]`
- Pro distribution: `FigX_stacked_distance_bins_top_countries_pro.[png|pdf|svg]`

## Notes

- Time-to-defib models are **heuristic sensitivity analyses** (round-trip vs assisted retrieval; walking speed + setup time).
- Survival decay curves are **illustrative envelopes** (not patient-level predictions).
