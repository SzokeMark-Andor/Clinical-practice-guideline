# Figure captions (draft)

**Fig0_AUDIT_DASHBOARD_open_pack_max_v8** — Dashboard summary: (A) nearest AED distance ECDF (0–2 km window); (B) baseline time-to-defibrillation ECDF (round-trip vs assisted); (C) rail-ish country heatmap across thresholds; (D) country coverage within 500 m with Wilson 95% CI; (E) data-quality vs coverage bubble plot; (F) clinical sensitivity curves (% meeting ≤5 min) across setup time, walking speeds, and retrieval models.

**FigA_ecdf_distance_all_vs_railish_pro** — Nearest AED distance ECDF (0–2 km window) comparing all station kinds vs rail-ish subset; dashed lines mark key distance thresholds.

**FigB_time_to_defib_ecdf_baseline_pro** — Estimated time-to-defibrillation ECDF under baseline assumptions (v=1.2 m/s, setup=60 s), comparing round-trip vs assisted retrieval models; 3- and 5-minute reference lines shown.

**FigC_heatmap_country_coverage_thresholds_railish_pro** — Rail-ish subset: per-country coverage heatmap (% of stations with nearest AED within each distance threshold), sorted by coverage within 500 m.

**FigD_forest_coverage500m_railish_pro** — Rail-ish subset: coverage within 500 m with Wilson 95% confidence intervals; points colored by % missing or >2 km; station counts annotated.

**FigE_data_quality_vs_coverage_bubble_pro** — Country-level association between metadata quality (mean tag completeness) and AED coverage within 500 m; bubble size reflects station counts; colors reflect % missing or >2 km; Pearson correlation shown.

**FigF_clinical_sensitivity_lines_5min_railish_pro** — Clinical sensitivity (rail-ish): percent of stations meeting a ≤5-minute time-to-defibrillation target as a function of setup time, walking speed, and retrieval model (round-trip vs assisted).

**FigX_stacked_distance_bins_top_countries_pro** — Rail-ish subset: stacked distance-bin composition for top countries by station count, showing the distribution of nearest AED distances across clinically relevant bins.

**FigM_medical_compound_survival_time_opportunity_pro** — Medical compound figure (heuristic): survival-decay envelopes vs time-to-shock, time-to-defib ECDF across operational scenarios, and the resulting expected opportunity index under two decay assumptions (CPR-like vs no-CPR-like).

