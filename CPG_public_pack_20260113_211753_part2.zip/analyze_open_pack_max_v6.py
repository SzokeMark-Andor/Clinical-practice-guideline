import argparse, os, math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# --------------------------
# Styling (journal-friendly)
# --------------------------
def setup_style():
    plt.rcParams.update({
        "figure.dpi": 160,
        "savefig.dpi": 500,
        "font.family": "DejaVu Sans",
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.22,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.fancybox": True,
        "pdf.fonttype": 42,  # embed TrueType
        "ps.fonttype": 42,
    })

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def pct(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def wilson_ci(k: int, n: int, z: float = 1.96):
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1.0 + (z*z)/n
    center = (p + (z*z)/(2*n)) / denom
    half = (z * math.sqrt((p*(1-p)/n) + (z*z)/(4*n*n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))

def ecdf_xy(values: np.ndarray):
    x = np.asarray(values, dtype=float)
    x = x[~np.isnan(x)]
    x = np.sort(x)
    y = np.arange(1, x.size + 1, dtype=float) / max(1, x.size)
    return x, y

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    df["country_iso2"] = df["country_iso2"].astype(str).str.strip()
    df["station_kind"] = df["station_kind"].astype(str).str.strip()
    return df

def time_to_defib_min(dist_m: np.ndarray, walk_speed_mps: float, setup_s: float, mult: float):
    # mult=2.0 => round-trip bystander fetch ; mult=1.0 => assisted/nearby responder heuristic
    return ((mult * dist_m / walk_speed_mps) + setup_s) / 60.0

def dmax_for_target_minutes(t_min: float, v_mps: float, setup_s: float, mult: float):
    # t = (mult*d/v + setup)/60 => d = ((t*60 - setup) * v) / mult
    return max(0.0, ((t_min*60.0 - setup_s) * v_mps) / max(1e-9, mult))

def savefig_all(fig, base_no_ext: str):
    # IMPORTANT: no tight_layout() here (prevents the colorbar/layout-engine crash you hit in v3)
    fig.savefig(base_no_ext + ".png", bbox_inches="tight")
    fig.savefig(base_no_ext + ".pdf", bbox_inches="tight")
    fig.savefig(base_no_ext + ".svg", bbox_inches="tight")
    plt.close(fig)

def add_panel_letter(ax, letter: str):
    ax.text(
        0.01, 0.98, letter,
        transform=ax.transAxes, va="top", ha="left",
        fontsize=12, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="0.7", alpha=0.95)
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--fig_dir", required=True)
    ap.add_argument("--max_dist_m", type=float, default=2000.0)
    ap.add_argument("--pairs_max_m", type=float, default=500.0)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    setup_style()
    rng = np.random.default_rng(args.seed)

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    fig_dir = os.path.abspath(args.fig_dir)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")
    p_cad     = os.path.join(in_dir, "open_counts_aed_kind_top30_max.csv")
    p_cst     = os.path.join(in_dir, "open_counts_station_kind_top30_max.csv")

    must_exist(p_summary); must_exist(p_meta)
    # counts are optional for v6 dashboard
    df   = read_summary(p_summary)
    meta = pd.read_csv(p_meta, low_memory=True)

    # Distances (inf for missing/too-far so ECDF can plateau below 1.0 in-window)
    d_all = df["nearest_aed_m"].to_numpy(dtype=float)
    d_all = np.where(np.isfinite(d_all), d_all, np.inf)

    railish = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_rail = df[df["station_kind"].isin(railish)].copy()
    d_rail  = df_rail["nearest_aed_m"].to_numpy(dtype=float)
    d_rail  = np.where(np.isfinite(d_rail), d_rail, np.inf)

    # Prefer rail-ish for “clinical” panels; fall back to all if empty
    use_rail = (df_rail.shape[0] > 0)
    d_use = d_rail if use_rail else d_all
    df_use = df_rail if use_rail else df
    subset_label = "Rail-ish" if use_rail else "All"

    # Country coverage within 500m (+ CI) helper
    def country_cov(dist_arr: np.ndarray, iso2: pd.Series, thr_m: float = 500.0):
        rows = []
        for c in sorted([x for x in iso2.unique().tolist() if x and x != "nan"]):
            mask = (iso2 == c).to_numpy()
            dc = dist_arr[mask]
            n = int(dc.size)
            k = int(np.sum(dc <= thr_m))
            lo, hi = wilson_ci(k, n)
            finite = np.isfinite(dc)
            med = float(np.nanmedian(dc[finite])) if np.any(finite) else np.nan
            q25 = float(np.nanquantile(dc[finite], 0.25)) if np.any(finite) else np.nan
            q75 = float(np.nanquantile(dc[finite], 0.75)) if np.any(finite) else np.nan
            rows.append({
                "country_iso2": c,
                "stations_n": n,
                "pct_leq_500m": pct(k/n) if n else np.nan,
                "ci95_lo_pct": pct(lo) if np.isfinite(lo) else np.nan,
                "ci95_hi_pct": pct(hi) if np.isfinite(hi) else np.nan,
                "median_m_finite": np.round(med, 1) if np.isfinite(med) else np.nan,
                "q25_m_finite": np.round(q25, 1) if np.isfinite(q25) else np.nan,
                "q75_m_finite": np.round(q75, 1) if np.isfinite(q75) else np.nan,
                "pct_missing_or_gt2km": pct(np.mean(dc > args.max_dist_m)),
            })
        return pd.DataFrame(rows)

    cc_all  = country_cov(d_all,  df["country_iso2"])
    cc_use  = country_cov(d_use,  df_use["country_iso2"])

    cc_all.to_csv(os.path.join(out_dir, "country_coverage_500m_all_station_kinds.csv"), index=False)
    cc_use.to_csv(os.path.join(out_dir, f"country_coverage_500m_{subset_label.lower().replace('-','')}.csv"), index=False)

    # Metadata quality index
    meta2 = meta.copy()
    if "country_iso2" in meta2.columns:
        meta2["country_iso2"] = meta2["country_iso2"].astype(str).str.strip()
        meta2 = meta2.set_index("country_iso2")

    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in meta2.columns]
    meta_index = None
    if cols:
        mm = meta2[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        mm["meta_quality_index"] = mm.mean(axis=1)
        meta_index = mm[["meta_quality_index"]].copy()
        meta_index.to_csv(os.path.join(out_dir, "metadata_quality_index_by_country.csv"))

    # --------------------------
    # DASHBOARD FIGURE (A–F)
    # --------------------------
    fig = plt.figure(figsize=(20.5, 11.6), constrained_layout=True)
    gs  = GridSpec(
        2, 3, figure=fig,
        width_ratios=[1.05, 1.28, 1.25],   # make B+E wider
        height_ratios=[1.00, 1.05]
    )

    axA = fig.add_subplot(gs[0,0])
    axB = fig.add_subplot(gs[0,1])
    axC = fig.add_subplot(gs[0,2])
    axD = fig.add_subplot(gs[1,0])
    axE = fig.add_subplot(gs[1,1])
    axF = fig.add_subplot(gs[1,2])

    fig.suptitle(
        f"OpenStreetMap AED proximity audit — rail-station environments (dashboard)\n"
        f"Subset focus: {subset_label}",
        fontsize=16, fontweight="bold"
    )

    # Palette (warm + cool)
    col_all  = "#f39c12"  # warm orange
    col_rail = "#3fa9f5"  # blue
    col_dark = "#c0392b"  # deep red

    # ---- A) Distance ECDF (All vs Rail-ish)
    def ecdf_inwindow(dist_arr):
        # Replace inf with a value just beyond window so ECDF plateaus below 1 within xlim
        dplot = dist_arr.copy()
        dplot = np.where(np.isfinite(dplot), dplot, args.max_dist_m * 1.05)
        x, y = ecdf_xy(dplot)
        return x, y

    x1, y1 = ecdf_inwindow(d_all)
    axA.step(x1, y1, where="post", lw=2.4, color=col_all, label=f"All (missing/> {int(args.max_dist_m)}m: {pct(np.mean(d_all>args.max_dist_m)):.1f}%)")
    if use_rail:
        x2, y2 = ecdf_inwindow(d_rail)
        axA.step(x2, y2, where="post", lw=2.4, color=col_rail, label=f"Rail-ish (missing/> {int(args.max_dist_m)}m: {pct(np.mean(d_rail>args.max_dist_m)):.1f}%)")

    for t in [50,75,100,150,200,300,500,1000,2000]:
        axA.axvline(t, ls="--", lw=1, color="0.4", alpha=0.55)

    axA.set_xlim(0, args.max_dist_m)
    axA.set_ylim(0, 1)
    axA.set_title("Nearest AED distance ECDF")
    axA.set_xlabel("Distance (m)")
    axA.set_ylabel(f"ECDF (0–{int(args.max_dist_m)} m window)")
    axA.grid(True, alpha=0.25)
    axA.legend(loc="lower right")
    add_panel_letter(axA, "A")

    # ---- B) Time-to-defib ECDF (baseline) — show round-trip vs assisted
    v0, setup0 = 1.2, 60.0
    t_round = time_to_defib_min(d_use, v0, setup0, 2.0)
    t_ass   = time_to_defib_min(d_use, v0, setup0, 1.0)

    def ecdf_time_inwindow(tmin):
        tplot = np.where(np.isfinite(tmin), tmin, 999.0)  # push inf beyond axis
        x, y = ecdf_xy(tplot)
        return x, y

    xR, yR = ecdf_time_inwindow(t_round)
    xA2,yA2= ecdf_time_inwindow(t_ass)

    axB.step(xR, yR, where="post", lw=2.4, color=col_all,  label=f"Round-trip ×2 ({subset_label})")
    axB.step(xA2,yA2,where="post", lw=2.4, color=col_rail, label=f"Assisted ×1 ({subset_label})")

    for thr in [3, 5]:
        axB.axvline(thr, ls="--", lw=1.2, color="0.35", alpha=0.7)
        axB.text(thr+0.08, 0.92 if thr==3 else 0.84, f"{thr} min", color="0.25", fontsize=11)

    axB.set_xlim(0, 15)
    axB.set_ylim(0, 1)
    axB.set_title("Estimated time-to-defib ECDF (baseline)")
    axB.set_xlabel("Minutes (retrieval + setup)\n(baseline v=1.2 m/s, setup=60 s)")
    axB.set_ylabel("ECDF")
    axB.tick_params(axis="x", labelsize=11)
    axB.grid(True, alpha=0.25)
    axB.legend(loc="lower right")
    add_panel_letter(axB, "B")

    # ---- C) Country coverage heatmap across thresholds (use rail-ish if available)
    thr_cols = [100, 200, 300, 500, 1000, 2000]
    cc_hm = cc_use.copy()
    if cc_hm.shape[0] > 0:
        countries_sorted = cc_hm.sort_values("pct_leq_500m", ascending=False)["country_iso2"].tolist()
        M = []
        for c in countries_sorted:
            mask = (df_use["country_iso2"].to_numpy() == c)
            dc = d_use[mask]
            row = [pct(np.mean(dc <= t)) for t in thr_cols]
            M.append(row)
        M = np.asarray(M, dtype=float)

        im = axC.imshow(M, aspect="auto", interpolation="nearest", cmap="magma", vmin=0, vmax=100)
        axC.set_xticks(np.arange(len(thr_cols)))
        axC.set_xticklabels([f"≤{t}m" for t in thr_cols], rotation=0)
        axC.set_yticks(np.arange(len(countries_sorted)))
        axC.set_yticklabels(countries_sorted)
        axC.set_title(f"{subset_label} — country coverage heatmap")
        cbar = fig.colorbar(im, ax=axC, fraction=0.046, pad=0.02)
        cbar.set_label("% stations within threshold")
        add_panel_letter(axC, "C")
    else:
        axC.axis("off")

    # ---- D) Forest plot: coverage within 500 m (Wilson 95% CI)
    dff = cc_use.copy().sort_values("pct_leq_500m", ascending=False, kind="mergesort")
    y = np.arange(dff.shape[0])

    x = dff["pct_leq_500m"].to_numpy(dtype=float)
    lo = dff["ci95_lo_pct"].to_numpy(dtype=float)
    hi = dff["ci95_hi_pct"].to_numpy(dtype=float)
    xerr = np.vstack([x - lo, hi - x])

    axD.errorbar(x, y, xerr=xerr, fmt="o", capsize=2, elinewidth=1.6, color=col_all, ecolor=col_dark)
    axD.set_yticks(y)
    axD.set_yticklabels(dff["country_iso2"].astype(str).tolist())
    axD.invert_yaxis()
    axD.set_xlim(0, max(10, float(np.nanmax(hi) + 5)))
    axD.set_xlabel("% ≤ 500 m (Wilson 95% CI)")
    axD.set_title("Coverage within 500 m (Wilson 95% CI)")
    axD.grid(True, axis="x", alpha=0.25)

    # annotate n
    xmax = axD.get_xlim()[1]
    for i, n in enumerate(dff["stations_n"].tolist()):
        axD.text(xmax * 0.985, i, f"n={n}", va="center", ha="right", fontsize=10, color="0.35")

    add_panel_letter(axD, "D")

    # ---- E) Data quality vs coverage (color by missing/>2km, size by station count)
    if meta_index is not None and meta_index.shape[0] > 0:
        tmp = cc_use.set_index("country_iso2").join(meta_index, how="left").dropna()
        if tmp.shape[0] >= 5:
            xs = tmp["meta_quality_index"].to_numpy(dtype=float)
            ys = tmp["pct_leq_500m"].to_numpy(dtype=float)
            cs = tmp["pct_missing_or_gt2km"].to_numpy(dtype=float)
            ss = np.sqrt(tmp["stations_n"].clip(lower=1).to_numpy(dtype=float)) * 10.0

            sc = axE.scatter(xs, ys, c=cs, s=ss, cmap="viridis", alpha=0.88, edgecolor="white", linewidth=0.6)
            # regression line
            a, b = np.polyfit(xs, ys, 1)
            xx = np.linspace(float(np.min(xs)), float(np.max(xs)), 120)
            axE.plot(xx, a*xx + b, lw=2.2, color="#4aa3df", alpha=0.95)

            # correlation annotation
            r = float(np.corrcoef(xs, ys)[0,1])
            axE.text(0.02, 0.96, f"Pearson r = {r:.2f}", transform=axE.transAxes,
                     ha="left", va="top", fontsize=11,
                     bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="0.75", alpha=0.95))

            axE.set_title("Data quality vs coverage")
            axE.set_xlabel("Metadata quality index (%)\n(mean tag completeness across station + AED fields)")
            axE.set_ylabel("% ≤ 500 m")
            axE.tick_params(axis="x", labelsize=11)
            axE.grid(True, alpha=0.25)

            cbar = fig.colorbar(sc, ax=axE, fraction=0.046, pad=0.02)
            cbar.set_label(f"% missing or >{int(args.max_dist_m)} m")
            add_panel_letter(axE, "E")
        else:
            axE.axis("off")
    else:
        axE.axis("off")

    # ---- F) Clinical sensitivity (5-min target) — FIXED: readable via zoom inset + scenario styling
    # Setup axis is still 0–100% (honest), but we add a zoom inset for low percentages.
    setups = np.arange(0, 181, 10, dtype=float)

    scenarios = [
        ("Baseline v=1.2", 1.2,  "#f39c12"),
        ("Slower v=1.0",   1.0,  "#e67e22"),
        ("Fast v=1.5",     1.5,  "#3fa9f5"),
    ]
    modes = [
        ("Round-trip ×2", 2.0, "-"),
        ("Assisted ×1",   1.0, "--"),
    ]

    # subtle band for typical “setup” guess range
    axF.axvspan(45, 90, color="#dfefff", alpha=0.45, zorder=0)
    axF.text(0.98, 0.98, "Shaded: typical setup band\n(~45–90 s)", transform=axF.transAxes,
             ha="right", va="top", fontsize=10, color="0.35",
             bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="0.8", alpha=0.9))

    # compute + plot
    all_series = []
    for scen_name, v, color in scenarios:
        for mode_name, mult, ls in modes:
            yvals = []
            for s in setups:
                t = time_to_defib_min(d_use, v, s, mult)
                yvals.append(pct(np.mean(t <= 5.0)))
            yvals = np.asarray(yvals, dtype=float)
            all_series.append(yvals)
            axF.plot(setups, yvals, ls=ls, lw=2.2, color=color,
                     marker="o" if mult==2.0 else None, markevery=3, ms=4.2,
                     label=f"{scen_name} — {mode_name}")

    axF.set_title("Clinical sensitivity (5-min target)")
    axF.set_xlabel("Setup time (s)")
    axF.set_ylabel("% stations meeting ≤ 5 min")
    axF.set_xlim(0, 180)
    axF.set_ylim(0, 100)  # keep honest global scale
    axF.grid(True, alpha=0.25)
    axF.legend(loc="upper right", fontsize=10)
    add_panel_letter(axF, "F")

    # inset zoom: show the informative low-percent region
    ymax = float(np.nanmax(np.vstack(all_series)))
    zoom_top = min(25.0, max(8.0, ymax * 1.35))  # auto zoom cap
    axins = inset_axes(axF, width="52%", height="46%", loc="lower left", borderpad=1.2)
    for (scen_name, v, color) in scenarios:
        for (mode_name, mult, ls) in modes:
            yvals = []
            for s in setups:
                t = time_to_defib_min(d_use, v, s, mult)
                yvals.append(pct(np.mean(t <= 5.0)))
            yvals = np.asarray(yvals, dtype=float)
            axins.plot(setups, yvals, ls=ls, lw=2.0, color=color, alpha=0.95)

    axins.axvspan(45, 90, color="#dfefff", alpha=0.55, zorder=0)
    axins.set_xlim(0, 180)
    axins.set_ylim(0, zoom_top)
    axins.set_title(f"Zoom (0–{zoom_top:.0f}%)", fontsize=10)
    axins.grid(True, alpha=0.22)
    axins.tick_params(labelsize=9)

    # Save dashboard
    outbase = os.path.join(fig_dir, "Fig0_AUDIT_DASHBOARD_open_pack_max_v6")
    savefig_all(fig, outbase)

    # --------------------------
    # Write a short report (v6)
    # --------------------------
    n_total = int(df.shape[0])
    n_rail  = int(df_rail.shape[0])
    miss_all = pct(np.mean(d_all > args.max_dist_m))
    miss_use = pct(np.mean(d_use > args.max_dist_m))

    # time-to-defib thresholds for baseline
    p3_round = pct(np.mean(t_round <= 3.0))
    p5_round = pct(np.mean(t_round <= 5.0))
    p3_ass   = pct(np.mean(t_ass   <= 3.0))
    p5_ass   = pct(np.mean(t_ass   <= 5.0))

    limits = []
    for label, v, setup_s in [("baseline",1.2,60.0), ("slower",1.0,90.0)]:
        for mult in [2.0, 1.0]:
            mode = "round-trip (×2)" if mult==2.0 else "assisted (×1)"
            limits.append({
                "scenario": label,
                "mode": mode,
                "dmax_3min_m": int(round(dmax_for_target_minutes(3, v, setup_s, mult))),
                "dmax_5min_m": int(round(dmax_for_target_minutes(5, v, setup_s, mult))),
            })
    limits_df = pd.DataFrame(limits)

    top5 = cc_use.sort_values("pct_leq_500m", ascending=False).head(5)[["country_iso2","stations_n","pct_leq_500m","ci95_lo_pct","ci95_hi_pct","pct_missing_or_gt2km"]]
    bot5 = cc_use.sort_values("pct_leq_500m", ascending=True).head(5)[["country_iso2","stations_n","pct_leq_500m","ci95_lo_pct","ci95_hi_pct","pct_missing_or_gt2km"]]

    rep = []
    rep.append("# OPEN PACK (MAX) — Manuscript Analytics v6")
    rep.append("")
    rep.append(f"- Stations rows (all kinds): **{n_total:,}**")
    rep.append(f"- Stations rows (rail-ish subset): **{n_rail:,}**")
    rep.append(f"- Missing / >{int(args.max_dist_m)} m (all): **{miss_all:.2f}%**")
    rep.append(f"- Missing / >{int(args.max_dist_m)} m ({subset_label}): **{miss_use:.2f}%**")
    rep.append("")
    rep.append("## Baseline time-to-defib (subset used in dashboard)")
    rep.append(f"- Round-trip ×2: % ≤3 min = **{p3_round:.2f}%**, % ≤5 min = **{p5_round:.2f}%**")
    rep.append(f"- Assisted ×1:   % ≤3 min = **{p3_ass:.2f}%**, % ≤5 min = **{p5_ass:.2f}%**")
    rep.append("")
    rep.append("## Distance limits implied by time targets (heuristic)")
    rep.append(limits_df.to_markdown(index=False))
    rep.append("")
    rep.append("## Best vs worst countries (≤500 m coverage; subset used in dashboard)")
    rep.append("Top 5:")
    rep.append(top5.to_markdown(index=False))
    rep.append("")
    rep.append("Bottom 5:")
    rep.append(bot5.to_markdown(index=False))
    rep.append("")
    rep.append("## Figures")
    rep.append("- Fig0_AUDIT_DASHBOARD_open_pack_max_v6.[png|pdf|svg]")

    rep_path = os.path.join(out_dir, "REPORT_open_pack_max_v6.md")
    with open(rep_path, "w", encoding="utf-8") as f:
        f.write("\n".join(rep))

    print("DONE")
    print("OUT_DIR:", out_dir)
    print("FIG_DIR:", fig_dir)
    print("REPORT:", rep_path)

if __name__ == "__main__":
    main()
