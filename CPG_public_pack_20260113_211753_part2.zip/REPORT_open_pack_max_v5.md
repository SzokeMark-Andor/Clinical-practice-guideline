# OPEN PACK (MAX) — Manuscript Analytics v5

- Stations rows (all kinds): **140,175**
- Stations rows (rail-ish subset): **31,700**

## Coverage summary (all station kinds)
- % with nearest AED ≤ 200 m: **11.79%**
- % with nearest AED ≤ 500 m: **20.83%**
- % with nearest AED ≤ 2 km:  **38.21%**
- % missing or >2 km:         **61.79%**

## Key figures written (PNG+PDF+SVG)
- `Fig0_AUDIT_DASHBOARD_open_pack_max_v5.[png|pdf|svg]`
- `Fig1_ecdf_distance_all_vs_railish.[png|pdf|svg]`
- `Fig2_ecdf_time_to_defib_baseline.[png|pdf|svg]`
- `Fig3_country_coverage_heatmap.[png|pdf|svg]`
- `Fig4_forest_coverage500m.[png|pdf|svg]`
- `Fig5_quality_vs_coverage.[png|pdf|svg]`
- `Fig6_clinical_sensitivity_5min_vs_setup.[png|pdf|svg]`