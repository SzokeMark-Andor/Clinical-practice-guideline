# OPEN PACK (MAX) — Manuscript Analytics v3

- Stations rows (all kinds): **140,175**
- Stations rows (rail-ish subset): **31,700**

## Coverage summary (all station kinds)

- % with nearest AED ≤ 200 m: **11.79%**
- % with nearest AED ≤ 500 m: **20.83%**
- % with nearest AED ≤ 2 km:  **38.21%**
- % missing or >2 km:         **61.79%**

## Coverage summary (rail-ish subset)

- % with nearest AED ≤ 200 m: **7.22%**
- % with nearest AED ≤ 500 m: **12.09%**
- % with nearest AED ≤ 2 km:  **22.78%**
- % missing or >2 km:         **77.22%**

## Clinical distance limits implied by time targets (heuristic)

| scenario | mode | dmax_3min_m | dmax_5min_m |
| --- | --- | --- | --- |
| baseline | round-trip (x2) | 72 | 144 |
| baseline | assisted (x1) | 144 | 288 |
| slower | round-trip (x2) | 45 | 105 |
| slower | assisted (x1) | 90 | 210 |

## Best vs worst countries (≤500 m coverage; all station kinds)

Top 5:
| country_iso2 | stations_n | pct_leq_500m | ci95_lo_pct | ci95_hi_pct | pct_no_aed_within_2km |
| --- | --- | --- | --- | --- | --- |
| CH | 10641 | 79.78 | 79.0 | 80.53 | 3.85 |
| NL | 5956 | 55.96 | 54.7 | 57.22 | 10.36 |
| IE | 1059 | 55.81 | 52.8 | 58.77 | 9.07 |
| BE | 6853 | 55.25 | 54.07 | 56.42 | 16.71 |
| DK | 3032 | 40.27 | 38.54 | 42.03 | 35.78 |

Bottom 5:
| country_iso2 | stations_n | pct_leq_500m | ci95_lo_pct | ci95_hi_pct | pct_no_aed_within_2km |
| --- | --- | --- | --- | --- | --- |
| CO | 281 | 0.0 | 0.0 | 1.35 | 98.93 |
| VN | 593 | 0.0 | 0.0 | 0.64 | 99.83 |
| TR | 5505 | 0.0 | 0.0 | 0.07 | 99.89 |
| MX | 1222 | 0.25 | 0.08 | 0.72 | 96.73 |
| KR | 5210 | 0.42 | 0.28 | 0.64 | 95.2 |

## Files written

- coverage thresholds: `coverage_thresholds_all_station_kinds.csv`, `coverage_thresholds_railish_only.csv`
- country coverage + CI: `country_coverage_500m_all_station_kinds.csv`, `country_coverage_500m_railish_only.csv`
- clinical sensitivity grids: `clinical_sensitivity_grid_*.csv`
- figure captions: `FIGURE_CAPTIONS_open_pack_max_v3.md`
- survival opportunity index: `survival_opportunity_index_by_country_baseline_roundtrip.csv`