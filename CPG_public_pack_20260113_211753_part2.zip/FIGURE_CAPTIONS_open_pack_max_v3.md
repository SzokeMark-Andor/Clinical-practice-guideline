# Figure captions (draft)

**Fig1_ecdf_distance_all_vs_railish** — Nearest AED distance ECDF (OpenStreetMap audit). Comparison between all station kinds and a stricter rail-ish subset. Dashed lines mark actionable distance thresholds.

**Fig2_heatmap_country_coverage_thresholds_railish** — Rail-ish subset: per-country coverage heatmap (% of stations with nearest AED within each distance threshold). Countries sorted by ≤500 m coverage.

**Fig3_forest_coverage500m_railish** — Rail-ish subset: country-level coverage within 500 m with Wilson 95% confidence intervals; station counts annotated.

**Fig3b_forest_coverage500m_all** — All station kinds: country-level coverage within 500 m with Wilson 95% confidence intervals; station counts annotated.

**Fig4_clinical_sensitivity_heatmaps_all_station_kinds** — Clinical sensitivity: percent of stations meeting 3-min and 5-min time-to-defibrillation targets across walking speed and setup-time grids, under round-trip vs assisted retrieval models.

**Fig5_scatter_metadata_quality_vs_coverage** — Association between metadata quality (mean tag completeness) and AED coverage within 500 m (country-level).

**Fig6_pairs_likely_public_access_top15** — Among station→AED pairs within 500 m, share with access tags indicating likely public availability (heuristic).

**Fig7_station_kind_distribution_top14** — Distribution of station kinds (top categories) in the station summary table.

**Fig8_aed_kind_distribution_top12** — Distribution of AED tag kinds (top categories) from AED counts.

**Fig9_survival_opportunity_index_top20** — Heuristic survival opportunity index by country under a baseline round-trip model, using a mid-point 4%/min decay concept.

