import argparse, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.ticker as mticker

def setup_style():
    plt.rcParams.update({
        "figure.dpi": 150,
        "savefig.dpi": 450,
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.20,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.fancybox": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

def ecdf(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    x = np.sort(x)
    y = np.arange(1, len(x)+1)/max(1, len(x))
    return x, y

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", required=True)
    ap.add_argument("--out",  required=True)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    setup_style()

    df = pd.read_excel(args.xlsx)
    # expected columns (from your file):
    # pseudo_event_id,event_date_utc,ym,country,station_id,station_name,aed_used,shocks_delivered,
    # rosc_any,survival_to_discharge,ems_response_time_s,time_to_first_shock_s

    d = df.copy()
    d["dt"] = pd.to_datetime(d["event_date_utc"], utc=True, errors="coerce")
    d["year_month"] = d["dt"].dt.to_period("M").astype(str)
    d["hour"] = d["dt"].dt.hour
    d["weekday"] = d["dt"].dt.dayofweek
    weekday_names = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
    d["weekday_name"] = d["weekday"].map(lambda i: weekday_names[i] if pd.notna(i) else None)

    d["ems_response_time_s"]   = pd.to_numeric(d["ems_response_time_s"], errors="coerce")
    d["time_to_first_shock_s"] = pd.to_numeric(d["time_to_first_shock_s"], errors="coerce")
    d["shocks_delivered"]      = pd.to_numeric(d["shocks_delivered"], errors="coerce").fillna(0).astype(int)

    d["rosc_yes"]  = (d["rosc_any"].astype(str).str.upper()=="YES")
    d["surv_yes"]  = (d["survival_to_discharge"].astype(str).str.upper()=="YES")
    d["shock_given"] = (d["shocks_delivered"]>0)

    monthly = d.groupby("year_month").agg(
        events=("pseudo_event_id","size"),
        shock_given=("shock_given","mean"),
        rosc=("rosc_yes","mean"),
        survival=("surv_yes","mean"),
        med_shock_min=("time_to_first_shock_s", lambda s: np.nanmedian(s)/60.0),
        med_ems_min=("ems_response_time_s", lambda s: np.nanmedian(s)/60.0),
    ).reset_index()
    monthly["ym_period"] = pd.PeriodIndex(monthly["year_month"], freq="M")
    monthly = monthly.sort_values("ym_period")

    heat = d.pivot_table(index="weekday_name", columns="hour", values="pseudo_event_id", aggfunc="size", fill_value=0)
    heat = heat.reindex(weekday_names)
    heat_mat = heat.to_numpy(dtype=float)

    station = d.groupby(["country","station_id"]).agg(
        n=("pseudo_event_id","size"),
        survival=("surv_yes","mean"),
        rosc=("rosc_yes","mean"),
        shock_given=("shock_given","mean"),
        med_shock_min=("time_to_first_shock_s", lambda s: np.nanmedian(s)/60.0),
        med_ems_min=("ems_response_time_s", lambda s: np.nanmedian(s)/60.0),
    ).reset_index()
    station["station_label"] = station.apply(lambda r: f"{r['country']}:{str(r['station_id'])[-6:]}", axis=1)
    topN = station.sort_values("n", ascending=False).head(30).copy()

    # ECDF panel
    t_shock_min = d["time_to_first_shock_s"].to_numpy(dtype=float)/60.0
    tmax = 15.0
    t_clip = np.clip(t_shock_min, 0, tmax)
    x_all, y_all   = ecdf(t_clip)
    x_sh,  y_sh    = ecdf(np.clip(d.loc[d["shock_given"],"time_to_first_shock_s"].to_numpy(float)/60.0, 0, tmax))
    x_nsh, y_nsh   = ecdf(np.clip(d.loc[~d["shock_given"],"time_to_first_shock_s"].to_numpy(float)/60.0, 0, tmax))

    # Time bins panel
    bins = [0,3,5,8,10,15,1e9]
    bin_labels = ["≤3","3–5","5–8","8–10","10–15",">15"]
    d["tbin"] = pd.cut(t_shock_min, bins=bins, labels=bin_labels, right=True, include_lowest=True)
    tb = d.groupby("tbin", observed=True).agg(
        n=("pseudo_event_id","size"),
        rosc=("rosc_yes","mean"),
        survival=("surv_yes","mean")
    ).reindex(bin_labels)

    # Cascade
    N_total = len(d)
    cascade = [
        ("OHCA events", N_total),
        ("Shock delivered (≥1)", int(d["shock_given"].sum())),
        ("ROSC (any)", int(d["rosc_yes"].sum())),
        ("Survival to discharge", int(d["surv_yes"].sum()))
    ]

    # === FIG R0: Dashboard ===
    fig = plt.figure(figsize=(18,10), constrained_layout=True)
    gs = GridSpec(2, 3, figure=fig, width_ratios=[1.05,1.05,1.15], height_ratios=[1,1])
    axA = fig.add_subplot(gs[0,0])
    axB = fig.add_subplot(gs[0,1])
    axC = fig.add_subplot(gs[0,2])
    axD = fig.add_subplot(gs[1,0])
    axE = fig.add_subplot(gs[1,1])
    axF = fig.add_subplot(gs[1,2])

    fig.suptitle("Rail-station OHCA registry (pseudonymized) — time-to-first shock, shocks, and outcomes (dashboard)",
                 fontsize=16, fontweight="bold")

    # A: monthly
    axA.grid(True)
    axA.plot(monthly["ym_period"].astype(str), monthly["events"], linewidth=2.2, marker="o", markersize=3.5)
    axA.set_title("Monthly case volume")
    axA.set_ylabel("Events (count)")
    axA.set_xlabel("Year-month")
    axA.tick_params(axis="x", rotation=45, labelsize=9)
    axA.yaxis.set_major_locator(mticker.MaxNLocator(6))
    axA2 = axA.twinx()
    axA2.plot(monthly["ym_period"].astype(str), 100*monthly["survival"], linewidth=2.0, linestyle="--", alpha=0.9, label="Survival %")
    axA2.plot(monthly["ym_period"].astype(str), 100*monthly["rosc"], linewidth=2.0, linestyle="-.", alpha=0.9, label="ROSC %")
    axA2.set_ylabel("Rate (%)")
    axA2.set_ylim(0, max(10, float(np.nanmax([100*monthly["survival"].max(), 100*monthly["rosc"].max()])+5)))
    axA2.legend(loc="upper right", fontsize=9)

    # B: ECDF
    axB.grid(True)
    axB.step(x_all, y_all, where="post", linewidth=2.2, label="All cases")
    axB.step(x_sh,  y_sh,  where="post", linewidth=2.0, label="Shock delivered (≥1)")
    axB.step(x_nsh, y_nsh, where="post", linewidth=2.0, linestyle="--", label="No shock delivered")
    for t, lab in [(3,"3 min"),(5,"5 min")]:
        axB.axvline(t, linestyle=":", linewidth=2.0, alpha=0.8)
        axB.text(t+0.12, 0.92, lab, fontsize=9, alpha=0.85)
    axB.set_xlim(0, tmax); axB.set_ylim(0,1)
    axB.set_title("Time-to-first shock ECDF (clipped at 15 min)")
    axB.set_xlabel("Minutes from collapse to first shock (retrieval + setup)")
    axB.set_ylabel("ECDF")
    axB.legend(loc="lower right", fontsize=9)

    # C: heatmap
    im = axC.imshow(heat_mat, aspect="auto", interpolation="nearest", cmap="magma")
    axC.set_title("Temporal pattern (counts): weekday × hour (UTC)")
    axC.set_yticks(np.arange(7)); axC.set_yticklabels(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"])
    axC.set_xticks(np.arange(0,24,3)); axC.set_xticklabels([str(h) for h in range(0,24,3)])
    axC.set_xlabel("Hour of day"); axC.set_ylabel("Weekday")
    cb = fig.colorbar(im, ax=axC, fraction=0.046, pad=0.02); cb.set_label("Events")

    # D: cascade
    axD.set_title("Shock + outcome cascade")
    labels = [x[0] for x in cascade]
    vals = np.array([x[1] for x in cascade], dtype=float)
    pct = 100*vals/vals[0]
    ypos = np.arange(len(labels))
    axD.barh(ypos, pct, alpha=0.9)
    axD.set_yticks(ypos); axD.set_yticklabels(labels)
    axD.invert_yaxis()
    axD.set_xlabel("Percent of cases (%)")
    axD.set_xlim(0,100)
    axD.grid(True, axis="x")
    for i,(p,v) in enumerate(zip(pct, vals)):
        axD.text(min(98,p+1.0), i, f"{p:.1f}%  (n={int(v)})",
                 va="center", ha=("right" if p>55 else "left"), fontsize=9)

    # E: station bubbles
    axE.set_title("Station-level performance (top 30 by volume)")
    X = topN["med_shock_min"].to_numpy(float)
    Y = 100*topN["survival"].to_numpy(float)
    S = 30 + 12*np.sqrt(topN["n"].to_numpy(float))
    C = topN["med_ems_min"].to_numpy(float)
    sc = axE.scatter(X, Y, s=S, c=C, cmap="viridis", alpha=0.85, edgecolors="white", linewidths=0.6)
    axE.set_xlabel("Median time-to-first shock (min)")
    axE.set_ylabel("Survival to discharge (%)")
    axE.grid(True)
    for _, r in topN.sort_values("n", ascending=False).head(8).iterrows():
        axE.text(float(r["med_shock_min"])+0.1, float(100*r["survival"])+0.3, r["station_label"], fontsize=8, alpha=0.85)
    cb2 = fig.colorbar(sc, ax=axE, fraction=0.046, pad=0.02)
    cb2.set_label("Median EMS response (min)")

    # F: bins
    axF.set_title("Outcomes vs time-to-first shock bins")
    xpos = np.arange(len(bin_labels))
    axF.bar(xpos, tb["n"].to_numpy(float), alpha=0.25, label="Cases (count)")
    axF.set_xticks(xpos); axF.set_xticklabels(bin_labels)
    axF.set_xlabel("Time-to-first shock (min)")
    axF.set_ylabel("Cases (count)")
    axF.grid(True, axis="y")
    axF2 = axF.twinx()
    axF2.plot(xpos, 100*tb["rosc"].to_numpy(float), marker="o", linewidth=2.2, label="ROSC %")
    axF2.plot(xpos, 100*tb["survival"].to_numpy(float), marker="s", linewidth=2.2, linestyle="--", label="Survival %")
    axF2.set_ylabel("Rate (%)")
    axF2.set_ylim(0, max(10, float(np.nanmax([100*tb["rosc"].max(), 100*tb["survival"].max()])+5)))
    h1,l1 = axF.get_legend_handles_labels()
    h2,l2 = axF2.get_legend_handles_labels()
    axF2.legend(h1+h2, l1+l2, loc="upper right", fontsize=9)

    base0 = os.path.join(args.out, "FigR0_REGISTRY_DASHBOARD_station_ohca")
    for ext in [".png",".pdf",".svg"]:
        fig.savefig(base0+ext, bbox_inches="tight")
    plt.close(fig)

    # === FIG R1: Survival response surface ===
    x = d["time_to_first_shock_s"].to_numpy(float)/60.0
    y = d["ems_response_time_s"].to_numpy(float)/60.0
    surv = d["surv_yes"].to_numpy(bool).astype(float)

    xbins = np.linspace(0, 15, 16)
    ybins = np.linspace(0, 15, 16)
    xi = np.digitize(x, xbins) - 1
    yi = np.digitize(y, ybins) - 1
    m = (xi>=0)&(xi<len(xbins)-1)&(yi>=0)&(yi<len(ybins)-1)
    xi = xi[m]; yi = yi[m]; surv = surv[m]

    counts = np.zeros((len(ybins)-1, len(xbins)-1), dtype=int)
    sums   = np.zeros_like(counts, dtype=float)
    for a,b,s in zip(xi, yi, surv):
        counts[b,a] += 1
        sums[b,a] += s
    rate = np.divide(sums, counts, out=np.full_like(sums, np.nan), where=counts>0)
    vmax = np.nanmax(rate*100) if np.isfinite(np.nanmax(rate*100)) else 1

    fig = plt.figure(figsize=(10,7), constrained_layout=True)
    ax = fig.add_subplot(111)
    im = ax.imshow(rate*100, origin="lower", aspect="auto", cmap="viridis", vmin=0, vmax=vmax)
    ax.set_title("Survival response surface (binned): time-to-first shock × EMS response", fontweight="bold")
    ax.set_xlabel("Time-to-first shock (min)")
    ax.set_ylabel("EMS response time (min)")
    ax.set_xticks(np.arange(len(xbins)-1))
    ax.set_xticklabels([f"{int(xbins[i])}-{int(xbins[i+1])}" if i%2==0 else "" for i in range(len(xbins)-1)],
                       rotation=45, ha="right", fontsize=9)
    ax.set_yticks(np.arange(len(ybins)-1))
    ax.set_yticklabels([f"{int(ybins[i])}-{int(ybins[i+1])}" if i%2==0 else "" for i in range(len(ybins)-1)],
                       fontsize=9)

    for b in range(counts.shape[0]):
        for a in range(counts.shape[1]):
            if counts[b,a] >= 12:
                ax.text(a, b, str(counts[b,a]), ha="center", va="center", fontsize=8, color="white", alpha=0.9)

    for t, lab in [(3,"3 min"),(5,"5 min")]:
        a = np.searchsorted(xbins, t) - 1
        ax.axvline(x=a+0.5, linestyle="--", linewidth=2, alpha=0.6, color="white")
        ax.text(a+0.6, counts.shape[0]-1, lab, color="white", fontsize=9, alpha=0.85, va="top")

    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
    cb.set_label("Survival to discharge (%)")
    ax.text(0.01, -0.13, "Numbers shown for bins with n≥12 (sample size).", transform=ax.transAxes, fontsize=9, alpha=0.8)

    base1 = os.path.join(args.out, "FigR1_SURVIVAL_RESPONSE_SURFACE_station_ohca")
    for ext in [".png",".pdf",".svg"]:
        fig.savefig(base1+ext, bbox_inches="tight")
    plt.close(fig)

    print("Wrote:", base0+".png", "and", base1+".png")

if __name__ == "__main__":
    main()
