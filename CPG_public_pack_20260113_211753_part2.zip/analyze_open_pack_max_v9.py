import argparse, os, math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --------------------------
# Styling (journal-friendly, colorful)
# --------------------------
def setup_style():
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.dpi": 160,
        "savefig.dpi": 520,
        "font.family": "DejaVu Sans",
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "axes.titleweight": "bold",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.22,
        "legend.frameon": True,
        "legend.framealpha": 0.92,
        "legend.fancybox": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

def savefig_all(fig, base_no_ext: str):
    # Avoid tight_layout mixing issues with colorbars; use constrained_layout in fig creation.
    fig.savefig(base_no_ext + ".png", bbox_inches="tight")
    fig.savefig(base_no_ext + ".pdf", bbox_inches="tight")
    fig.savefig(base_no_ext + ".svg", bbox_inches="tight")
    plt.close(fig)

def must_exist(p: str):
    if not os.path.exists(p):
        raise FileNotFoundError(p)

def pct(x: float) -> float:
    return float(np.round(100.0 * x, 2))

def wilson_ci(k: int, n: int, z: float = 1.96):
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1.0 + (z*z)/n
    center = (p + (z*z)/(2*n)) / denom
    half = (z * math.sqrt((p*(1-p)/n) + (z*z)/(4*n*n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))

def read_summary(path: str) -> pd.DataFrame:
    usecols = ["station_uid","country_iso2","station_kind","nearest_aed_m","unique_aeds_within_radius"]
    df = pd.read_csv(path, usecols=usecols, low_memory=True)
    df["nearest_aed_m"] = pd.to_numeric(df["nearest_aed_m"], errors="coerce")
    df["unique_aeds_within_radius"] = pd.to_numeric(df["unique_aeds_within_radius"], errors="coerce")
    df["country_iso2"] = df["country_iso2"].astype(str).str.strip()
    df["station_kind"] = df["station_kind"].astype(str).str.strip()
    return df

def time_to_defib_min(dist_m: np.ndarray, walk_speed_mps: float, setup_s: float, retrieval_multiplier: float):
    # retrieval_multiplier: 2.0=round-trip fetch; 1.0=assisted/nearby responder (one-way distance model)
    return ((retrieval_multiplier * dist_m / walk_speed_mps) + setup_s) / 60.0

def ecdf_window(values: np.ndarray, denom_n: int, xmax: float):
    # ECDF within a plotting window; y is fraction of ALL rows (denom_n)
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    x = x[(x >= 0.0) & (x <= xmax)]
    if x.size == 0 or denom_n <= 0:
        return np.array([]), np.array([])
    x = np.sort(x)
    y = np.arange(1, x.size + 1, dtype=float) / float(denom_n)
    return x, y

def pearson_r(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(x) & np.isfinite(y)
    if np.sum(m) < 3:
        return np.nan
    return float(np.corrcoef(x[m], y[m])[0,1])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--fig_dir", required=True)
    ap.add_argument("--max_dist_m", type=float, default=2000.0)
    ap.add_argument("--max_time_min", type=float, default=15.0)
    ap.add_argument("--top_countries", type=int, default=20)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    setup_style()
    rng = np.random.default_rng(args.seed)

    in_dir  = os.path.abspath(args.in_dir)
    out_dir = os.path.abspath(args.out_dir)
    fig_dir = os.path.abspath(args.fig_dir)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(fig_dir, exist_ok=True)

    p_summary = os.path.join(in_dir, "open_station_summary_top30_countries_max.csv")
    p_pairs   = os.path.join(in_dir, "open_pairs_top30_countries_max.csv")
    p_cst     = os.path.join(in_dir, "open_counts_station_kind_top30_max.csv")
    p_cad     = os.path.join(in_dir, "open_counts_aed_kind_top30_max.csv")
    p_meta    = os.path.join(in_dir, "open_metadata_coverage_top30_max.csv")

    must_exist(p_summary); must_exist(p_cst); must_exist(p_cad); must_exist(p_meta)

    df   = read_summary(p_summary)
    meta = pd.read_csv(p_meta, low_memory=True)

    # Distances: missing -> inf (so "≤ window" fractions remain correct)
    d = df["nearest_aed_m"].to_numpy(dtype=float)
    d_all = d.copy()
    d_all[~np.isfinite(d_all)] = np.inf

    railish = {"rail_station","pt_station","rail_halt","rail_stop"}
    df_rail = df[df["station_kind"].isin(railish)].copy()
    dR = df_rail["nearest_aed_m"].to_numpy(dtype=float)
    d_rail = dR.copy()
    d_rail[~np.isfinite(d_rail)] = np.inf

    N_all  = int(df.shape[0])
    N_rail = int(df_rail.shape[0]) if df_rail.shape[0] else 0

    # Country counts (rail-ish), for Top-N selection to reduce clutter
    if N_rail > 0:
        rail_counts = df_rail["country_iso2"].value_counts()
        topN = rail_counts.head(max(5, args.top_countries)).index.tolist()
    else:
        topN = []

    # Helper: country metrics
    thr_cols = [100, 200, 300, 500, 1000, 2000]
    thr_labels = ["≤100\nm","≤200\nm","≤300\nm","≤500\nm","≤1000\nm","≤2000\nm"]

    def country_metrics(dist_arr: np.ndarray, iso2: pd.Series, countries_subset=None, thr_m=500.0):
        rows = []
        iso = iso2.astype(str).to_numpy()
        countries = sorted([c for c in np.unique(iso) if c and c != "nan"])
        if countries_subset is not None:
            countries = [c for c in countries if c in set(countries_subset)]
        for c in countries:
            mask = (iso == c)
            dc = dist_arr[mask]
            n = int(dc.size)
            k = int(np.sum(dc <= thr_m))
            lo, hi = wilson_ci(k, n)
            rows.append({
                "country_iso2": c,
                "stations_n": n,
                "pct_leq_500m": pct(k/n) if n else np.nan,
                "ci95_lo_pct": pct(lo) if np.isfinite(lo) else np.nan,
                "ci95_hi_pct": pct(hi) if np.isfinite(hi) else np.nan,
                "pct_missing_or_gt2km": pct(np.mean(dc > args.max_dist_m)) if n else np.nan,
            })
        out = pd.DataFrame(rows)
        return out

    cm_rail_top = country_metrics(d_rail, df_rail["country_iso2"], countries_subset=topN, thr_m=500.0) if N_rail else pd.DataFrame()
    cm_all      = country_metrics(d_all, df["country_iso2"], countries_subset=None, thr_m=500.0)

    # Heatmap matrix (rail-ish, Top-N)
    def coverage_matrix(dist_arr: np.ndarray, iso2: pd.Series, countries_list):
        M = []
        for c in countries_list:
            mask = (iso2.astype(str).to_numpy() == c)
            dc = dist_arr[mask]
            row = [pct(np.mean(dc <= t)) for t in thr_cols]
            M.append(row)
        return np.asarray(M, dtype=float)

    # Metadata quality index
    meta2 = meta.copy()
    if "country_iso2" in meta2.columns:
        meta2["country_iso2"] = meta2["country_iso2"].astype(str).str.strip()
        meta2 = meta2.set_index("country_iso2")

    wanted = [
        "st_pct_name","st_pct_operator","st_pct_network","st_pct_wikidata","st_pct_wheelchair","st_pct_opening",
        "aed_pct_access","aed_pct_opening","aed_pct_operator","aed_pct_indoor"
    ]
    cols = [c for c in wanted if c in meta2.columns]
    mq = None
    if cols:
        mm = meta2[cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        mm["meta_quality_index"] = mm.mean(axis=1)
        mq = mm[["meta_quality_index"]].copy()

    # Join for bubble plot (use rail-ish Top-N if available; else all)
    bubble_df = None
    if mq is not None:
        if N_rail and not cm_rail_top.empty:
            tmp = cm_rail_top.set_index("country_iso2").join(mq, how="left").dropna()
        else:
            tmp = cm_all.set_index("country_iso2").join(mq, how="left").dropna()
        if tmp.shape[0] >= 5:
            bubble_df = tmp.reset_index()

    # --------------------------
    # FIG A (mono): Distance ECDF (all vs rail-ish) — with top-right legend + top labels
    # --------------------------
    def fig_distance_ecdf_mono():
        fig, ax = plt.subplots(figsize=(9.6, 6.0), constrained_layout=True)
        # ECDF within window, denominator includes ALL rows
        xA, yA = ecdf_window(d_all, N_all, args.max_dist_m)
        ax.step(xA, yA, where="post", linewidth=2.6, label=f"All station kinds (≤{int(args.max_dist_m)}m: {pct(np.mean(d_all<=args.max_dist_m)):.1f}%)")
        if N_rail:
            xR, yR = ecdf_window(d_rail, N_rail, args.max_dist_m)
            ax.step(xR, yR, where="post", linewidth=2.6, label=f"Rail-ish subset (≤{int(args.max_dist_m)}m: {pct(np.mean(d_rail<=args.max_dist_m)):.1f}%)")

        # Threshold lines + TOP labels
        for t in [100, 200, 300, 500, 1000, 2000]:
            ax.axvline(t, linestyle="--", linewidth=1.0, alpha=0.65)
        # label key thresholds at top
        for t, lab in [(200,"200m"), (500,"500m"), (1000,"1km"), (2000,"2km")]:
            ax.text(t, 0.985, lab, rotation=90, va="top", ha="right", fontsize=10, alpha=0.85)

        ax.set_xlim(0, args.max_dist_m)
        ax.set_ylim(0, 1.0)
        ax.set_xlabel("Distance to nearest AED (m)")
        ax.set_ylabel(f"ECDF (fraction of rows within 0–{int(args.max_dist_m)} m window)")
        ax.set_title("Nearest AED distance ECDF")
        ax.legend(loc="upper right")
        return fig

    savefig_all(fig_distance_ecdf_mono(), os.path.join(fig_dir, "FigA_ecdf_distance_all_vs_railish_v9"))

    # --------------------------
    # FIG B (mono): Time-to-defib ECDF (baseline) — top-right legend + top labels
    # --------------------------
    def fig_time_ecdf_mono():
        fig, ax = plt.subplots(figsize=(9.6, 6.0), constrained_layout=True)
        # Baseline parameters (consistent with your manuscript narrative)
        v = 1.2
        setup_s = 60.0

        if N_rail:
            t_round = time_to_defib_min(d_rail, v, setup_s, 2.0)
            t_asst  = time_to_defib_min(d_rail, v, setup_s, 1.0)
            x1, y1 = ecdf_window(t_round, N_rail, args.max_time_min)
            x2, y2 = ecdf_window(t_asst,  N_rail, args.max_time_min)
            ax.step(x1, y1, where="post", linewidth=2.6, label=f"Round-trip ×2 (≤{int(args.max_time_min)}m: {pct(np.mean(t_round<=args.max_time_min)):.1f}%)")
            ax.step(x2, y2, where="post", linewidth=2.6, label=f"Assisted ×1 (≤{int(args.max_time_min)}m: {pct(np.mean(t_asst<=args.max_time_min)):.1f}%)")
        else:
            t_round = time_to_defib_min(d_all, v, setup_s, 2.0)
            t_asst  = time_to_defib_min(d_all, v, setup_s, 1.0)
            x1, y1 = ecdf_window(t_round, N_all, args.max_time_min)
            x2, y2 = ecdf_window(t_asst,  N_all, args.max_time_min)
            ax.step(x1, y1, where="post", linewidth=2.6, label=f"Round-trip ×2")
            ax.step(x2, y2, where="post", linewidth=2.6, label=f"Assisted ×1")

        # 3/5-min lines + TOP labels (not bottom)
        for T, txt in [(3.0, "3 min"), (5.0, "5 min")]:
            ax.axvline(T, linestyle="--", linewidth=1.1, alpha=0.75)
            ax.text(T, 0.985, txt, rotation=90, va="top", ha="right", fontsize=10, alpha=0.9)

        ax.set_xlim(0, args.max_time_min)
        ax.set_ylim(0, 1.0)
        ax.set_xlabel("Estimated time-to-defibrillation (min)  (retrieval + setup)")
        ax.set_ylabel("ECDF")
        ax.set_title("Estimated time-to-defib ECDF (baseline)")
        ax.legend(loc="upper right")
        return fig

    savefig_all(fig_time_ecdf_mono(), os.path.join(fig_dir, "FigB_time_to_defib_ecdf_baseline_v9"))

    # --------------------------
    # FIG C (mono): Rail-ish country coverage heatmap (Top-N) — airy tick spacing
    # --------------------------
    def fig_heatmap_country_topN():
        if not N_rail or not topN:
            return None

        # Sort Top-N by ≤500m coverage (desc)
        sort_df = country_metrics(d_rail, df_rail["country_iso2"], countries_subset=topN, thr_m=500.0)
        top_sorted = sort_df.sort_values("pct_leq_500m", ascending=False)["country_iso2"].tolist()
        M = coverage_matrix(d_rail, df_rail["country_iso2"], top_sorted)

        fig, ax = plt.subplots(figsize=(10.2, max(6.2, 0.32*len(top_sorted) + 2.2)), constrained_layout=True)
        im = ax.imshow(M, aspect="auto", interpolation="nearest", cmap="magma", vmin=0, vmax=100)
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
        cb.set_label("% of stations within threshold", labelpad=10)

        ax.set_yticks(np.arange(len(top_sorted)))
        ax.set_yticklabels(top_sorted)
        ax.tick_params(axis="y", labelsize=10, pad=4)
        ax.set_xticks(np.arange(len(thr_cols)))
        ax.set_xticklabels(thr_labels)
        ax.tick_params(axis="x", labelsize=11, pad=8)

        ax.set_xlabel("Distance threshold")
        ax.set_ylabel("Country")
        ax.set_title(f"Rail-ish subset — country coverage heatmap (Top {len(top_sorted)} by station count)")
        return fig

    figC = fig_heatmap_country_topN()
    if figC is not None:
        savefig_all(figC, os.path.join(fig_dir, "FigC_heatmap_country_coverage_thresholds_railish_topN_v9"))

    # --------------------------
    # FIG D (mono): Forest/coverage within 500 m (Top-N) — airy + readable
    # --------------------------
    def fig_forest_topN():
        if not N_rail or cm_rail_top.empty:
            return None

        # Sort by coverage desc; keep Top-N (already Top-N by count)
        dff = cm_rail_top.copy().sort_values("pct_leq_500m", ascending=False, kind="mergesort").reset_index(drop=True)
        y = np.arange(dff.shape[0])

        x  = dff["pct_leq_500m"].to_numpy(dtype=float)
        lo = dff["ci95_lo_pct"].to_numpy(dtype=float)
        hi = dff["ci95_hi_pct"].to_numpy(dtype=float)
        xerr = np.vstack([x - lo, hi - x])

        fig, ax = plt.subplots(figsize=(10.2, max(6.2, 0.33*dff.shape[0] + 2.4)), constrained_layout=True)
        ax.errorbar(x, y, xerr=xerr, fmt="o", capsize=2, elinewidth=1.6, markersize=5.5)
        ax.set_yticks(y)
        ax.set_yticklabels(dff["country_iso2"].astype(str).tolist())
        ax.tick_params(axis="y", labelsize=10, pad=4)
        ax.invert_yaxis()

        ax.set_xlabel("% stations with nearest AED ≤ 500 m (Wilson 95% CI)")
        ax.set_title(f"Coverage within 500 m (Rail-ish; Top {dff.shape[0]} by station count)")

        # annotate station counts at right edge (subtle)
        xmax = max(10.0, float(np.nanmax(hi) + 6.0))
        ax.set_xlim(0, xmax)
        for i, n in enumerate(dff["stations_n"].tolist()):
            ax.text(xmax*0.985, i, f"n={n}", va="center", ha="right", fontsize=9.5, alpha=0.75)

        return fig

    figD = fig_forest_topN()
    if figD is not None:
        savefig_all(figD, os.path.join(fig_dir, "FigD_forest_coverage500m_railish_topN_v9"))

    # --------------------------
    # FIG E (mono): Data quality vs coverage (bubble) — restore alignment + centered label
    # --------------------------
    def fig_bubble_meta_quality():
        if bubble_df is None or bubble_df.shape[0] < 5:
            return None

        dff = bubble_df.copy()
        # y should not be negative; clamp view to [0, ...]
        y = dff["pct_leq_500m"].to_numpy(dtype=float)
        x = dff["meta_quality_index"].to_numpy(dtype=float)
        c = dff["pct_missing_or_gt2km"].to_numpy(dtype=float)
        n = dff["stations_n"].to_numpy(dtype=float)
        s = (np.sqrt(np.clip(n, 1, None)) * 8.0)

        fig, ax = plt.subplots(figsize=(9.8, 6.2), constrained_layout=True)
        sc = ax.scatter(x, y, s=s, c=c, cmap="plasma", alpha=0.88, edgecolors="white", linewidths=0.8)
        cb = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.03)
        cb.set_label("% missing / >2 km", labelpad=10)

        # regression line
        rr = pearson_r(x, y)
        if np.isfinite(rr) and np.sum(np.isfinite(x) & np.isfinite(y)) >= 3:
            a, b = np.polyfit(x[np.isfinite(x) & np.isfinite(y)], y[np.isfinite(x) & np.isfinite(y)], 1)
            xx = np.linspace(float(np.min(x)), float(np.max(x)), 100)
            ax.plot(xx, a*xx + b, linewidth=2.2, alpha=0.95)

        # annotation TOP-CENTER (as requested)
        ax.text(
            0.5, 0.98,
            f"Pearson r = {rr:.2f}" if np.isfinite(rr) else "Pearson r = NA",
            transform=ax.transAxes,
            ha="center", va="top",
            fontsize=11,
            bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="0.7", alpha=0.95)
        )

        ax.set_xlabel("Metadata quality index (%)  (mean tag completeness across station + AED fields)")
        ax.set_ylabel("% stations with nearest AED ≤ 500 m")
        ax.set_title("Data quality vs AED coverage (bubble = √stations)")
        ax.set_ylim(0, max(5.0, float(np.nanmax(y) + 5.0)))
        ax.set_xlim(max(0.0, float(np.nanmin(x) - 2.0)), float(np.nanmax(x) + 2.0))
        return fig

    figE = fig_bubble_meta_quality()
    if figE is not None:
        savefig_all(figE, os.path.join(fig_dir, "FigE_metadata_quality_vs_coverage_bubble_v9"))

    # --------------------------
    # FIG F (mono): Clinical sensitivity — CLEAN LINES (0–15%) so lines sit mid-plot
    # --------------------------
    def fig_clinical_sensitivity_lines():
        if not N_rail:
            dist_arr = d_all
            denom = N_all
        else:
            dist_arr = d_rail
            denom = N_rail

        setup_grid = np.arange(0, 181, 10, dtype=float)
        target_min = 5.0
        speeds = [1.0, 1.2, 1.5]  # slower/baseline/fast
        modes = [
            ("Round-trip ×2", 2.0, "-"),
            ("Assisted ×1",   1.0, "--"),
        ]

        # Use distinct color per speed (consistent, readable)
        speed_colors = {
            1.0: "#D55E00",  # orange/red
            1.2: "#0072B2",  # blue
            1.5: "#009E73",  # green
        }

        fig, ax = plt.subplots(figsize=(9.8, 6.2), constrained_layout=True)

        for v in speeds:
            for mode_name, mult, ls in modes:
                vals = []
                for s in setup_grid:
                    t = time_to_defib_min(dist_arr, v, s, mult)
                    vals.append(pct(np.mean(t <= target_min)))
                ax.plot(
                    setup_grid, vals,
                    linestyle=ls, linewidth=2.4,
                    color=speed_colors[v],
                    marker="o", markersize=3.2, markevery=2,
                    alpha=0.95,
                    label=f"v={v:.1f} m/s — {mode_name}"
                )

        ax.axvline(60, linewidth=1.0, alpha=0.45)
        ax.text(60, 14.8, "60 s", rotation=90, va="top", ha="right", fontsize=10, alpha=0.75)

        ax.set_xlabel("Setup time (s)")
        ax.set_ylabel("% stations meeting ≤ 5 min")
        ax.set_title("Clinical sensitivity (Rail-ish) — % meeting ≤ 5 min target")
        ax.set_xlim(0, 180)
        ax.set_ylim(0, 15)  # KEY FIX: keeps lines in the middle (not stuck at bottom)

        # Smaller legend, not covering labels
        ax.legend(
            loc="upper center",
            bbox_to_anchor=(0.5, 1.02),
            ncol=2,
            fontsize=9.5,
            columnspacing=1.2,
            handlelength=2.6
        )

        return fig

    savefig_all(fig_clinical_sensitivity_lines(), os.path.join(fig_dir, "FigF_clinical_sensitivity_lines_v9"))

    # --------------------------
    # FIG X: Rail-ish distance-bin composition (Top countries by station count) — legend TOP-RIGHT
    # --------------------------
    def fig_stacked_bins_top_countries():
        if not N_rail or not topN:
            return None

        # Use topN by station count; keep order by count descending (for your “wow” chart)
        rail_counts = df_rail["country_iso2"].value_counts()
        countries = rail_counts.head(max(5, args.top_countries)).index.tolist()

        bins = [0,100,200,300,500,1000,2000,np.inf]
        labels = ["0–100","100–200","200–300","300–500","500–1000","1000–2000",">2000/missing"]

        # Color palette similar to your pro fig
        colors = ["#2b145a","#4b1d82","#6f2c91","#b3367a","#f05b5b","#ff9b6a","#fde2aa"]

        rows = []
        iso = df_rail["country_iso2"].astype(str).to_numpy()
        for c in countries:
            mask = (iso == c)
            dc = d_rail[mask]
            # bin counts
            cnts = []
            for i in range(len(bins)-1):
                lo, hi = bins[i], bins[i+1]
                if np.isfinite(hi):
                    cnts.append(int(np.sum((dc >= lo) & (dc < hi))))
                else:
                    cnts.append(int(np.sum(dc >= lo)))
            n = int(np.sum(mask))
            perc = (np.array(cnts, dtype=float) / max(1,n)) * 100.0
            rows.append((c, perc, n))

        # plot
        fig, ax = plt.subplots(figsize=(12.2, max(6.8, 0.35*len(rows)+2.2)), constrained_layout=True)
        y = np.arange(len(rows))
        left = np.zeros(len(rows), dtype=float)

        for i, lab in enumerate(labels):
            vals = np.array([r[1][i] for r in rows], dtype=float)
            ax.barh(y, vals, left=left, color=colors[i], edgecolor="white", linewidth=0.8, label=lab)
            left += vals

        ax.set_yticks(y)
        ax.set_yticklabels([r[0] for r in rows], fontsize=12)
        ax.invert_yaxis()
        ax.set_xlim(0, 100)
        ax.set_xlabel("Percent of stations")
        ax.set_title("Rail-ish subset — distance-bin composition (top countries by station count)")

        ax.legend(loc="upper right", ncol=2, fontsize=11, framealpha=0.95)
        return fig

    figX = fig_stacked_bins_top_countries()
    if figX is not None:
        savefig_all(figX, os.path.join(fig_dir, "FigX_stacked_distance_bins_top_countries_v9"))

    # --------------------------
    # FIG M: Medical compound — smaller titles to avoid overlap
    # --------------------------
    def fig_medical_compound():
        # Use rail-ish if available, else all
        dist_arr = d_rail if N_rail else d_all
        denom = N_rail if N_rail else N_all

        fig, axes = plt.subplots(1, 3, figsize=(16.0, 5.4), constrained_layout=True)

        # (1) survival decay vs time-to-shock
        ax = axes[0]
        t = np.linspace(0, args.max_time_min, 200)
        rates = [0.03, 0.04, 0.05, 0.07, 0.10]
        for r in rates:
            ax.plot(t, (1.0 - r)**t, linewidth=2.6, label=f"{int(r*100)}%/min")
        for T in [3,5]:
            ax.axvline(T, linestyle="--", linewidth=1.0, alpha=0.7)
        ax.set_title("Medical model: survival decay vs time-to-shock", fontsize=12.5)
        ax.set_xlabel("Minutes from collapse to shock")
        ax.set_ylabel("Relative survival multiplier (heuristic)")
        ax.set_xlim(0, args.max_time_min)
        ax.set_ylim(0, 1.02)
        ax.legend(loc="upper right", fontsize=10)

        # (2) time-to-defib ECDF (scenarios)
        ax = axes[1]
        scenarios = [
            ("Slow round-trip", 1.0, 90.0, 2.0),
            ("Baseline round-trip", 1.2, 60.0, 2.0),
            ("Baseline assisted", 1.2, 60.0, 1.0),
            ("Fast assisted", 1.5, 45.0, 1.0),
        ]
        for name, v, s, mult in scenarios:
            tt = time_to_defib_min(dist_arr, v, s, mult)
            x, y = ecdf_window(tt, denom, args.max_time_min)
            ax.step(x, y, where="post", linewidth=2.6, label=name)
        for T in [3,5]:
            ax.axvline(T, linestyle="--", linewidth=1.0, alpha=0.7)
        ax.set_title("Operational model: time-to-defib distribution", fontsize=12.5)
        ax.set_xlabel("Estimated time-to-defibrillation (min)")
        ax.set_ylabel("ECDF")
        ax.set_xlim(0, args.max_time_min)
        ax.set_ylim(0, 1.0)
        ax.legend(loc="lower right", fontsize=10)

        # (3) opportunity index (heuristic) – compare assumed decay rates
        ax = axes[2]
        # Build mean opportunity by scenario under two assumptions
        labels = [s[0] for s in scenarios]
        vals_4 = []
        vals_10 = []
        for _, v, s, mult in scenarios:
            tt = time_to_defib_min(dist_arr, v, s, mult)
            surv_4  = np.power(0.96, np.where(np.isfinite(tt), tt, 1e9))
            surv_10 = np.power(0.90, np.where(np.isfinite(tt), tt, 1e9))
            vals_4.append(float(np.mean(surv_4)))
            vals_10.append(float(np.mean(surv_10)))

        x = np.arange(len(labels))
        w = 0.38
        ax.bar(x - w/2, vals_4,  width=w, label="Assumed 4%/min (CPR-like)")
        ax.bar(x + w/2, vals_10, width=w, label="Assumed 10%/min (no-CPR-like)")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=25, ha="right")
        ax.set_ylim(0, 1.0)
        ax.set_ylabel("Mean survival opportunity (0–1)")
        ax.set_title("Expected opportunity index (heuristic)", fontsize=12.5)
        ax.legend(loc="upper right", fontsize=10)

        fig.suptitle("Clinical impact summary (heuristic): early shock remains dominant", fontsize=15, fontweight="bold")
        return fig

    savefig_all(fig_medical_compound(), os.path.join(fig_dir, "FigM_medical_compound_survival_time_opportunity_v9"))

    # --------------------------
    # FIG Y (EXTRA): Clinical distance budget heatmap (3/5 min) across scenarios
    # --------------------------
    def fig_distance_budget_heatmap():
        # Scenario grid: speeds + setup, and two retrieval modes
        scenarios = [
            ("Slow",     1.0, 90.0),
            ("Baseline", 1.2, 60.0),
            ("Fast",     1.5, 45.0),
        ]
        modes = [
            ("Round-trip ×2", 2.0),
            ("Assisted ×1",   1.0),
        ]
        targets = [3, 5]

        rows = []
        vals = []
        for sc, v, s in scenarios:
            for mn, mult in modes:
                rows.append(f"{sc} — {mn}")
                rowv = []
                for T in targets:
                    # d = ((T*60 - setup)*v)/mult
                    dmax = max(0.0, ((T*60.0 - s) * v) / max(1e-9, mult))
                    rowv.append(dmax)
                vals.append(rowv)

        M = np.asarray(vals, dtype=float)  # rows x targets

        fig, ax = plt.subplots(figsize=(9.6, 6.0), constrained_layout=True)
        im = ax.imshow(M, aspect="auto", cmap="YlOrRd")
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
        cb.set_label("Distance budget (m)", labelpad=10)

        ax.set_yticks(np.arange(len(rows)))
        ax.set_yticklabels(rows)
        ax.tick_params(axis="y", labelsize=11, pad=4)

        ax.set_xticks(np.arange(len(targets)))
        ax.set_xticklabels([f"{t}-min target" for t in targets])
        ax.tick_params(axis="x", labelsize=12, pad=8)

        # annotate numbers
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                ax.text(j, i, f"{M[i,j]:.0f}", ha="center", va="center",
                        fontsize=11, color="black",
                        bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="0.8", alpha=0.85))

        ax.set_title("Clinical distance budget implied by time targets (heuristic)")
        ax.set_xlabel("Time-to-shock target")
        ax.set_ylabel("Scenario")
        return fig

    savefig_all(fig_distance_budget_heatmap(), os.path.join(fig_dir, "FigY_clinical_distance_budget_heatmap_v9"))

    # --------------------------
    # FIG 0 (Dashboard): 2x3 overview (NO A–F letters)
    # --------------------------
    def fig_dashboard():
        fig, axes = plt.subplots(2, 3, figsize=(17.2, 9.2), constrained_layout=True)
        axA, axB, axC, axD, axE, axF = axes.flatten()

        # A: distance ECDF
        xA, yA = ecdf_window(d_all, N_all, args.max_dist_m)
        axA.step(xA, yA, where="post", linewidth=2.4,
                 label=f"All (≤{int(args.max_dist_m)}m: {pct(np.mean(d_all<=args.max_dist_m)):.1f}%)")
        if N_rail:
            xR, yR = ecdf_window(d_rail, N_rail, args.max_dist_m)
            axA.step(xR, yR, where="post", linewidth=2.4,
                     label=f"Rail-ish (≤{int(args.max_dist_m)}m: {pct(np.mean(d_rail<=args.max_dist_m)):.1f}%)")

        for t in [100,200,300,500,1000,2000]:
            axA.axvline(t, linestyle="--", linewidth=1.0, alpha=0.55)
        for t, lab in [(200,"200m"), (500,"500m"), (1000,"1km"), (2000,"2km")]:
            axA.text(t, 0.985, lab, rotation=90, va="top", ha="right", fontsize=9.5, alpha=0.85)

        axA.set_xlim(0, args.max_dist_m)
        axA.set_ylim(0, 1.0)
        axA.set_title("Nearest AED distance ECDF")
        axA.set_xlabel("Distance (m)")
        axA.set_ylabel(f"ECDF (0–{int(args.max_dist_m)} m window)")
        axA.legend(loc="upper right", fontsize=10)

        # B: time ECDF baseline
        v, setup_s = 1.2, 60.0
        if N_rail:
            t_round = time_to_defib_min(d_rail, v, setup_s, 2.0)
            t_asst  = time_to_defib_min(d_rail, v, setup_s, 1.0)
            x1, y1 = ecdf_window(t_round, N_rail, args.max_time_min)
            x2, y2 = ecdf_window(t_asst,  N_rail, args.max_time_min)
            axB.step(x1, y1, where="post", linewidth=2.4, label="Round-trip ×2 (Rail-ish)")
            axB.step(x2, y2, where="post", linewidth=2.4, label="Assisted ×1 (Rail-ish)")
        else:
            t_round = time_to_defib_min(d_all, v, setup_s, 2.0)
            t_asst  = time_to_defib_min(d_all, v, setup_s, 1.0)
            x1, y1 = ecdf_window(t_round, N_all, args.max_time_min)
            x2, y2 = ecdf_window(t_asst,  N_all, args.max_time_min)
            axB.step(x1, y1, where="post", linewidth=2.4, label="Round-trip ×2")
            axB.step(x2, y2, where="post", linewidth=2.4, label="Assisted ×1")

        for T, txt in [(3.0, "3 min"), (5.0, "5 min")]:
            axB.axvline(T, linestyle="--", linewidth=1.0, alpha=0.7)
            axB.text(T, 0.985, txt, rotation=90, va="top", ha="right", fontsize=9.5, alpha=0.9)

        axB.set_xlim(0, args.max_time_min)
        axB.set_ylim(0, 1.0)
        axB.set_title("Estimated time-to-defib ECDF (baseline)")
        axB.set_xlabel("Minutes (retrieval + setup)")
        axB.set_ylabel("ECDF")
        axB.legend(loc="upper right", fontsize=10)

        # C: heatmap rail-ish Top-N
        if N_rail and topN:
            sort_df = country_metrics(d_rail, df_rail["country_iso2"], countries_subset=topN, thr_m=500.0)
            top_sorted = sort_df.sort_values("pct_leq_500m", ascending=False)["country_iso2"].tolist()
            M = coverage_matrix(d_rail, df_rail["country_iso2"], top_sorted)
            im = axC.imshow(M, aspect="auto", interpolation="nearest", cmap="magma", vmin=0, vmax=100)
            cb = fig.colorbar(im, ax=axC, fraction=0.046, pad=0.03)
            cb.set_label("%", labelpad=8)
            axC.set_yticks(np.arange(len(top_sorted)))
            axC.set_yticklabels(top_sorted)
            axC.tick_params(axis="y", labelsize=9.5, pad=3)
            axC.set_xticks(np.arange(len(thr_cols)))
            axC.set_xticklabels(thr_labels)
            axC.tick_params(axis="x", labelsize=10, pad=7)
            axC.set_title("Rail-ish — country coverage heatmap")
            axC.set_xlabel("Distance threshold")
            axC.set_ylabel("Country")
        else:
            axC.set_axis_off()
            axC.text(0.5, 0.5, "Rail-ish subset not available", ha="center", va="center")

        # D: forest Top-N
        if N_rail and not cm_rail_top.empty:
            dff = cm_rail_top.copy().sort_values("pct_leq_500m", ascending=False).reset_index(drop=True)
            y = np.arange(dff.shape[0])
            x = dff["pct_leq_500m"].to_numpy(dtype=float)
            lo = dff["ci95_lo_pct"].to_numpy(dtype=float)
            hi = dff["ci95_hi_pct"].to_numpy(dtype=float)
            xerr = np.vstack([x - lo, hi - x])
            axD.errorbar(x, y, xerr=xerr, fmt="o", capsize=2, elinewidth=1.4, markersize=4.8)
            axD.set_yticks(y)
            axD.set_yticklabels(dff["country_iso2"].astype(str).tolist())
            axD.tick_params(axis="y", labelsize=9.5, pad=3)
            axD.invert_yaxis()
            axD.set_title("Coverage within 500 m")
            axD.set_xlabel("% ≤ 500 m (Wilson 95% CI)")
            axD.set_xlim(0, max(10.0, float(np.nanmax(hi) + 6.0)))
        else:
            axD.set_axis_off()
            axD.text(0.5, 0.5, "Coverage plot unavailable", ha="center", va="center")

        # E: bubble
        if bubble_df is not None and bubble_df.shape[0] >= 5:
            dff = bubble_df.copy()
            yy = dff["pct_leq_500m"].to_numpy(dtype=float)
            xx = dff["meta_quality_index"].to_numpy(dtype=float)
            cc = dff["pct_missing_or_gt2km"].to_numpy(dtype=float)
            nn = dff["stations_n"].to_numpy(dtype=float)
            ss = (np.sqrt(np.clip(nn, 1, None)) * 6.8)

            sc = axE.scatter(xx, yy, s=ss, c=cc, cmap="plasma", alpha=0.88, edgecolors="white", linewidths=0.7)
            cb = fig.colorbar(sc, ax=axE, fraction=0.046, pad=0.03)
            cb.set_label("% missing/>2km", labelpad=8)

            rr = pearson_r(xx, yy)
            if np.isfinite(rr) and np.sum(np.isfinite(xx) & np.isfinite(yy)) >= 3:
                a, b = np.polyfit(xx[np.isfinite(xx) & np.isfinite(yy)], yy[np.isfinite(xx) & np.isfinite(yy)], 1)
                xxx = np.linspace(float(np.min(xx)), float(np.max(xx)), 100)
                axE.plot(xxx, a*xxx + b, linewidth=2.0, alpha=0.9)

            axE.text(
                0.5, 0.98,
                f"Pearson r = {rr:.2f}" if np.isfinite(rr) else "Pearson r = NA",
                transform=axE.transAxes, ha="center", va="top", fontsize=10.5,
                bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="0.7", alpha=0.95)
            )
            axE.set_title("Data quality vs coverage (bubble = √stations)")
            axE.set_xlabel("Metadata quality index (%)")
            axE.set_ylabel("% ≤ 500 m")
            axE.set_ylim(0, max(5.0, float(np.nanmax(yy) + 5.0)))
        else:
            axE.set_axis_off()
            axE.text(0.5, 0.5, "Metadata plot unavailable", ha="center", va="center")

        # F: clinical sensitivity lines (clean, mid-plot)
        dist_arr = d_rail if N_rail else d_all
        denom = N_rail if N_rail else N_all
        setup_grid = np.arange(0, 181, 10, dtype=float)
        target_min = 5.0
        speeds = [1.0, 1.2, 1.5]
        modes = [("Round-trip ×2", 2.0, "-"), ("Assisted ×1", 1.0, "--")]
        speed_colors = {1.0:"#D55E00", 1.2:"#0072B2", 1.5:"#009E73"}

        for v in speeds:
            for mode_name, mult, ls in modes:
                vals = []
                for s in setup_grid:
                    t = time_to_defib_min(dist_arr, v, s, mult)
                    vals.append(pct(np.mean(t <= target_min)))
                axF.plot(setup_grid, vals, linestyle=ls, linewidth=2.1,
                         color=speed_colors[v], alpha=0.95,
                         label=f"v={v:.1f} — {mode_name}")

        axF.axvline(60, linewidth=1.0, alpha=0.35)
        axF.set_title("Clinical sensitivity (Rail-ish)")
        axF.set_xlabel("Setup time (s)")
        axF.set_ylabel("% meeting ≤ 5 min")
        axF.set_xlim(0, 180)
        axF.set_ylim(0, 15)

        axF.legend(loc="upper center", bbox_to_anchor=(0.5, 1.02), ncol=2, fontsize=9.0,
                   columnspacing=1.1, handlelength=2.6)

        fig.suptitle("OpenStreetMap AED proximity audit — rail-station environments (dashboard)", fontsize=16, fontweight="bold")
        fig.text(0.5, 0.965, "Subset focus: Rail-ish (Top-N shown where relevant)", ha="center", va="top", fontsize=11, alpha=0.9)

        return fig

    savefig_all(fig_dashboard(), os.path.join(fig_dir, "Fig0_AUDIT_DASHBOARD_open_pack_max_v9"))

    # --------------------------
    # Minimal report (paths)
    # --------------------------
    rep = []
    rep.append("# OPEN PACK (MAX) — v9 outputs")
    rep.append("")
    rep.append(f"- Rows (all): {N_all:,}")
    rep.append(f"- Rows (rail-ish): {N_rail:,}")
    rep.append(f"- Figures folder: {fig_dir}")
    rep_path = os.path.join(out_dir, "REPORT_open_pack_max_v9.md")
    with open(rep_path, "w", encoding="utf-8") as f:
        f.write("\n".join(rep))

    print("DONE")
    print("OUT_DIR:", out_dir)
    print("FIG_DIR:", fig_dir)
    print("REPORT:", rep_path)

if __name__ == "__main__":
    main()
